import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp,
  Firestore
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with specific database ID if provided
export const db: Firestore = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Authentication Helpers
export async function signInWithGoogle(): Promise<User | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error('Google Sign-In Error:', error);
    throw error;
  }
}

export async function logOut(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error: any) {
    console.error('Sign-Out Error:', error);
    throw error;
  }
}

// Firestore Evidence Sync
export async function syncEvidenceToFirestore(userId: string, evidenceItems: any[]) {
  try {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, { lastActive: serverTimestamp() }, { merge: true });

    for (const item of evidenceItems) {
      const itemRef = doc(db, 'users', userId, 'evidence', String(item.id));
      await setDoc(
        itemRef,
        {
          ...item,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );
    }
  } catch (error) {
    console.warn('Firestore Evidence Sync Error (offline fallback active):', error);
  }
}

// Firestore Dual-Ledger Sync
export async function syncLedgerToFirestore(userId: string, ledgerEntries: any[]) {
  try {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, { lastActive: serverTimestamp() }, { merge: true });

    for (const entry of ledgerEntries) {
      const entryRef = doc(db, 'users', userId, 'ledger', String(entry.id));
      await setDoc(
        entryRef,
        {
          ...entry,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );
    }
  } catch (error) {
    console.warn('Firestore Ledger Sync Error (offline fallback active):', error);
  }
}

// Fetch user data from Firestore
export async function fetchUserCaseData(userId: string) {
  try {
    const evidenceSnap = await getDocs(collection(db, 'users', userId, 'evidence'));
    const evidenceList: any[] = [];
    evidenceSnap.forEach((doc) => evidenceList.push(doc.data()));

    const ledgerSnap = await getDocs(collection(db, 'users', userId, 'ledger'));
    const ledgerList: any[] = [];
    ledgerSnap.forEach((doc) => ledgerList.push(doc.data()));

    return {
      evidence: evidenceList,
      ledger: ledgerList
    };
  } catch (error) {
    console.warn('Error fetching user case data from Firestore:', error);
    return null;
  }
}
