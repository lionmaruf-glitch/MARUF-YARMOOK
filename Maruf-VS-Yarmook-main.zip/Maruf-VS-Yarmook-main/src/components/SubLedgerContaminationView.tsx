import React from 'react';
import { Binary, ShieldAlert, ArrowRight, Printer, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Language } from '../data/translations';
import { CONTAMINATION_ENTRIES } from '../data/forensicData';

interface SubLedgerContaminationViewProps {
  lang: Language;
  onNavigate: (section: string) => void;
  onPrint: () => void;
}

export const SubLedgerContaminationView: React.FC<SubLedgerContaminationViewProps> = ({
  lang,
  onNavigate,
  onPrint
}) => {
  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Binary className="w-3.5 h-3.5 text-amber-600" />
              <span>Section 6 · Forensic Sub-Ledger Tampering Evidence</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'সাব-লেজার দূষণ ও প্রতারণামূলক জালিয়াতি রেকর্ড' : lang === 'ar' ? 'تلوث السجل الفرعي (MARUF LOAN A/C) والتلاعب المحاسبي' : 'Sub-Ledger Contamination & Fraud Analysis'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'কোম্পানির অ্যাকাউন্টিং সফটওয়্যার (MARUF LOAN A/C) থেকে সংগৃহীত অকাট্য প্রমাণ যাতে দেখা যায় অন্য শ্রমিকদের ঋণ মারুফের ব্যক্তিগত লোনে ঢুকিয়ে কৃত্রিম দেনা সৃষ্টি করা হয়েছিল।'
                : lang === 'ar'
                ? 'كشف ضوئي وتحليل فني يثبت إقحام سلفيات عمال آخرين (شاه جهان وحافظ) لتضخيم مديونية العامل صورياً واصطناع عجز 2,200 ر.ع كيدياً.'
                : 'Irrefutable proof from company accounting software showing insertion of third-party workers debts (Shajahan & Hafez) into Maruf loan ledger.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onPrint}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'প্রমাণ প্রিন্ট' : lang === 'ar' ? 'طباعة الكشف' : 'Print Ledger'}</span>
            </button>
          </div>
        </div>

        {/* Forensic Core Finding Callout */}
        <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <b className="text-amber-950 block text-sm mb-0.5">
                {lang === 'bn' ? 'আদালতের মূল বিচার্য বিষয়: ০৬/০৭/২০২৪ তারিখে হিসাব ছিল প্লাস ২১.৮০ রিয়াল ক্রেডিট!' : lang === 'ar' ? 'نقطة الفصل الجنائية: قفل الحساب في 06/07/2024م برصيد دائن (+21.80 ر.ع)!' : 'Crucial Court Evidence: Cleared balance of +21.80 OMR on 06/07/2024!'}
              </b>
              <p className="text-amber-900 leading-relaxed">
                {lang === 'bn'
                  ? 'কোম্পানির নিজের খতিয়ানই প্রমাণ করে মারুফের কোনো দেনা ছিল না। ছুটি থেকে ফেরার পর অ্যাডমিন পাসওয়ার্ড বদলে ২,২০০ রিয়ালের যে ঘাটতি সৃষ্টি করা হয়েছে তা সম্পূর্ণ মিথ্যা ও জালিয়াতি।'
                  : lang === 'ar'
                  ? 'كشف الحساب الختامي يثبت قطعياً أن حساب العامل كان مسوّى برصيد دائن 21.80 ر.ع، مما ينسف ادعاء العجز الجديد (2,200 ر.ع) كلياً.'
                  : 'Company own ERP final balance on 06/07/2024 proved Maruf was in credit. The 2,200 OMR shortage fabricated later was an intentional fraud.'}
              </p>
            </div>
          </div>
          <div className="shrink-0">
            <span className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-mono font-bold text-xs inline-block">
              +21.800 OMR Credit
            </span>
          </div>
        </div>
      </div>

      {/* Contamination Forensic Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 mb-1">
          {lang === 'bn' ? 'অ্যাকাউন্টিং সফটওয়্যার সাব-লেজার অডিট সারণি' : lang === 'ar' ? 'جدول بنود التلوث المحاسبي في حساب MARUF LOAN A/C' : 'Sub-Ledger MARUF LOAN A/C Audit Table'}
        </h2>
        <p className="text-xs text-slate-500 mb-4 font-mono">
          Company Code: 1834525 · Branch: BARKA SANAIYA · ERP v2.4 Audit
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-[#0b1f3a] text-white font-semibold">
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Voucher No.</th>
                <th className="py-3 px-4">Account Details & Narrative</th>
                <th className="py-3 px-3 text-right">Debit (OMR)</th>
                <th className="py-3 px-3 text-right">Credit (OMR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800 font-mono">
              {CONTAMINATION_ENTRIES.map((row, idx) => (
                <tr
                  key={idx}
                  className={`transition-colors ${
                    row.highlight
                      ? 'bg-amber-50/80 font-semibold'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  <td className="py-3 px-3 whitespace-nowrap">{row.date}</td>
                  <td className="py-3 px-3 whitespace-nowrap font-bold text-slate-600">{row.voucher}</td>
                  <td className="py-3 px-4 font-sans text-xs">
                    <span className={row.highlight ? 'text-amber-950 font-bold' : 'text-slate-700'}>
                      {row.narrative}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-red-700 font-bold">
                    {row.debit !== null ? row.debit.toFixed(3) : '—'}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-emerald-700 font-bold">
                    {row.credit !== null ? row.credit.toFixed(3) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Forensic Notes */}
        <div className="mt-5 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-2">
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{lang === 'bn' ? 'ফরেনসিক আইনি বিশ্লেষণ:' : lang === 'ar' ? 'التحليل الجنائي للواقعة:' : 'Forensic Evidentiary Analysis:'}</span>
          </div>
          <p className="leading-relaxed">
            1. <b>Voucher Pmt:2080 (11-12-2021)</b>: SHAJAHAN ADVANCE (300 OMR) was directly injected into Maruf personal ledger with zero legal justification.
          </p>
          <p className="leading-relaxed">
            2. <b>Voucher Pmt:2110 (20-12-2021)</b>: HAFEZ LOAN (100 OMR) was forced onto claimant's sub-ledger to fabricate a bogus debt balance.
          </p>
          <p className="leading-relaxed">
            3. On <b>06-07-2024</b>, when legitimate liquidations were calculated, the account was in fact in credit by <b>+21.800 OMR</b>, conclusively invalidating the later claim of a 2,200 OMR cash deficit.
          </p>
        </div>
      </div>

    </div>
  );
};
