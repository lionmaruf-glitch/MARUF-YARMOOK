import React, { useState, useMemo } from 'react';
import { Calculator, RotateCcw, AlertCircle, FileSpreadsheet, CheckCircle, Scale, ShieldAlert, TrendingDown } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';

interface LegalCalculatorProps {
  lang: Language;
  onNavigateToPetition: () => void;
}

export const LegalCalculator: React.FC<LegalCalculatorProps> = ({
  lang,
  onNavigateToPetition
}) => {
  const t = TRANSLATIONS[lang];

  // Configurable inputs
  const [basicSalary, setBasicSalary] = useState<number>(250);
  const [tenureYears, setTenureYears] = useState<number>(11);
  const [covidMonths, setCovidMonths] = useState<number>(12);
  const [monthlyIllegalCut, setMonthlyIllegalCut] = useState<number>(50);
  const [illegalCutMonths, setIllegalCutMonths] = useState<number>(12);
  const [covidQuarantinePenalty, setCovidQuarantinePenalty] = useState<number>(600);
  const [ooredooPenalty, setOoredooPenalty] = useState<number>(217);
  const [leaveAllowanceTotal, setLeaveAllowanceTotal] = useState<number>(1100);
  const [showFraudComparison, setShowFraudComparison] = useState<boolean>(true);

  // Dynamic computations
  const calculations = useMemo(() => {
    // 1. EOSB Article 37:
    // First 3 years @ 15 days basic wage (0.5 month per year)
    // Subsequent years (above 3) @ 30 days basic wage (1.0 month per year)
    const first3Years = Math.min(tenureYears, 3);
    const remainingYears = Math.max(0, tenureYears - 3);

    const eosbFirst3 = first3Years * (basicSalary * 0.5);
    const eosbRemaining = remainingYears * basicSalary;
    const eosbTotal = eosbFirst3 + eosbRemaining;

    // 2. COVID Unpaid Period Wages
    const covidWagesTotal = covidMonths * basicSalary;

    // 3. Illegal Deductions
    const recurringCuts = monthlyIllegalCut * illegalCutMonths;
    const illegalDeductionsTotal = recurringCuts + covidQuarantinePenalty + ooredooPenalty;

    // 4. Annual Leave
    const annualLeaveTotal = leaveAllowanceTotal;

    // Grand Total
    const grandTotal = eosbTotal + covidWagesTotal + illegalDeductionsTotal + annualLeaveTotal;

    // Fraud comparison with fake 60 OMR paper contract
    const fakeEosb = (first3Years * 30) + (remainingYears * 60);
    const stolenDifference = eosbTotal - fakeEosb;

    return {
      eosbFirst3,
      eosbRemaining,
      eosbTotal,
      covidWagesTotal,
      recurringCuts,
      illegalDeductionsTotal,
      annualLeaveTotal,
      grandTotal,
      fakeEosb,
      stolenDifference
    };
  }, [
    basicSalary,
    tenureYears,
    covidMonths,
    monthlyIllegalCut,
    illegalCutMonths,
    covidQuarantinePenalty,
    ooredooPenalty,
    leaveAllowanceTotal
  ]);

  const handleReset = () => {
    setBasicSalary(250);
    setTenureYears(11);
    setCovidMonths(12);
    setMonthlyIllegalCut(50);
    setIllegalCutMonths(12);
    setCovidQuarantinePenalty(600);
    setOoredooPenalty(217);
    setLeaveAllowanceTotal(1100);
  };

  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span>Royal Decree No. 53/2023 Statutory Algorithm</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {t.calculatorTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {t.calculatorSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.calculateReset}</span>
            </button>
            <button
              onClick={onNavigateToPetition}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'আদালতের পিটিশনে দেখুন' : lang === 'ar' ? 'عرض في صحيفة الدعوى' : 'View in Petition'}</span>
            </button>
          </div>
        </div>

        {/* Input Controls Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          
          {/* Proven Basic Salary */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.basicSalaryInput}
            </label>
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min="60"
                max="1000"
                step="10"
                value={basicSalary}
                onChange={(e) => setBasicSalary(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-mono font-bold bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-slate-900"
              />
              <span className="text-xs font-semibold text-slate-500">OMR</span>
            </div>
            <p className="text-[11px] text-emerald-700 font-medium mt-1.5">
              ✓ Bank Muscat WPS verified: 250 OMR
            </p>
          </div>

          {/* Tenure Years */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.tenureYearsInput}
            </label>
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min="1"
                max="30"
                step="1"
                value={tenureYears}
                onChange={(e) => setTenureYears(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-mono font-bold bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-slate-900"
              />
              <span className="text-xs font-semibold text-slate-500">Years</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5">
              July 2015 – September 2026 (11 yrs)
            </p>
          </div>

          {/* Unpaid COVID Months */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.covidMonthsInput}
            </label>
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min="0"
                max="24"
                step="1"
                value={covidMonths}
                onChange={(e) => setCovidMonths(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-mono font-bold bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-slate-900"
              />
              <span className="text-xs font-semibold text-slate-500">Months</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1.5">
              12 mos @ 250 OMR = 3,000 OMR
            </p>
          </div>

          {/* Illegal Deductions Sub-items */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.monthlyDeductionInput}
            </label>
            <div className="flex items-center gap-2 mt-2">
              <input
                type="number"
                min="0"
                max="200"
                step="5"
                value={monthlyIllegalCut}
                onChange={(e) => setMonthlyIllegalCut(Number(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-mono font-bold bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-slate-900"
              />
              <span className="text-xs font-semibold text-slate-500">OMR/mo</span>
            </div>
            <p className="text-[11px] text-red-700 font-medium mt-1.5">
              12 mos × 50 = 600 OMR + 600 COVID + 217 Ooredoo
            </p>
          </div>

        </div>
      </div>

      {/* Main Statutory Output Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Itemized Breakdown Cards */}
        <div className="lg:col-span-2 space-y-4">
          
          {/* Card 1: EOSB */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold text-amber-700">ARTICLE 37</span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">
                  {t.calcEosbTitle}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {lang === 'bn'
                    ? 'প্রথম ৩ বছর: প্রতি বছর ১৫ দিনের বেতন (১২৫ রিয়াল × ৩ = ৩৭৫ রিয়াল) + পরবর্তী ৮ বছর: প্রতি বছর ৩০ দিনের বেতন (২৫০ রিয়াল × ৮ = ২,০০০ রিয়াল)।'
                    : lang === 'ar'
                    ? 'أول 3 سنوات (15 يوماً/سنة = 375 ر.ع) + السنوات الـ 8 التالية (30 يوماً/سنة = 2,000 ر.ع) محسوبة على الأجر الأساسي الفعلي 250 ر.ع.'
                    : 'First 3 years @ 15 days/yr (375 OMR) + subsequent 8 years @ 30 days/yr (2,000 OMR) based on 250 OMR wage.'}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
                  {calculations.eosbTotal.toLocaleString('en-US', { minimumFractionDigits: 3 })}
                </div>
                <span className="text-xs font-semibold text-slate-500">OMR</span>
              </div>
            </div>
          </div>

          {/* Card 2: COVID Wages */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold text-blue-700">WAGE PROTECTION</span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">
                  {t.calcCovidTitle}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {lang === 'bn'
                    ? 'আকাশপথ বন্ধ ও আটকে পড়ার সময়ে কোম্পানির দায়িত্বভুক্ত ১২ মাসের বেতন (১২ মাস × ২৫০ ওমানি রিয়াল = ৩,০০০ রিয়াল)।'
                    : lang === 'ar'
                    ? 'أجور 12 شهراً مستحقة خلال فترة الإغلاق القسري للطيران والجائحة (12 × 250 ر.ع = 3,000 ر.ع).'
                    : '12 months unremitted wages during air lockdown and quarantine (12 × 250 OMR = 3,000 OMR).'}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
                  {calculations.covidWagesTotal.toLocaleString('en-US', { minimumFractionDigits: 3 })}
                </div>
                <span className="text-xs font-semibold text-slate-500">OMR</span>
              </div>
            </div>
          </div>

          {/* Card 3: Illegal Deductions */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold text-red-700">ARTICLES 55, 58 & 59</span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">
                  {t.calcDeductionsTitle}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {lang === 'bn'
                    ? 'কোভিড কোয়ারেন্টাইন জরিমানা (৬০০ রিয়াল) + মাসিক বেআইনি কর্তন (৬০০ রিয়াল) + কোম্পানির অরিডু বিল (২১৭ রিয়াল) = ১,৪১৭ রিয়াল ফেরত।'
                    : lang === 'ar'
                    ? 'استرداد مصاريف حجر كورونا (600 ر.ع) + الخصومات الشهرية (600 ر.ع) + فاتورة هاتف أوريدو التجاري (217 ر.ع).'
                    : 'Refund of 600 OMR COVID penalty + 600 OMR arbitrary cuts + 217 OMR Ooredoo commercial line.'}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
                  {calculations.illegalDeductionsTotal.toLocaleString('en-US', { minimumFractionDigits: 3 })}
                </div>
                <span className="text-xs font-semibold text-slate-500">OMR</span>
              </div>
            </div>
          </div>

          {/* Card 4: Accrued Leave */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold text-emerald-700">ARTICLE 66</span>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">
                  {t.calcLeaveTitle}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {lang === 'bn'
                    ? '১১ বছর অবিচ্ছিন্ন দায়িত্ব পালনের বিপরীতে সঞ্চিত বার্ষিক ছুটির আইনসম্মত আর্থিক এনক্যাশমেন্ট।'
                    : lang === 'ar'
                    ? 'مستحقات رصيد الإجازات السنوية المتراكمة طوال 11 سنة خدمة متصلة دون صرف نقدي.'
                    : 'Accrued statutory leave balance across 11 unbroken years of service.'}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
                  {calculations.annualLeaveTotal.toLocaleString('en-US', { minimumFractionDigits: 3 })}
                </div>
                <span className="text-xs font-semibold text-slate-500">OMR</span>
              </div>
            </div>
          </div>

        </div>

        {/* Right 1 Column: Grand Total Card + Fraud Comparison Widget */}
        <div className="space-y-4">
          
          {/* Grand Total Display */}
          <div className="bg-[#0b1f3a] text-white rounded-xl p-6 shadow-md border border-slate-800">
            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
              {t.totalCalculatedOutput}
            </div>
            
            <div className="text-4xl sm:text-5xl font-extrabold font-mono text-amber-300 tabular-nums tracking-tight my-2">
              {calculations.grandTotal.toLocaleString('en-US', { minimumFractionDigits: 3 })}
            </div>
            <div className="text-sm font-semibold text-slate-300">
              Omani Rials (OMR)
            </div>

            <p className="text-xs text-slate-400 mt-4 pt-4 border-t border-slate-700/80 leading-relaxed">
              {t.royalDecreeCitation}
            </p>

            <button
              onClick={onNavigateToPetition}
              className="w-full mt-5 py-3 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{lang === 'bn' ? 'আদালতের পিটিশনে সংযুক্ত করুন' : lang === 'ar' ? 'اعتماد الحسبة في صحيفة الدعوى' : 'Commit Calculation to Petition'}</span>
            </button>
          </div>

          {/* Employer Fraud Comparison Box */}
          <div className="bg-white rounded-xl border border-red-200 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
              <div className="flex items-center gap-1.5 text-xs font-bold text-red-900">
                <ShieldAlert className="w-4 h-4 text-red-600" />
                <span>{lang === 'bn' ? 'কোম্পানির ৬০ রিয়াল চুক্তির প্রতারণা' : lang === 'ar' ? 'مقارنة الاحتيال: العقد الصوري 60 ر.ع' : 'Deception Contrast: 60 OMR Contract'}</span>
              </div>
              <button
                onClick={() => setShowFraudComparison(!showFraudComparison)}
                className="text-[11px] text-slate-500 hover:text-slate-800 font-medium"
              >
                {showFraudComparison ? 'Hide' : 'Show'}
              </button>
            </div>

            {showFraudComparison && (
              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center text-slate-600">
                  <span>{lang === 'bn' ? 'প্রকৃত ২৫০ রিয়ালে গ্র্যাচুইটি:' : lang === 'ar' ? 'مكافأة 250 ر.ع الحقيقية:' : 'True 250 OMR EOSB:'}</span>
                  <span className="font-mono font-bold text-slate-900">{calculations.eosbTotal.toFixed(3)} OMR</span>
                </div>
                <div className="flex justify-between items-center text-slate-500">
                  <span>{lang === 'bn' ? 'ভুয়া ৬০ রিয়ালে হিসাব করলে:' : lang === 'ar' ? 'الحسبة بالعقد الصوري 60 ر.ع:' : 'Simulated 60 OMR Contract:'}</span>
                  <span className="font-mono text-red-700">{calculations.fakeEosb.toFixed(3)} OMR</span>
                </div>
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-100 text-red-950">
                  <div className="flex justify-between items-center font-bold">
                    <span>{lang === 'bn' ? 'চুরি করার অপচেষ্টা:' : lang === 'ar' ? 'المبلغ المستهدف سرقته:' : 'Amount Targeted to Steal:'}</span>
                    <span className="font-mono text-sm text-red-700">+{calculations.stolenDifference.toFixed(3)} OMR</span>
                  </div>
                  <p className="text-[11px] text-red-900 mt-1 leading-normal">
                    {lang === 'bn'
                      ? 'কোম্পানি এই ১,৬১৫ রিয়াল আত্মসাৎ করার জন্যই জোরপূর্বক সাদা কাগজে ও ৬০ রিয়ালের চুক্তিতে সই নেওয়ার অপচেষ্টা চালায়।'
                      : lang === 'ar'
                      ? 'هذا الفارق يوضح الدافع وراء تزوير العقود والضغط لتوقيع إبراء الذمة.'
                      : 'This proven discrepancy exposes the illicit motive behind the coercive paper contract.'}
                  </p>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
