import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  FileCheck2,
  Sparkles,
  AlertCircle,
  Copy,
  Check,
  Download,
  Trash2,
  RefreshCw,
  Search,
  BookOpen,
  Scale,
  ShieldAlert,
  Send,
  Eye,
  Camera,
  ExternalLink,
  ChevronRight,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { Language } from '../data/translations';
import { DocumentScannerModal } from './DocumentScannerModal';

interface LegalResearchLabViewProps {
  lang: Language;
  onForwardToPetition?: (text: string) => void;
  onForwardToAILab?: (text: string) => void;
}

interface PreloadedDoc {
  id: string;
  titleEn: string;
  titleAr: string;
  titleBn: string;
  category: string;
  type: string;
  size: string;
  fileName: string;
  mimeType: string;
  summary: string;
  sampleText: string;
}

const PRELOADED_CASE_DOCS: PreloadedDoc[] = [
  {
    id: 'barka-summons',
    titleEn: 'Barka Primary Court Summons (Case 1005/1215/2026)',
    titleAr: 'إعلان وتكليف حضور المحكمة الابتدائية ببركاء (الدعوى 1005/1215/2026)',
    titleBn: 'বারকা প্রাথমিক আদালত সমন (কেস নং ১০০৫/১২১৫/২০২৬)',
    category: 'Court Judgment & Summons',
    type: 'Official Judicial Notice',
    size: '1.4 MB',
    fileName: 'barka_court_summons_1005_1215_2026.pdf',
    mimeType: 'application/pdf',
    summary: 'Judicial summons to attend civil circuit session on 29/06/2026 at 09:00 AM regarding company claim of 300 OMR unpaid loan balance.',
    sampleText: `سلطنة عمان - المجلس الأعلى للقضاء - المحكمة الابتدائية ببركاء
إعلان بالحضور أمام الدائرة فردي مدني في الدعوى رقم 1005/1215/2026
المدعية: شركة اليرموك الحديثة للتجارة ش.م.م (سجل تجاري 1834525)
المدعى عليه: حبيب الرحمن عبد البارك (الرقم المدني 103352388)
موضوع الدعوى: مطالبة مالية بسداد رصيد سلفة مزعومة بمبلغ 300 ر.ع وتسليم عهدة فرع بركاء الصناعية.`
  },
  {
    id: 'absconding-notice',
    titleEn: 'Malicious Absconding Report DCA-20260802114',
    titleAr: 'بلاغ ترك العمل الكيدي الصادر بعد النزاع (DCA-20260802114)',
    titleBn: 'প্রতিশোধমূলক ভুয়া পলায়ন নোটিশ DCA-20260802114',
    category: 'Police & MOL Notice',
    type: 'MOL Absconding Notice',
    size: '890 KB',
    fileName: 'mol_absconding_notice_DCA_20260802114.pdf',
    mimeType: 'application/pdf',
    summary: 'Retaliatory absconding report registered on 02/08/2026, four days after Maruf reopened MOL complaint REF2607290085. Direct violation of RD 53/2023 Art. 114.',
    sampleText: `وزارة العمل - سلطنة عمان
إشعار تسجيل بلاغ ترك العمل رقم: DCA-20260802114
تاريخ التسجيل: 02/08/2026م
اسم المنشأة: شركة اليرموك الحديثة للتجارة ش.م.م
اسم العامل: حبيب الرحمن عبد البارك (رقم بطاقة المقيم: 103352388)
ملاحظة قانونية حاسمة: الشكوى العمالية رقم REF2603150080 مقيدة بتاريخ 15/03/2026م ومجددة برقم REF2607290085 بتاريخ 29/07/2026م، مما يجعل هذا البلاغ باطلاً بحكم القانون لمخالفته المادة 114.`
  },
  {
    id: 'wps-bank-muscat',
    titleEn: 'Bank Muscat WPS Official Statement (250 OMR)',
    titleAr: 'كشف رواتب نظام حماية الأجور بنك مسقط (WPS 250 ر.ع)',
    titleBn: 'ব্যাংক মাস্কাট ডব্লিউপিএস স্যালারি স্টেটমেন্ট (২৫০ OMR)',
    category: 'Certified Banking Record',
    type: 'Official Bank Statement',
    size: '2.8 MB',
    fileName: 'bank_muscat_wps_statement_maruf.pdf',
    mimeType: 'application/pdf',
    summary: 'Official Bank Muscat WPS wage statement proving regular monthly basic transfers of 250.000 OMR into account #0453043828350012, completely refuting 60 OMR dummy contract.',
    sampleText: `Bank Muscat (S.A.O.G) - Official Wage Protection System (WPS) Certificate
Beneficiary: Habibur Rahman Abdul Barak (Civil ID: 103352388)
Bank Account: 0453-0438-2835-0012
Employer: Al Yarmook Modern Trading LLC (CR: 1834525)
Standard Remittance: 250.000 OMR Monthly Basic Salary (MD 729/2024 compliance)
Irregularities Detected: Intermittent unremitted periods (2020 lockdown) and unapproved sub-deductions.`
  },
  {
    id: 'nazar-diary',
    titleEn: 'Nazar Handwritten Diary & Sub-Ledger Tampering',
    titleAr: 'دفتر حسابات النزار اليدوي وتلوث السجل الفرعي',
    titleBn: 'নজর ডায়েরি ও সাব-লেজার টেম্পারিংয়ের প্রমাণপত্র',
    category: 'Forensic Accounting Evidence',
    type: 'Handwritten Ledger Scan',
    size: '3.1 MB',
    fileName: 'nazar_handwritten_ledger_contamination.jpg',
    mimeType: 'image/jpeg',
    summary: 'Page 42 from accountant Nazar handwritten store log. Account closed on 06/07/2024 with a credit of 21.80 OMR, followed by forged insertion of Shah Jahan (300 OMR) and Hafez (100 OMR) debts.',
    sampleText: `فحص دفتري جنائي: دفتر النزار لفرع بركاء الصناعية
حساب سلفيات معروف (MARUF LOAN A/C):
- تاريخ الإقفال النهائي المعتمد: 06/07/2024م
- الرصيد الختامي: دائن بمبلغ 21.80 ر.ع (الشركة مدينة للعامل)
- الإقحام غير المشروع: تدوين سلفة السائق شاه جهان بمبلغ 300 ر.ع وسلفة حافظ 100 ر.ع في ذمة حبيب الرحمن دون توقيع أو سند استلام.`
  },
  {
    id: 'ooredoo-invoice',
    titleEn: 'Ooredoo Commercial SIM Invoice (217 OMR Deducted)',
    titleAr: 'فواتير خط أوريدو التجاري المخصوم من الراتب (217 ر.ع)',
    titleBn: 'ওরিডু বাণিজ্যিক সিম ইনভয়েস (২১৭ রিয়াল অবৈধ কর্তন)',
    category: 'Commercial Utility Proof',
    type: 'Telecom Statement',
    size: '1.1 MB',
    fileName: 'ooredoo_commercial_sim_invoices.pdf',
    mimeType: 'application/pdf',
    summary: 'Official invoices for corporate mobile line (+968 96522902) registered in company CR name for Barka branch sales, whose bills were illegally deducted from Maruf wages.',
    sampleText: `Ooredoo Sultanate of Oman - Corporate Billing Account
Subscriber Name: Al Yarmook Modern Trading LLC (CR: 1834525)
Service Line: +968 96522902 (Barka Aluminium & Glass Store Operations)
Total Accumulated Payments Deducted from Employee Wages: 217.350 OMR
Statutory Breach: Employer operating costs unlawfully transferred to employee in violation of RD 53/2023 Art. 58.`
  }
];

export const LegalResearchLabView: React.FC<LegalResearchLabViewProps> = ({
  lang,
  onForwardToPetition,
  onForwardToAILab
}) => {
  const [selectedStudyType, setSelectedStudyType] = useState<string>('comprehensive_study');
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    type: string;
    size: string;
    base64: string;
    previewUrl?: string;
  } | null>(null);
  const [activePresetDoc, setActivePresetDoc] = useState<PreloadedDoc | null>(null);
  const [customNotes, setCustomNotes] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [researchOutput, setResearchOutput] = useState<string>('');
  const [sources, setSources] = useState<any[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showScanner, setShowScanner] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const studyTypes = [
    {
      id: 'comprehensive_study',
      titleEn: 'Comprehensive Forensic & Statutory Study',
      titleAr: 'دراسة قانونية وبحث جنائي شامل (المرسوم 53/2023)',
      titleBn: 'পূর্ণাঙ্গ ফরেনসিক ও আইনি বিচারিক গবেষণা',
      descriptionEn: 'Full 360° breakdown: facts, legal articles, discrepancies, and court strategy.'
    },
    {
      id: 'judgment_audit',
      titleEn: 'Judicial Judgment & Order Analysis',
      titleAr: 'تحليل أحكام وقرارات المحكمة وأوامر الحضور',
      titleBn: 'আদালতের রায়, রুলিং ও সমন নোটিশ বিশ্লেষণ',
      descriptionEn: 'Analyze legal standing, jurisdictional defenses, and appellate merits.'
    },
    {
      id: 'fraud_discrepancy',
      titleEn: 'Discrepancy, Forgery & Contamination Audit',
      titleAr: 'كشف التناقضات والتزوير وتلويث السجلات المحاسبية',
      titleBn: 'রেকর্ড টেম্পারিং ও জালিয়াতি অডিট',
      descriptionEn: 'Uncover third-party debts, retroactive insertions, and timeline mismatches.'
    },
    {
      id: 'court_cross_examination',
      titleEn: 'Court Defense & Judge Cross-Examination Questions',
      titleAr: 'صياغة دفوع المحكمة وأسئلة استجواب الخصم أمام القاضي',
      titleBn: 'বিচারকের সামনে শুনানির প্রশ্ন ও জেরা প্রস্তুতি',
      descriptionEn: 'Actionable questions for the presiding judge to corner the employer.'
    }
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      alert(lang === 'bn' ? 'ফাইলের সর্বোচ্চ আকার ২০ মেগাবাইট।' : 'File size cannot exceed 20 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1] || '';
      setUploadedFile({
        name: file.name,
        type: file.type || 'application/octet-stream',
        size: `${(file.size / 1024).toFixed(1)} KB`,
        base64: base64,
        previewUrl: file.type.startsWith('image/') ? result : undefined
      });
      setActivePresetDoc(null);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (doc: PreloadedDoc) => {
    setActivePresetDoc(doc);
    // Convert sample text to base64 for submission
    const base64 = btoa(unescape(encodeURIComponent(doc.sampleText)));
    setUploadedFile({
      name: doc.fileName,
      type: doc.mimeType,
      size: doc.size,
      base64: base64,
      previewUrl: undefined
    });
    setError(null);
  };

  const handleScannedDocument = (doc: { title: string; grayscaleDataUrl: string; mimeType: string }) => {
    const base64 = doc.grayscaleDataUrl.split(',')[1] || '';
    setUploadedFile({
      name: `${doc.title}.jpg`,
      type: 'image/jpeg',
      size: 'Scanned Grayscale Document',
      base64: base64,
      previewUrl: doc.grayscaleDataUrl
    });
    setActivePresetDoc(null);
    setShowScanner(false);
  };

  const handleRunResearch = async () => {
    if (!uploadedFile) {
      setError(
        lang === 'bn'
          ? 'অনুগ্রহ করে কোনো ফাইল আপলোড করুন অথবা নিচের ৫টি প্রমাণের একটি নির্বাচন করুন।'
          : lang === 'ar'
          ? 'يرجى تحميل ملف أو اختيار إحدى وثائق القضية الجاهزة لبدء الدراسة القانونية.'
          : 'Please upload a file or select one of the preloaded case documents.'
      );
      return;
    }

    setLoading(true);
    setError(null);
    setResearchOutput('');
    setSources([]);

    try {
      const response = await fetch('/api/ai/research-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: uploadedFile.base64,
          mimeType: uploadedFile.type,
          fileName: uploadedFile.name,
          studyType: selectedStudyType,
          customNotes: customNotes,
          language: lang
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate legal research study');
      }

      setResearchOutput(data.text || '');
      setSources(data.sources || []);
    } catch (err: any) {
      console.error('Research error:', err);
      setError(err.message || 'An error occurred during legal study generation.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(researchOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const element = document.createElement('a');
    const file = new Blob([researchOutput], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `Legal_Research_Study_${uploadedFile?.name || 'Document'}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <span className="p-1 rounded bg-amber-500/10 text-amber-700 font-bold">Oman RD 53/2023</span>
              <span>·</span>
              <span>AI Judicial Research & Judgment Study Engine</span>
              <span>·</span>
              <span>Evidence Forensic Verification</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
              <Scale className="w-7 h-7 text-amber-600 shrink-0" />
              <span>
                {lang === 'bn'
                  ? 'লিগ্যাল ফাইল ও রায় রিসার্চ ল্যাব (Legal Document & Judgment Lab)'
                  : lang === 'ar'
                  ? 'مختبر أبحاث الأحكام والمستندات القضائية المتكامل'
                  : 'Universal Legal Document & Judgment Research Lab'}
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl">
              {lang === 'bn'
                ? 'আদালতের রায়, সমন, ব্যাংক স্টেটমেন্ট, পুলিশ রিপোর্ট, বা হাতের লেখার ডায়েরি আপলোড করে ওমান শ্রম আইন (Royal Decree 53/2023) অনুযায়ী তাত্ক্ষণিক আইনি মূল্যায়ন, সারসংক্ষেপ ও বিচারিক পরামর্শ পান।'
                : lang === 'ar'
                ? 'ارفع أي مستند، حكم قضائي، كشف بنكي، صورة عقد، أو بلاغ شرطة لإجراء دراسة قانونية معمقة واستخراج الدفوع والثغرات وفق المرسوم السلطاني 53/2023.'
                : 'Upload any PDF, judgment, bank statement, or photo to extract key legal facts, statutory citations under RD 53/2023, and court cross-examination strategies.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowScanner(true)}
              className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg flex items-center gap-2 shadow-2xs transition-colors"
            >
              <Camera className="w-4 h-4 text-amber-400" />
              <span>{lang === 'bn' ? 'ক্যামেরা স্ক্যানার' : lang === 'ar' ? 'ماسح المستندات' : 'Camera Scanner'}</span>
            </button>
          </div>
        </div>

        {/* 5 Quick Real Case Preloaded Documents */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-amber-600" />
              <span>
                {lang === 'bn'
                  ? 'মামলার ৫টি প্রস্তুতকৃত মূল প্রমাণ (ক্লিক করে তাত্ক্ষণিক রিসার্চ করুন):'
                  : lang === 'ar'
                  ? 'وثائق وأحكام القضية الجاهزة للاختبار الفوري والدراسة:'
                  : 'Preloaded Case Evidence & Judgments (Click to test instantly):'}
              </span>
            </h3>
            <span className="text-[11px] text-slate-400 font-mono">5 Presets</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {PRELOADED_CASE_DOCS.map((doc) => {
              const isSelected = activePresetDoc?.id === doc.id;
              return (
                <button
                  key={doc.id}
                  onClick={() => handleSelectPreset(doc)}
                  className={`p-2.5 rounded-lg border text-left transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'border-[#0b1f3a] bg-blue-50/60 ring-2 ring-[#0b1f3a]/20 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50 hover:bg-white'
                  }`}
                >
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
                      {doc.category}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                      {lang === 'bn' ? doc.titleBn : lang === 'ar' ? doc.titleAr : doc.titleEn}
                    </h4>
                  </div>
                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span>{doc.size}</span>
                    <span className="text-blue-700 font-semibold">{isSelected ? '✓ Loaded' : 'Load Doc'}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Research Workspace: 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Upload & Configuration Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* File Upload Box */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between">
              <span>{lang === 'bn' ? '১. ফাইল বা ছবি আপলোড করুন' : lang === 'ar' ? '1. رفع الملف أو المستند' : '1. Upload Document or Image'}</span>
              {uploadedFile && (
                <button
                  onClick={() => {
                    setUploadedFile(null);
                    setActivePresetDoc(null);
                  }}
                  className="text-xs text-red-600 hover:text-red-700 font-medium flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              )}
            </h3>

            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,.doc,.docx"
              className="hidden"
            />

            {!uploadedFile ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-amber-500 rounded-xl p-6 text-center cursor-pointer bg-slate-50/50 hover:bg-amber-50/20 transition-all"
              >
                <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-3">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="font-bold text-sm text-slate-800">
                  {lang === 'bn' ? 'ফাইল সিলেক্ট করতে এখানে ক্লিক করুন' : lang === 'ar' ? 'انقر هنا لاختيار ملف من جهازك' : 'Click to browse or drop file here'}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  PDF, JPG, PNG, WEBP, DOCX up to 20 MB
                </div>
                <div className="text-[11px] text-slate-400 mt-2 font-mono">
                  Court Orders · WPS Statements · Absconding Slips · Diaries
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-700 shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {uploadedFile.name}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      {uploadedFile.size} · {uploadedFile.type}
                    </div>
                  </div>
                </div>

                {uploadedFile.previewUrl && (
                  <div className="relative rounded-lg overflow-hidden border border-slate-200 max-h-48 bg-slate-900 flex items-center justify-center">
                    <img
                      src={uploadedFile.previewUrl}
                      alt="Uploaded Document Preview"
                      className="max-h-48 object-contain w-full"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Study Mode Selector */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-800 block">
                {lang === 'bn' ? '২. আইনি গবেষণার ধরন নির্বাচন করুন:' : lang === 'ar' ? '2. نوع الدراسة والبحث المطلوب:' : '2. Select Research Study Focus:'}
              </label>

              <div className="space-y-1.5">
                {studyTypes.map((st) => (
                  <label
                    key={st.id}
                    className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer text-xs transition-colors ${
                      selectedStudyType === st.id
                        ? 'border-[#0b1f3a] bg-blue-50/50 text-[#0b1f3a] font-semibold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="studyType"
                      checked={selectedStudyType === st.id}
                      onChange={() => setSelectedStudyType(st.id)}
                      className="mt-0.5 text-amber-600 focus:ring-amber-500"
                    />
                    <div>
                      <div className="font-bold">
                        {lang === 'bn' ? st.titleBn : lang === 'ar' ? st.titleAr : st.titleEn}
                      </div>
                      <div className="text-[11px] text-slate-500 font-normal">
                        {st.descriptionEn}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Specific Instructions / User Notes */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-800 block">
                {lang === 'bn' ? '৩. আপনার নির্দিষ্ট প্রশ্ন বা নোট (ঐচ্ছিক):' : lang === 'ar' ? '3. ملاحظاتك أو استفساراتك الخاصة (اختياري):' : '3. Specific Question or Custom Focus (Optional):'}
              </label>
              <textarea
                value={customNotes}
                onChange={(e) => setCustomNotes(e.target.value)}
                placeholder={
                  lang === 'bn'
                    ? 'যেমন: এই রসিদের তারিখ এবং শ্রম আইনের ১১৪ ধারার সাথে এর সম্পর্ক কী?'
                    : lang === 'ar'
                    ? 'مثال: هل هذا البلاغ باطل لصدوره أثناء الشكوى؟ وما هي المادة الواجبة التطبيق؟'
                    : 'e.g., Does this notice violate Article 114? What questions should we ask the employer in court?'
                }
                rows={3}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0b1f3a] focus:border-transparent"
              />
            </div>

            {/* Action Button */}
            <button
              onClick={handleRunResearch}
              disabled={loading}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all ${
                loading
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-[#0b1f3a] hover:bg-slate-800 text-white active:scale-98'
              }`}
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                  <span>
                    {lang === 'bn' ? 'ফরেনসিক আইনি বিশ্লেষণ চলছে...' : lang === 'ar' ? 'جارٍ فحص المستند وإعداد الدراسة القضائية...' : 'Conducting Forensic Legal Research...'}
                  </span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>
                    {lang === 'bn' ? 'গবেষণা ও সারসংক্ষেপ তৈরি করুন' : lang === 'ar' ? 'بدء التحليل وإعداد تقرير المحكمة' : 'Generate Legal Study & Court Brief'}
                  </span>
                </>
              )}
            </button>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{error}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Research Study Report & Findings (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs min-h-[560px] flex flex-col justify-between">
            <div>
              {/* Report Header Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
                    📜
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900">
                      {lang === 'bn' ? 'আইনি গবেষণা রিপোর্ট ও সারসংক্ষেপ' : lang === 'ar' ? 'تقرير الدراسة والتقييم القضائي' : 'Forensic Study & Judicial Report'}
                    </h3>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {uploadedFile ? `Examining: ${uploadedFile.name}` : 'Awaiting document upload or preset selection'}
                    </div>
                  </div>
                </div>

                {researchOutput && (
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleCopy}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy'}</span>
                    </button>
                    <button
                      onClick={handleDownloadTxt}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export TXT</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Report Content Body */}
              <div className="mt-5">
                {loading ? (
                  <div className="py-20 text-center space-y-4">
                    <div className="w-12 h-12 rounded-full border-4 border-slate-200 border-t-[#0b1f3a] animate-spin mx-auto" />
                    <div className="space-y-1">
                      <div className="text-sm font-bold text-slate-800">
                        {lang === 'bn' ? 'ওমান শ্রম আইনের ভিত্তিতে নথি পরীক্ষা হচ্ছে...' : lang === 'ar' ? 'جارٍ التدقيق الجنائي ومطابقة مواد قانون العمل العماني...' : 'Auditing against Oman Labour Law & Case Precedents...'}
                      </div>
                      <div className="text-xs text-slate-500 font-mono">
                        Checking RD 53/2023 Arts 6, 37, 55, 58, 114, 120 · Bank Muscat WPS reconciliation
                      </div>
                    </div>
                  </div>
                ) : researchOutput ? (
                  <div className="space-y-6">
                    {/* Formatted Output */}
                    <div className="prose prose-slate max-w-none text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-sans bg-slate-50/50 p-5 rounded-xl border border-slate-200/80 text-slate-800">
                      {researchOutput}
                    </div>

                    {/* Sources from Search Grounding */}
                    {sources.length > 0 && (
                      <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-200/80 space-y-2">
                        <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                          <span>
                            {lang === 'bn' ? 'যাচাইকৃত ওমানি আইনি সূত্রসমূহ (Verified Legal Grounding):' : lang === 'ar' ? 'المصادر والقرارات الرسمية المعتمدة:' : 'Official Grounding & Legal Sources:'}
                          </span>
                        </span>
                        <div className="space-y-1">
                          {sources.map((src, i) => (
                            <a
                              key={i}
                              href={src.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="text-xs text-blue-700 hover:underline flex items-center gap-1 truncate"
                            >
                              <ExternalLink className="w-3 h-3 shrink-0" />
                              <span>{src.title || src.uri}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="py-16 text-center space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto text-2xl">
                      ⚖️
                    </div>
                    <div className="text-sm font-bold text-slate-700">
                      {lang === 'bn' ? 'কোনো স্টাডি তৈরি করা হয়নি' : lang === 'ar' ? 'بانتظار المستند لإجراء الدراسة' : 'No research study generated yet'}
                    </div>
                    <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                      {lang === 'bn'
                        ? 'বাম পাশের আপলোড বক্সে আপনার আদালতের ফাইলটি আপলোড করুন অথবা উপরের ৫টি প্রমাণের যেকোনো একটিতে ক্লিক করে "গবেষণা ও সারসংক্ষেপ তৈরি করুন" বাটনে চাপ দিন।'
                        : lang === 'ar'
                        ? 'اختر إحدى وثائق القضية الجاهزة من الأعلى أو قم برفع حكم المحكمة أو كشف الحساب البنكي لعرض التحليل الجنائي والقانوني هنا.'
                        : 'Select any preloaded document above or upload your own legal filing to generate an instant statutory case study.'}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Strategic Action Strip */}
            {researchOutput && (
              <div className="pt-5 mt-6 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-500 font-medium">
                  {lang === 'bn' ? 'এই রিপোর্টটি সরাসরি আদালতের পিটিশনে সংযুক্ত করুন:' : lang === 'ar' ? 'تضمين هذه المخرجات في المستندات الرسمية:' : 'Forward findings directly into court documents:'}
                </div>

                <div className="flex items-center gap-2">
                  {onForwardToPetition && (
                    <button
                      onClick={() => onForwardToPetition(researchOutput)}
                      className="px-3.5 py-2 bg-[#0b1f3a] text-white hover:bg-slate-800 text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <FileCheck2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>{lang === 'bn' ? 'আদালতের পিটিশনে পাঠান' : lang === 'ar' ? 'إرسال لمذكرة المحكمة (A4)' : 'Send to Court Petition'}</span>
                    </button>
                  )}

                  {onForwardToAILab && (
                    <button
                      onClick={() => onForwardToAILab(researchOutput)}
                      className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'এআই ল্যাবে পাঠান' : lang === 'ar' ? 'تحويل لمختبر AI' : 'Send to AI Lab'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Embedded Scanner Modal if triggered */}
      {showScanner && (
        <DocumentScannerModal
          isOpen={showScanner}
          onClose={() => setShowScanner(false)}
          onCaptureDocument={handleScannedDocument}
          lang={lang}
        />
      )}
    </div>
  );
};
