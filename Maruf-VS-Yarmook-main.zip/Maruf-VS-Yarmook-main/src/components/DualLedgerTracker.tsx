import React, { useState, useEffect, useMemo } from 'react';
import { BookOpenCheck, Plus, Trash2, Filter, AlertCircle, FileSpreadsheet, ArrowUpDown } from 'lucide-react';
import { Language } from '../data/translations';
import { LedgerEntry, LedgerType } from '../types/forensic';
import { INITIAL_LEDGER_ENTRIES } from '../data/forensicData';

interface DualLedgerTrackerProps {
  lang: Language;
}

export const DualLedgerTracker: React.FC<DualLedgerTrackerProps> = ({ lang }) => {
  const [entries, setEntries] = useState<LedgerEntry[]>(() => {
    try {
      const saved = localStorage.getItem('marufedge_v1_ledger');
      return saved ? JSON.parse(saved) : INITIAL_LEDGER_ENTRIES;
    } catch {
      return INITIAL_LEDGER_ENTRIES;
    }
  });

  // Filter state
  const [filterType, setFilterType] = useState<string>('ALL');

  // New entry form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0]);
  const [newSales, setNewSales] = useState<number>(0);
  const [newDeposit, setNewDeposit] = useState<number>(0);
  const [newExpenses, setNewExpenses] = useState<number>(0);
  const [newDeduction, setNewDeduction] = useState<number>(0);
  const [newType, setNewType] = useState<LedgerType>('HABIBUR_PERSONAL');
  const [newNote, setNewNote] = useState('');

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('marufedge_v1_ledger', JSON.stringify(entries));
    } catch {
      // quota error or private mode
    }
  }, [entries]);

  // Computed live preview of short_amount
  const computedShortAmount = Math.max(0, Number((newSales - newDeposit - newExpenses).toFixed(3)));

  // 3 Required Metric Cards
  const stats = useMemo(() => {
    let personalDeductions = 0;
    let corporateLiabilities = 0;

    entries.forEach((entry) => {
      if (entry.ledger_type === 'HABIBUR_PERSONAL') {
        personalDeductions += entry.deduction || 0;
      } else if (entry.ledger_type === 'OWNER_CORPORATE') {
        corporateLiabilities += (entry.expenses_paid || 0) + (entry.deduction || 0);
      }
    });

    return {
      personalDeductions,
      corporateLiabilities,
      totalCount: entries.length
    };
  }, [entries]);

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();

    const short_amount = Number((newSales - newDeposit - newExpenses).toFixed(3));

    const newEntry: LedgerEntry = {
      id: `led-${Date.now()}`,
      date: newDate,
      total_sales: Number(newSales.toFixed(3)),
      bank_deposit: Number(newDeposit.toFixed(3)),
      expenses_paid: Number(newExpenses.toFixed(3)),
      deduction: Number(newDeduction.toFixed(3)),
      ledger_type: newType,
      note: newNote.trim(),
      short_amount: short_amount > 0 ? short_amount : 0
    };

    setEntries([newEntry, ...entries]);

    // Reset inputs
    setNewSales(0);
    setNewDeposit(0);
    setNewExpenses(0);
    setNewDeduction(0);
    setNewNote('');
    setShowAddForm(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm(lang === 'bn' ? 'এই লেজার এন্ট্রি মুছে ফেলতে চান?' : lang === 'ar' ? 'هل تريد حذف هذا القيد بالتأكيد؟' : 'Delete this entry?')) {
      setEntries(entries.filter((x) => x.id !== id));
    }
  };

  const filteredEntries = useMemo(() => {
    if (filterType === 'ALL') return entries;
    return entries.filter((x) => x.ledger_type === filterType);
  }, [entries, filterType]);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <BookOpenCheck className="w-3.5 h-3.5 text-amber-600" />
              <span>Section 7 · Dual-Ledger Separation Protocol</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'ডুয়াল-লেজার ট্র্যাকার (ব্যক্তিগত বনাম করপোরেট দায়)' : lang === 'ar' ? 'متتبع الدفتر المزدوج (شخصي مقابل ديون الشركة)' : 'Dual-Ledger Tracker (Personal vs Corporate)'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'মারুফের ব্যক্তিগত আয়ের বিপরীতে কোম্পানির জোরপূর্বক চাপানো ঘাটতি ও খরচ আলাদা করে হিসাব সংরক্ষণের ফুল সিআরইউডি (CRUD) সিস্টেম।'
                : lang === 'ar'
                ? 'فصل جنائي حاسم بين المسحوبات الشخصية للعامل ومصروفات الشركة التشغيلية لمنع التلاعب الحسابي.'
                : 'Definitive forensic demarcation between worker personal receipts and employer corporate operating expenses.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-amber-400" />
              <span>{showAddForm ? 'Close Form' : 'Add Ledger Entry'}</span>
            </button>
          </div>
        </div>

        {/* 3 Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          <div className="p-4 rounded-xl bg-blue-50 border border-blue-200">
            <div className="text-xs font-bold text-blue-900 uppercase tracking-wider">
              {lang === 'bn' ? 'মারুফের ব্যক্তিগত বেতন কর্তন' : lang === 'ar' ? 'إجمالي الخصم الشخصي من الراتب' : 'Personal Deductions Total'}
            </div>
            <div className="text-2xl font-bold font-mono text-blue-950 mt-1 tabular-nums">
              {stats.personalDeductions.toFixed(3)} <span className="text-xs font-sans text-blue-700">OMR</span>
            </div>
            <div className="text-[11px] text-blue-700 mt-1">HABIBUR_PERSONAL entries</div>
          </div>

          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
            <div className="text-xs font-bold text-amber-900 uppercase tracking-wider">
              {lang === 'bn' ? 'কোম্পানির চাপানো করপোরেট দেনা' : lang === 'ar' ? 'التزامات ومصاريف الشركة المقحمة' : 'Corporate Liabilities Total'}
            </div>
            <div className="text-2xl font-bold font-mono text-amber-950 mt-1 tabular-nums">
              {stats.corporateLiabilities.toFixed(3)} <span className="text-xs font-sans text-amber-700">OMR</span>
            </div>
            <div className="text-[11px] text-amber-800 mt-1">OWNER_CORPORATE expenses</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              {lang === 'bn' ? 'মোট সংরক্ষিত লেজার এন্ট্রি' : lang === 'ar' ? 'إجمالي قيود اليومية الموثقة' : 'Total Entries Logged'}
            </div>
            <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
              {stats.totalCount} <span className="text-xs font-sans text-slate-500">records</span>
            </div>
            <div className="text-[11px] text-emerald-700 mt-1 font-semibold">✓ Auto-saved in localStorage</div>
          </div>
        </div>
      </div>

      {/* Add New Entry Form */}
      {showAddForm && (
        <form onSubmit={handleAddEntry} className="bg-white rounded-xl border border-amber-300 p-6 shadow-sm space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'bn' ? 'নতুন লেজার এন্ট্রি যুক্ত করুন' : lang === 'ar' ? 'إضافة قيد محاسبي جديد' : 'Record New Transaction Entry'}
            </h3>
            <span className="text-xs text-amber-800 font-mono">
              Computed Short: {computedShortAmount.toFixed(3)} OMR
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Date</label>
              <input
                type="date"
                required
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-slate-50 text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Total Sales (OMR)</label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={newSales}
                onChange={(e) => setNewSales(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Bank Deposit (OMR)</label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={newDeposit}
                onChange={(e) => setNewDeposit(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Expenses Paid (OMR)</label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={newExpenses}
                onChange={(e) => setNewExpenses(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Salary Deduction (OMR)</label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={newDeduction}
                onChange={(e) => setNewDeduction(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Ledger Type</label>
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as LedgerType)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded font-semibold text-slate-900 bg-white"
              >
                <option value="HABIBUR_PERSONAL">HABIBUR_PERSONAL</option>
                <option value="OWNER_CORPORATE">OWNER_CORPORATE</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1 text-xs">Note / Narrative / Voucher Ref</label>
            <input
              type="text"
              required
              placeholder="e.g., Stamped Bank Muscat receipt BM-88419, freight charge, etc."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded text-xs text-slate-900"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded shadow-xs"
            >
              Save Transaction
            </button>
          </div>
        </form>
      )}

      {/* Table & Filtering */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500">Filter Ledger:</span>
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                filterType === 'ALL' ? 'bg-[#0b1f3a] text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All ({entries.length})
            </button>
            <button
              onClick={() => setFilterType('HABIBUR_PERSONAL')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                filterType === 'HABIBUR_PERSONAL' ? 'bg-blue-700 text-white' : 'bg-blue-50 text-blue-900 hover:bg-blue-100'
              }`}
            >
              Personal
            </button>
            <button
              onClick={() => setFilterType('OWNER_CORPORATE')}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${
                filterType === 'OWNER_CORPORATE' ? 'bg-amber-600 text-white' : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
              }`}
            >
              Corporate
            </button>
          </div>

          <span className="text-xs text-slate-500 font-mono">
            Showing {filteredEntries.length} records
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#0b1f3a] text-white font-semibold">
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Ledger Type</th>
                <th className="py-2.5 px-3 text-right">Sales</th>
                <th className="py-2.5 px-3 text-right">Deposit</th>
                <th className="py-2.5 px-3 text-right">Expenses</th>
                <th className="py-2.5 px-3 text-right">Short</th>
                <th className="py-2.5 px-3 text-right">Deduction</th>
                <th className="py-2.5 px-4">Narrative</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700 font-mono">
              {filteredEntries.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2.5 px-3 whitespace-nowrap text-slate-900">{row.date}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap font-sans">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        row.ledger_type === 'HABIBUR_PERSONAL'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {row.ledger_type}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right tabular-nums">{row.total_sales.toFixed(3)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-emerald-700 font-semibold">{row.bank_deposit.toFixed(3)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums">{row.expenses_paid.toFixed(3)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-red-600 font-bold">{row.short_amount.toFixed(3)}</td>
                  <td className="py-2.5 px-3 text-right tabular-nums text-amber-700 font-bold">{row.deduction.toFixed(3)}</td>
                  <td className="py-2.5 px-4 font-sans text-xs text-slate-600 max-w-xs truncate" title={row.note}>
                    {row.note}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => handleDelete(row.id)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded"
                      title="Delete entry"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
