import React from 'react';
import {
  LayoutDashboard,
  FileSpreadsheet,
  AlertOctagon,
  FolderArchive,
  BookOpenCheck,
  Binary,
  Bot,
  Calculator,
  Mail,
  Scale,
  Settings,
  DatabaseBackup,
  X,
  FileCheck2,
  Mic,
  Calendar
} from 'lucide-react';
import { Language } from '../data/translations';

interface SidebarProps {
  currentSection: string;
  onSelectSection: (section: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  lang: Language;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  onSelectSection,
  isOpenMobile,
  onCloseMobile,
  lang
}) => {
  const groups = [
    {
      id: 'main',
      titleEn: 'Main Navigation',
      titleAr: 'الرئيسية',
      titleBn: 'মূল সেকশন',
      items: [
        { id: 'dashboard', icon: <LayoutDashboard className="w-4 h-4" />, labelEn: '1. Dashboard', labelAr: '1. لوحة التحكم', labelBn: '১. কেস ড্যাশবোর্ড' },
        { id: 'case-timeline', icon: <Calendar className="w-4 h-4" />, labelEn: '1b. Case Timeline (Recharts)', labelAr: '1ب. المخطط الزمني (Recharts)', labelBn: '১খ. বিচারিক টাইমলাইন (Recharts)' },
        { id: 'forensic-audit', icon: <FileSpreadsheet className="w-4 h-4" />, labelEn: '2. Forensic Audit', labelAr: '2. التقرير الجنائي', labelBn: '২. ফরেনসিক অডিট (1,947 OMR)' },
        { id: 'statutory-violations', icon: <AlertOctagon className="w-4 h-4" />, labelEn: '3. Statutory Violations', labelAr: '3. المخالفات القانونية', labelBn: '৩. ৫টি প্রধান আইনি লঙ্ঘন' }
      ]
    },
    {
      id: 'evidence',
      titleEn: 'Evidence & Ledgers',
      titleAr: 'الأدلة والسجلات',
      titleBn: 'প্রমাণ ও লেজার খতিয়ান',
      items: [
        { id: 'evidence-vault', icon: <FolderArchive className="w-4 h-4" />, labelEn: '4. Evidence Vault', labelAr: '4. مخزن الأدلة الرقمية', labelBn: '৪. ডিজিটাল এভিডেন্স ভল্ট' },
        { id: 'dual-ledger', icon: <BookOpenCheck className="w-4 h-4" />, labelEn: '5. Dual-Ledger Tracker', labelAr: '5. الدفتر المزدوج (CRUD)', labelBn: '৫. ডুয়াল-লেজার ট্র্যাকার' },
        { id: 'sub-ledger-contamination', icon: <Binary className="w-4 h-4" />, labelEn: '6. Sub-Ledger Tampering', labelAr: '6. تلوث السجل الفرعي', labelBn: '৬. সাব-লেজার টেম্পারিং প্রমাণ' }
      ]
    },
    {
      id: 'analysis',
      titleEn: 'AI & Calculators',
      titleAr: 'التحليل والذكاء الاصطناعي',
      titleBn: 'এআই ও আইনি ক্যালকুলেটর',
      items: [
        { id: 'ai-lab', icon: <Bot className="w-4 h-4" />, labelEn: '7. AI Lab (Gemini Engine)', labelAr: '7. مختبر الذكاء الاصطناعي', labelBn: '৭. এআই লিগ্যাল ল্যাব' },
        { id: 'ai-research-lab', icon: <FileCheck2 className="w-4 h-4" />, labelEn: '7d. Legal Document & Judgment Lab', labelAr: '7د. مختبر أبحاث الأحكام والمستندات', labelBn: '৭ঘ. লিগ্যাল ফাইল ও রায় রিসার্চ ল্যাব' },
        { id: 'audio-transcribe', icon: <Mic className="w-4 h-4" />, labelEn: '7b. Audio Transcriber', labelAr: '7ب. تفريغ الصوت (gemini-3.5-transcribe)', labelBn: '৭খ. অডিও ট্রান্সক্রিপশন (Gemini)' },
        { id: 'law-advisor', icon: <Scale className="w-4 h-4" />, labelEn: '7c. Oman Law AI Advisor', labelAr: '7ج. مستشار قانون العمل (Search)', labelBn: '৭গ. ওমান শ্রম আইন অ্যাডভাইজার' },
        { id: 'calculator', icon: <Calculator className="w-4 h-4" />, labelEn: '8. Statutory Calculator', labelAr: '8. حاسبة المستحقات (EOSB)', labelBn: '৮. ক্ষতিপূরণ ক্যালকুলেটর' }
      ]
    },
    {
      id: 'letters',
      titleEn: 'Court & Strategic Letters',
      titleAr: 'الخطابات والمذكرات',
      titleBn: 'আদালতের পত্র ও আবেদন',
      items: [
        { id: 'strategic-letters', icon: <Mail className="w-4 h-4" />, labelEn: '9. Strategic Letters', labelAr: '9. الخطابات والتظلمات (Track 1/2)', labelBn: '৯. স্ট্র্যাটেজিক লেটার্স (১ ও ২)' },
        { id: 'court-petition', icon: <Scale className="w-4 h-4" />, labelEn: '10. Court Petition (A4)', labelAr: '10. مذكرة المحكمة وحافظة الأدلة', labelBn: '১০. আদালতের পিটিশন (A4)' }
      ]
    },
    {
      id: 'system',
      titleEn: 'System & Backup',
      titleAr: 'النظام والنسخ الاحتياطي',
      titleBn: 'সিস্টেম ও ব্যাকআপ',
      items: [
        { id: 'settings', icon: <Settings className="w-4 h-4" />, labelEn: '11. Settings & Profile', labelAr: '11. إعدادات المستخدم', labelBn: '১১. সেটিংস ও প্রোফাইল' },
        { id: 'backup', icon: <DatabaseBackup className="w-4 h-4" />, labelEn: '12. Backup & Export JSON', labelAr: '12. النسخ الاحتياطي واستيراد', labelBn: '১২. JSON এক্সপোর্ট / ব্যাকআপ' }
      ]
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-950/60 z-40 lg:hidden backdrop-blur-2xs no-print"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 z-50 w-72 bg-[#0b1f3a] text-slate-200 border-r border-slate-800 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        } ${lang === 'ar' ? 'right-0 border-l border-r-0' : 'left-0'} no-print`}
      >
        {/* Sidebar Brand Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-black">
              ⚖️
            </div>
            <div>
              <div className="font-extrabold text-sm text-white tracking-tight">
                MarufEdge Forensic Lab
              </div>
              <div className="text-[10px] text-amber-300/80 font-mono">
                Oman Labour Law RD 53/2023
              </div>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="lg:hidden p-1 text-slate-400 hover:text-white rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Litigant Quick Summary Chip */}
        <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/80 text-[11px] font-mono flex items-center justify-between text-slate-400">
          <div>
            <span className="text-amber-400 font-bold">Maruf</span> vs <span className="text-slate-300">Al Yarmook</span>
          </div>
          <div className="text-[10px] px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-800/40">
            CRT2601-3344
          </div>
        </div>

        {/* Grouped Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5 text-xs">
          {groups.map((group) => (
            <div key={group.id} className="space-y-1">
              <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {lang === 'bn' ? group.titleBn : lang === 'ar' ? group.titleAr : group.titleEn}
              </div>
              {group.items.map((item) => {
                const isActive = currentSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectSection(item.id);
                      onCloseMobile();
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all ${
                      isActive
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white font-medium'
                    }`}
                  >
                    <span className={isActive ? 'text-slate-950' : 'text-amber-400'}>
                      {item.icon}
                    </span>
                    <span className="truncate">
                      {lang === 'bn' ? item.labelBn : lang === 'ar' ? item.labelAr : item.labelEn}
                    </span>
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Bottom Fast Links */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/40 text-[11px] text-slate-400 flex items-center justify-between">
          <span className="font-mono text-emerald-400 font-semibold">100% Offline Ready</span>
          <span className="font-mono text-slate-400">v2.4.0</span>
        </div>
      </aside>
    </>
  );
};
