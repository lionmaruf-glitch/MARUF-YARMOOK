import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Printer,
  Sparkles,
  Scale,
  Building2,
  FileText,
  AlertOctagon,
  CheckCircle2,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { CASE_METADATA } from '../data/evidenceData';
import { CaseTimelineChart, CASE_MILESTONES, MilestoneEvent } from './CaseTimelineChart';

interface CaseTimelineViewProps {
  lang: Language;
  onNavigate: (section: string) => void;
  onSendToAILab?: (prompt: string) => void;
}

export const CaseTimelineView: React.FC<CaseTimelineViewProps> = ({
  lang,
  onNavigate,
  onSendToAILab
}) => {
  const t = TRANSLATIONS[lang];
  const [selectedMilestone, setSelectedMilestone] = useState<MilestoneEvent | null>(null);

  const handleInspectInLab = (m: MilestoneEvent) => {
    const prompt = `قم بإجراء دراسة قانونية وبحث جنائي معمق لواقعة (${m.dateStr}: ${m.labelAr})، الرقم المرجعي (${m.caseRef})، والسند القانوني من المرسوم السلطاني 53/2023 (${m.statutoryArticle}).\n\nتفاصيل الواقعة:\n"${m.summaryAr}"\n\nالمطلوب: بيان حجية هذه الواقعة لإثبات بطلان بلاغ الهروب الكيدي وطلب الإلزام بكامل مبلغ 7,642 ر.ع.`;
    if (onSendToAILab) {
      onSendToAILab(prompt);
      onNavigate('ai-lab');
    } else {
      onNavigate('ai-research-lab');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <span className="text-amber-700 font-bold">Supreme Judicial Council</span>
              <span>·</span>
              <span>Seeb Primary Court (Case CRT2601-3344)</span>
              <span>·</span>
              <span>Barka Court (Case 1005/1215/2026)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {lang === 'bn'
                ? 'মামলার মূল কালানুক্রম ও বিচারিক টাইমলাইন'
                : lang === 'ar'
                ? 'التسلسل الزمني القضائي والمحطات المفصلية للنزاع'
                : 'Case Milestones & Judicial Chronology Overview'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl">
              {lang === 'bn'
                ? '২০১৫ সালের চাকরি শুরু, বারকা শাখা প্রতিষ্ঠা, করোনাকালীন বেতন কর্তন, শ্রম মন্ত্রণালয়ে অভিযোগ এবং সিব আদালতের শুনানি পর্যন্ত রিচার্টস (Recharts) ভিত্তিক পূর্ণাঙ্গ দৃশ্যপট।'
                : lang === 'ar'
                ? 'مخطط بياني تفاعلي باستخدام Recharts يربط كافة الوقائع الجوهرية، المخالفات العمالية، والبلاغات الكيدية، ومواعيد الجلسات القضائية لإثبات تسلسل الأحداث أمام عدالة المحكمة.'
                : 'Interactive Recharts visualization plotting all critical dates, employer breaches, absconding reports, and court dates from 2015 to 2027.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onNavigate('ai-research-lab')}
              className="px-4 py-2 bg-[#0b1f3a] text-white hover:bg-slate-800 text-xs font-bold rounded-lg flex items-center gap-2 shadow-xs transition-colors"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{lang === 'bn' ? 'ফাইল ও রায় রিসার্চ ল্যাব' : lang === 'ar' ? 'مختبر أبحاث الأحكام والملفات' : 'Research Documents Lab'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors no-print"
            >
              <Printer className="w-4 h-4" />
              <span>Print A4</span>
            </button>
          </div>
        </div>

        {/* Quick Statutory Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
              Recruitment & Unbroken Service
            </span>
            <div className="text-sm font-bold text-slate-900 font-mono">July 2015 – Sep 2026</div>
            <div className="text-xs text-emerald-700 font-semibold mt-0.5">11 Years, 2 Months Continuous</div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
              First Ministry Complaint
            </span>
            <div className="text-sm font-bold text-slate-900 font-mono">15/03/2026 (REF2603150080)</div>
            <div className="text-xs text-blue-700 font-semibold mt-0.5">Prior to Absconding Report</div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
              Malicious Absconding Date
            </span>
            <div className="text-sm font-bold text-red-700 font-mono">02/08/2026 (DCA-20260802114)</div>
            <div className="text-xs text-red-600 font-semibold mt-0.5">Art. 114 Direct Violation</div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
              Resident Card Valid Until
            </span>
            <div className="text-sm font-bold text-slate-900 font-mono">06/09/2027 (Civil ID: 103352388)</div>
            <div className="text-xs text-purple-700 font-semibold mt-0.5">Full Lawful Residency Standing</div>
          </div>
        </div>
      </div>

      {/* Main Recharts Interactive Timeline */}
      <CaseTimelineChart
        lang={lang}
        onSelectMilestone={(m) => setSelectedMilestone(m)}
        onNavigateToSection={onNavigate}
      />

      {/* Deep-Dive Procedural Stages */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Scale className="w-5 h-5 text-amber-600" />
          <span>
            {lang === 'bn'
              ? 'বিচারিক ও মন্ত্রণালয়ের ৪টি মূল পর্যায় (Procedural Legal Stages)'
              : lang === 'ar'
              ? 'المراحل القانونية الأربع للدعوى العمالية'
              : 'The Four Distinct Legal Stages of the Dispute'}
          </span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Stage 1 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 relative">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mb-2">
              Phase 1 (2015–2019)
            </span>
            <h4 className="font-bold text-sm text-slate-900 mb-1">
              {lang === 'bn' ? 'চাকরি ও বারকা শাখা বিস্তার' : lang === 'ar' ? 'الخدمة وتأسيس فرع بركاء' : 'Service & Barka Founding'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'bn'
                ? 'শূন্য থেকে বারকা সানাইয়া শাখা প্রতিষ্ঠা, মাসিক ৫৩,০০০ রিয়াল লেনদেন এবং ১৮০+ ক্লায়েন্ট পরিচালনা। যা ম্যানেজার পদমর্যাদা প্রমাণ করে।'
                : 'Building the Barka branch, reaching 53k OMR/month revenue with 180+ clients. Proves de facto managerial capacity.'}
            </p>
          </div>

          {/* Stage 2 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 relative">
            <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full inline-block mb-2">
              Phase 2 (2020–2025)
            </span>
            <h4 className="font-bold text-sm text-slate-900 mb-1">
              {lang === 'bn' ? 'কোভিড লকডাউন ও অবৈধ কর্তন' : lang === 'ar' ? 'تجميد الرواتب وتلوث السجلات' : 'Lockdown Cuts & Contamination'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'bn'
                ? '১২ মাসের বেতন স্থগিত (৩,০০০ OMR), ওরিডু বিল ও কোয়ারেন্টিন কর্তন (১,৪১৭ OMR), এবং নজর ডায়েরিতে অন্যের ঋণ যুক্তকরণ।'
                : '12 months unremitted wages (3,000 OMR), arbitrary deductions (1,417 OMR), and cross-contamination in Nazar diary.'}
            </p>
          </div>

          {/* Stage 3 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 relative">
            <span className="text-xs font-bold text-blue-800 bg-blue-100 px-2 py-0.5 rounded-full inline-block mb-2">
              Phase 3 (Mar–Jul 2026)
            </span>
            <h4 className="font-bold text-sm text-slate-900 mb-1">
              {lang === 'bn' ? 'শ্রম মন্ত্রণালয় ও আপস প্রক্রিয়া' : lang === 'ar' ? 'شكاوى وزارة العمل والتسوية' : 'MOL Filings & Retaliation'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'bn'
                ? '১৫/০৩/২০২৬ এ ১ম অভিযোগ দায়ের। মালিকপক্ষ আপস প্রত্যাখ্যান করে প্রতিহিংসামূলক পলায়ন নোটিশ দেওয়ার চেষ্টা করে যা বাতিল হয়।'
                : 'Complaint REF2603150080 filed. Employer attempted malicious absconding report which was rejected by MOL.'}
            </p>
          </div>

          {/* Stage 4 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 relative">
            <span className="text-xs font-bold text-purple-800 bg-purple-100 px-2 py-0.5 rounded-full inline-block mb-2">
              Phase 4 (Aug 2026–2027)
            </span>
            <h4 className="font-bold text-sm text-slate-900 mb-1">
              {lang === 'bn' ? 'সিব ও বারকা আদালতে চূড়ান্ত বিচার' : lang === 'ar' ? 'الإحالة القضائية والمحاكم' : 'Judicial Adjudication'}
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {lang === 'bn'
                ? 'রেফারাল CTR-2601-33444 এর মাধ্যমে সিব আদালতে মামলা। ৭,৬৪২ OMR ডিক্রি, পাসপোর্ট উদ্ধার ও এনওসি ছাড়পত্রের জন্য প্রস্তুত।'
                : 'Direct transmission to Seeb Primary Court (Case CRT2601-3344) with complete fee waiver under Article 120.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
