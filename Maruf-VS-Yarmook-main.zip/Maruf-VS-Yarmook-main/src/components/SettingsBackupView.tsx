import React, { useState, useEffect } from 'react';
import {
  Settings,
  DatabaseBackup,
  Download,
  Upload,
  Moon,
  Sun,
  Save,
  CheckCircle2,
  ShieldCheck,
  HardDrive,
  Cloud,
  CloudCheck,
  LogIn,
  LogOut,
  Key,
  Sparkles,
  Bot,
  User as UserIcon,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Language } from '../data/translations';
import { AppSettings } from '../types/forensic';
import { CASE_METADATA } from '../data/evidenceData';
import {
  auth,
  signInWithGoogle,
  logOut,
  syncEvidenceToFirestore,
  syncLedgerToFirestore
} from '../firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

interface SettingsBackupViewProps {
  lang: Language;
}

export const SettingsBackupView: React.FC<SettingsBackupViewProps> = ({ lang }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [isSyncingFirestore, setIsSyncingFirestore] = useState<boolean>(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('marufedge_v1_settings');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      name: CASE_METADATA.plaintiff.fullName,
      civilId: CASE_METADATA.plaintiff.civilId,
      workPermit: CASE_METADATA.plaintiff.workPermit,
      crNumber: CASE_METADATA.defendant.crNumber,
      phone: CASE_METADATA.plaintiff.phone,
      theme: 'light'
    };
  });

  // AI API Keys
  const [apiKeys, setApiKeys] = useState<{ gemini: string; openrouter: string; groq: string }>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('marufedge_keys_v1') || '{}');
      return {
        gemini: saved.gemini || '',
        openrouter: saved.openrouter || '',
        groq: saved.groq || ''
      };
    } catch {
      return { gemini: '', openrouter: '', groq: '' };
    }
  });

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [storageBytes, setStorageBytes] = useState(0);

  // Monitor Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Update theme on document
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
  }, [settings.theme]);

  // Storage byte size calculation
  useEffect(() => {
    let total = 0;
    for (let x in localStorage) {
      if (localStorage.hasOwnProperty(x)) {
        total += (localStorage[x].length + x.length) * 2;
      }
    }
    setStorageBytes(total);
  }, [savedSuccess]);

  const handleGoogleSignIn = async () => {
    try {
      setAuthLoading(true);
      await signInWithGoogle();
      setSyncStatusMsg(lang === 'bn' ? 'সফলভাবে গুগল সাইন ইন সম্পন্ন!' : 'تم تسجيل الدخول بنجاح عبر حساب Google');
      setTimeout(() => setSyncStatusMsg(null), 3000);
    } catch (err: any) {
      console.error('Sign-in error:', err);
      alert('Google Sign-In failed: ' + err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logOut();
      setSyncStatusMsg(lang === 'bn' ? 'লগআউট সম্পন্ন হয়েছে' : 'تم تسجيل الخروج');
      setTimeout(() => setSyncStatusMsg(null), 2000);
    } catch (err: any) {
      alert('Sign-out error: ' + err.message);
    }
  };

  const handleManualSyncFirestore = async () => {
    if (!currentUser) {
      alert(lang === 'bn' ? 'ক্লাউড সিঙ্ক করতে প্রথমে গুগল অ্যাকাউন্টে লগইন করুন।' : 'يرجى تسجيل الدخول بحساب Google لمزامنة البيانات في السحابة.');
      return;
    }

    setIsSyncingFirestore(true);
    setSyncStatusMsg(null);
    try {
      const evidenceData = JSON.parse(localStorage.getItem('marufedge_scanned_evidence') || '[]');
      const ledgerData = JSON.parse(localStorage.getItem('marufedge_v1_ledger') || '[]');

      await syncEvidenceToFirestore(currentUser.uid, evidenceData);
      await syncLedgerToFirestore(currentUser.uid, ledgerData);

      setSyncStatusMsg(
        lang === 'bn'
          ? 'ক্লাউড ফায়ারস্টোরে সফলভাবে ব্যাকআপ সিঙ্ক হয়েছে!'
          : lang === 'ar'
          ? 'تمت مزامنة الأدلة والدفاتر بنجاح في قاعدة بيانات Firestore السحابية!'
          : 'All evidence and ledger records synced successfully to Firestore!'
      );
    } catch (err: any) {
      console.error('Firestore sync error:', err);
      setSyncStatusMsg('Sync Error: ' + err.message);
    } finally {
      setIsSyncingFirestore(false);
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      localStorage.setItem('marufedge_v1_settings', JSON.stringify(settings));
      localStorage.setItem('marufedge_keys_v1', JSON.stringify(apiKeys));
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      alert('Failed to save settings: LocalStorage quota exceeded.');
    }
  };

  const handleExportJSON = () => {
    try {
      const exportData = {
        exportedAt: new Date().toISOString(),
        version: 'marufedge_v2_firebase',
        user: currentUser ? { email: currentUser.email, uid: currentUser.uid } : null,
        settings,
        ledger: JSON.parse(localStorage.getItem('marufedge_v1_ledger') || '[]'),
        evidenceChecklist: JSON.parse(localStorage.getItem('maruf_evidence_checklist_v2') || '{}'),
        scannedEvidence: JSON.parse(localStorage.getItem('marufedge_scanned_evidence') || '[]'),
        lang: localStorage.getItem('maruf_lang') || 'bn'
      };

      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportData, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `marufedge-case-backup-${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } catch (err: any) {
      alert(`Export failed: ${err.message}`);
    }
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!window.confirm(lang === 'bn' ? 'বর্তমান ডেটার উপর ব্যাকআপ ফাইল প্রতিস্থাপন করতে চান?' : lang === 'ar' ? 'هل أنت متأكد من استبدال البيانات الحالية بالملف المستورد؟' : 'Replace current data with imported backup?')) {
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.settings) {
          setSettings(parsed.settings);
          localStorage.setItem('marufedge_v1_settings', JSON.stringify(parsed.settings));
        }
        if (parsed.ledger) {
          localStorage.setItem('marufedge_v1_ledger', JSON.stringify(parsed.ledger));
        }
        if (parsed.scannedEvidence) {
          localStorage.setItem('marufedge_scanned_evidence', JSON.stringify(parsed.scannedEvidence));
        }
        if (parsed.evidenceChecklist) {
          localStorage.setItem('maruf_evidence_checklist_v2', JSON.stringify(parsed.evidenceChecklist));
        }
        alert(lang === 'bn' ? 'সফলভাবে ডেটা ইমপোর্ট সম্পন্ন হয়েছে!' : lang === 'ar' ? 'تم استيراد البيانات بنجاح!' : 'Data imported successfully!');
        window.location.reload();
      } catch (err: any) {
        alert(`Invalid JSON format: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="pb-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-600 mb-1">
              <Settings className="w-4 h-4" />
              <span>Full System Settings & Security Vault</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {lang === 'bn' ? 'সিস্টেম সেটিংস, ফায়ারবেস ক্লাউড ও ব্যাকআপ' : lang === 'ar' ? 'إعدادات النظام، سحابة Firebase والنسخ الاحتياطي' : 'System Settings, Firebase Cloud & Security Vault'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'মামলার মেটাডাটা, গুগল সাইন-ইন ও ফায়ারবেস ক্লাউড ব্যাকআপ, বিনামূল্যে এআই এপিআই কি কনফিগারেশন এবং অফলাইন ফাইল রিকভারি।'
                : lang === 'ar'
                ? 'إدارة بيانات الدعوى، تسجيل الدخول عبر Google ومزامنة السحابة (Firestore)، ومفاتيح الذكاء الاصطناعي المجانية.'
                : 'Configure litigant identity parameters, Google Auth with Firestore persistence, AI API key options, and disaster recovery.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Firestore Active</span>
            </span>
          </div>
        </div>

        {/* Storage & Cloud KPI strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <HardDrive className="w-4 h-4 text-blue-600" />
              <span>Offline Local Storage</span>
            </div>
            <div className="text-xl font-bold font-mono text-slate-900 mt-1">
              {(storageBytes / 1024).toFixed(1)} KB
            </div>
            <div className="text-[11px] text-emerald-700 mt-0.5">Protected offline on client</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <CloudCheck className="w-4 h-4 text-emerald-600" />
              <span>Cloud Firestore Database</span>
            </div>
            <div className="text-xs font-mono font-bold text-slate-900 mt-1 truncate">
              {currentUser ? currentUser.email : 'Local Only (Sign In Below)'}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Database ID: gen-lang-client-0766286591</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <DatabaseBackup className="w-4 h-4 text-amber-600" />
              <span>Standalone HTML Engine</span>
            </div>
            <div className="text-xs font-semibold text-amber-900 mt-2">
              <a
                href="/marufedge-forensic-lab.html"
                download="marufedge-forensic-lab.html"
                className="inline-flex items-center gap-1 text-amber-800 hover:text-amber-950 font-bold underline"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Self-Contained File</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* FIREBASE AUTH & FIRESTORE CLOUD PERSISTENCE PANEL */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-600">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                {lang === 'bn' ? 'গুগল সাইন-ইন ও ফায়ারবেস ক্লাউড সিঙ্ক' : lang === 'ar' ? 'تسجيل الدخول ومزامنة سحابة Firebase' : 'Google Authentication & Firestore Cloud Sync'}
              </h2>
              <p className="text-xs text-slate-500">
                Securely persist your case evidence, notes, and dual-ledger entries across devices.
              </p>
            </div>
          </div>

          {currentUser ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-xs">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt="" className="w-7 h-7 rounded-full border border-slate-300" />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700">
                    <UserIcon className="w-3.5 h-3.5" />
                  </div>
                )}
                <div>
                  <div className="font-bold text-slate-900 leading-tight">{currentUser.displayName || 'Authenticated User'}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{currentUser.email}</div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSignOut}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-red-700 bg-slate-100 hover:bg-red-50 rounded-lg flex items-center gap-1 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={authLoading}
              className="px-4 py-2 bg-[#0b1f3a] hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5 text-amber-400" />
              <span>{authLoading ? 'Connecting...' : 'Sign in with Google (Firebase)'}</span>
            </button>
          )}
        </div>

        {/* Sync trigger button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs">
          <div className="text-slate-600">
            {currentUser
              ? 'Your account is linked to Firestore. Click below to push all local evidence & dual-ledger records to cloud storage.'
              : 'Sign in above to enable real-time cloud synchronization for your court filings.'}
          </div>

          {currentUser && (
            <button
              type="button"
              onClick={handleManualSyncFirestore}
              disabled={isSyncingFirestore}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto shrink-0 shadow-sm"
            >
              {isSyncingFirestore ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Syncing to Firestore...</span>
                </>
              ) : (
                <>
                  <CloudCheck className="w-3.5 h-3.5" />
                  <span>Sync Records to Cloud Now</span>
                </>
              )}
            </button>
          )}
        </div>

        {syncStatusMsg && (
          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncStatusMsg}</span>
          </div>
        )}
      </div>

      {/* LITIGANT PROFILE & CASE METADATA FORM */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 mb-1">
          {lang === 'bn' ? 'বাদী ও মামলার মূল মেটাডাটা সম্পাদনা' : lang === 'ar' ? 'تعديل بيانات المدعي وأطراف النزاع' : 'Litigant & Case Parameters'}
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          All calculations, generated court petitions, and statutory memorandums instantly update according to these values.
        </p>

        <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Full Legal Name</label>
              <input
                type="text"
                value={settings.name}
                onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Civil ID Number</label>
              <input
                type="text"
                value={settings.civilId}
                onChange={(e) => setSettings({ ...settings, civilId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-medium focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Work Permit Number</label>
              <input
                type="text"
                value={settings.workPermit}
                onChange={(e) => setSettings({ ...settings, workPermit: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-medium focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Defendant CR Number</label>
              <input
                type="text"
                value={settings.crNumber}
                onChange={(e) => setSettings({ ...settings, crNumber: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-medium focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Registered Phone</label>
              <input
                type="text"
                value={settings.phone}
                onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-medium focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Interface Appearance</label>
              <div className="flex rounded-lg border border-slate-300 p-0.5 bg-slate-50">
                <button
                  type="button"
                  onClick={() => setSettings({ ...settings, theme: 'light' })}
                  className={`flex-1 py-1.5 font-bold rounded flex items-center justify-center gap-1 ${
                    settings.theme === 'light' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span>Light</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSettings({ ...settings, theme: 'dark' })}
                  className={`flex-1 py-1.5 font-bold rounded flex items-center justify-center gap-1 ${
                    settings.theme === 'dark' ? 'bg-[#0b1f3a] text-white shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 text-blue-400" />
                  <span>Dark</span>
                </button>
              </div>
            </div>
          </div>

          {/* AI ENGINE & API KEYS CONFIGURATION */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>AI Providers & Free Server Engine</span>
              </div>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Free Server Proxy Active
              </span>
            </div>

            <p className="text-[11px] text-slate-500">
              The app automatically processes legal queries and transcription using the pre-configured server environment. Optional custom keys can be provided below:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Custom Gemini API Key</label>
                <input
                  type="password"
                  value={apiKeys.gemini}
                  onChange={(e) => setApiKeys({ ...apiKeys, gemini: e.target.value })}
                  placeholder="Leave empty for free server AI"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-slate-900 font-mono text-[11px] bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">OpenRouter Key (Optional)</label>
                <input
                  type="password"
                  value={apiKeys.openrouter}
                  onChange={(e) => setApiKeys({ ...apiKeys, openrouter: e.target.value })}
                  placeholder="sk-or-v1-..."
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-slate-900 font-mono text-[11px] bg-slate-50"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Groq Key (Optional)</label>
                <input
                  type="password"
                  value={apiKeys.groq}
                  onChange={(e) => setApiKeys({ ...apiKeys, groq: e.target.value })}
                  placeholder="gsk_..."
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-slate-900 font-mono text-[11px] bg-slate-50"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-100">
            {savedSuccess ? (
              <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                <span>Settings & API keys saved successfully!</span>
              </span>
            ) : (
              <span className="text-xs text-slate-400">Settings persist in encrypted local storage and sync to Firestore.</span>
            )}

            <button
              type="submit"
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Configuration</span>
            </button>
          </div>
        </form>
      </div>

      {/* BACKUP & DISASTER RECOVERY ACTIONS */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 mb-1">
          {lang === 'bn' ? 'ব্যাকআপ ও ডেটা রিকভারি (JSON Export / Import)' : lang === 'ar' ? 'النسخ الاحتياطي واستعادة البيانات' : 'JSON Backup & Disaster Recovery'}
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          Export your complete evidence catalog, scanned documents, dual-ledger entries, and verification checklist to a secure timestamped JSON file.
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={handleExportJSON}
            className="w-full sm:w-auto px-5 py-2.5 bg-[#0b1f3a] text-white hover:bg-slate-800 text-xs font-bold rounded-lg shadow-2xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-amber-400" />
            <span>Export Complete JSON Backup</span>
          </button>

          <label className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg cursor-pointer flex items-center justify-center gap-2 transition-colors border border-slate-200">
            <Upload className="w-4 h-4 text-slate-600" />
            <span>Import JSON Backup File</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportJSON}
              className="hidden"
            />
          </label>
        </div>
      </div>

    </div>
  );
};
