import React from 'react';
import { Scale, Printer } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';

interface HeaderProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  lang: Language;
  onLangChange: (lang: Language) => void;
  onPrint: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  lang,
  onLangChange,
  onPrint
}) => {
  const t = TRANSLATIONS[lang];

  const navItems = [
    { id: 'dashboard', label: t.navDashboard },
    { id: 'evidence', label: t.navEvidenceVault },
    { id: 'calculator', label: t.navCalculator },
    { id: 'petition', label: t.navPetition },
    { id: 'checklist', label: t.navChecklist },
    { id: 'uploader', label: t.navUploader }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0b1f3a] text-white border-b border-slate-700/60 shadow-md no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Brand Wordmark & Case Badge */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Scale className="w-5 h-5 text-amber-300" />
              </div>
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap">
                  {t.appName}
                </span>
                <span className="text-[11px] text-amber-200/80 font-mono hidden sm:inline-block">
                  Sultanate of Oman · Royal Decree 53/2023
                </span>
              </div>
            </div>
            <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-950/40 border border-red-700/40 text-red-200 text-xs font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
              <span>{t.caseBadge}</span>
            </div>
          </div>

          {/* Zone 2: Navigation Links (Single-line) */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  currentTab === item.id
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Language Selector & Primary Print CTA */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Language Switcher */}
            <div className="flex items-center bg-slate-900/80 p-0.5 rounded-lg border border-slate-700">
              <button
                onClick={() => onLangChange('bn')}
                className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                  lang === 'bn'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="বাংলা ইন্টারফেস"
              >
                বাংলা
              </button>
              <button
                onClick={() => onLangChange('en')}
                className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                  lang === 'en'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="English Interface"
              >
                EN
              </button>
              <button
                onClick={() => onLangChange('ar')}
                className={`px-2.5 py-1 text-xs font-bold rounded transition-colors ${
                  lang === 'ar'
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="الواجهة العربية"
              >
                العربية
              </button>
            </div>

            {/* Print Primary Action */}
            <button
              onClick={onPrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 rounded-lg shadow-sm transition-all whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.printButton}</span>
              <span className="sm:hidden">Print A4</span>
            </button>
          </div>

        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-800 text-xs no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`px-2.5 py-1 rounded text-xs whitespace-nowrap shrink-0 transition-colors ${
                currentTab === item.id
                  ? 'bg-amber-400 text-slate-950 font-bold'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

      </div>
    </header>
  );
};
