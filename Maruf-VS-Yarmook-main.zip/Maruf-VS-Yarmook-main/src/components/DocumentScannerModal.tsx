import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  X,
  RotateCw,
  Sliders,
  Check,
  Download,
  FileText,
  Upload,
  RefreshCw,
  Sun,
  ShieldCheck,
  Crop,
  Layers,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Language } from '../data/translations';
import { EvidenceCategory, EvidenceItem } from '../types/case';

interface DocumentScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSaveToVault: (item: Partial<EvidenceItem>, base64Data: string, mimeType: string) => void;
}

export const DocumentScannerModal: React.FC<DocumentScannerModalProps> = ({
  isOpen,
  onClose,
  lang,
  onSaveToVault
}) => {
  const [step, setStep] = useState<'camera' | 'edit'>('camera');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  // Captured raw image
  const [rawImage, setRawImage] = useState<string | null>(null);

  // Filter & Edit states
  const [filterMode, setFilterMode] = useState<'grayscale' | 'enhanced_bw' | 'color'>('grayscale');
  const [contrast, setContrast] = useState<number>(130); // percentage
  const [brightness, setBrightness] = useState<number>(110); // percentage
  const [rotation, setRotation] = useState<number>(0);

  // Document metadata for filing
  const [docTitle, setDocTitle] = useState<string>('');
  const [docCategory, setDocCategory] = useState<EvidenceCategory>('wps_financial');
  const [docRefCode, setDocRefCode] = useState<string>('');
  const [docArticle, setDocArticle] = useState<string>('Royal Decree 53/2023 - Art. 53/55');

  // Processing canvas refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Start Camera Stream
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(
          lang === 'bn'
            ? 'ব্রাউজারে ক্যামেরা পারমিশন নেই বা ক্যামেরা সাপোর্ট করে না।'
            : lang === 'ar'
            ? 'الكاميرا غير مدعومة أو تم حظر الإذن في هذا المتصفح.'
            : 'Camera access is not supported or was blocked.'
        );
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      });

      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError(
        err.message ||
          (lang === 'bn'
            ? 'ক্যামেরা চালু করা সম্ভব হয়নি। নিচের "ছবি আপলোড করুন" বোতাম ব্যবহার করতে পারেন।'
            : lang === 'ar'
            ? 'تعذر تشغيل الكاميرا. يمكنك رفع صورة المستند يدوياً عبر زر الرفع.'
            : 'Could not access camera. You can upload an image directly below.')
      );
    }
  };

  // Stop camera stream
  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  };

  useEffect(() => {
    if (isOpen && step === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isOpen, step, facingMode]);

  // Capture current camera frame
  const captureFrame = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    setRawImage(dataUrl);
    setStep('edit');
    stopCamera();

    // Default metadata
    const stamp = new Date().toISOString().slice(0, 10);
    setDocTitle(`Court Exhibit Scan - ${stamp}`);
    setDocRefCode(`EX-${Date.now().toString().slice(-6)}`);
  };

  // Upload an image file as document source
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setRawImage(dataUrl);
      setStep('edit');
      stopCamera();

      setDocTitle(file.name.replace(/\.[^/.]+$/, ''));
      setDocRefCode(`EX-${Date.now().toString().slice(-6)}`);
    };
    reader.readAsDataURL(file);
  };

  // Switch rear/front camera
  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Render processed image with Grayscale / Enhanced B&W filter onto preview canvas
  useEffect(() => {
    if (step !== 'edit' || !rawImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = rawImage;

    img.onload = () => {
      const isRotated = rotation % 180 !== 0;
      canvas.width = isRotated ? img.height : img.width;
      canvas.height = isRotated ? img.width : img.height;

      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
      ctx.restore();

      // Apply Grayscale & Legal Document Filters
      if (filterMode === 'grayscale' || filterMode === 'enhanced_bw') {
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imgData.data;

        const contrastFactor = (259 * (contrast + 255)) / (255 * (259 - contrast));
        const brightAdjust = brightness - 100;

        for (let i = 0; i < data.length; i += 4) {
          // Standard Rec. 709 luminance formula
          let gray = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];

          // Brightness adjustment
          gray += brightAdjust;

          // Contrast adjustment
          gray = contrastFactor * (gray - 128) + 128;

          // Enhanced B&W High-Contrast thresholding for judicial filings
          if (filterMode === 'enhanced_bw') {
            gray = gray > 140 ? 255 : gray * 0.7; // Crisp clean document paper background
          }

          gray = Math.max(0, Math.min(255, gray));

          data[i] = gray;
          data[i + 1] = gray;
          data[i + 2] = gray;
        }

        ctx.putImageData(imgData, 0, 0);
      }
    };
  }, [rawImage, step, filterMode, contrast, brightness, rotation]);

  // Save document directly to Evidence Vault
  const handleSaveDocument = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const base64Data = canvas.toDataURL('image/jpeg', 0.92);

    const newEvidence: Partial<EvidenceItem> = {
      id: `scan-${Date.now()}`,
      refCode: docRefCode || `SCAN-${Date.now().toString().slice(-5)}`,
      category: docCategory,
      titleEn: docTitle || 'Court Document Scan (Grayscale)',
      titleBn: docTitle || 'আদালতের নথিপত্র স্ক্যান (গ্রেস্কেল)',
      titleAr: docTitle || 'مستند قضائي ممسوح ضوئياً (أبيض وأسود)',
      documentType: 'Legal Filing Scan (PDF/JPG)',
      legalArticle: docArticle || 'Royal Decree 53/2023',
      date: new Date().toISOString().slice(0, 10),
      status: 'court_exhibit',
      descriptionEn: `Digitally scanned legal document converted to high-contrast grayscale for judicial filing. Filter: ${filterMode}.`,
      descriptionBn: `আদালতে পেশের উদ্দেশ্যে হাই-কনট্রাস্ট গ্রেস্কেলে কনভার্ট করা ডিজিটাল নথি। ফিল্টার: ${filterMode}.`,
      descriptionAr: `مستند قانوني ممسوح ضوئياً ومحول لدرجات الرمادي عالية التباين المعتمدة لدى المحكمة الابتدائية.`
    };

    onSaveToVault(newEvidence, base64Data, 'image/jpeg');
    onClose();
  };

  // Download directly as Grayscale JPG
  const handleDownloadJpg = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = `${docRefCode || 'court_scan'}_grayscale.jpg`;
    link.href = canvasRef.current.toDataURL('image/jpeg', 0.95);
    link.click();
  };

  // Generate and download as printable single-page PDF
  const handleDownloadPdf = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.95);

    // Create an printable HTML window formatted strictly for A4
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Popups blocked. Downloading JPG instead.');
      handleDownloadJpg();
      return;
    }

    printWindow.document.write(`
      <!doctype html>
      <html>
      <head>
        <title>${docTitle || 'Legal Document Filing'}</title>
        <style>
          @page { size: A4 portrait; margin: 0; }
          body { margin: 0; padding: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: sans-serif; background: #fff; }
          .header { width: 100%; max-width: 720px; margin-bottom: 12px; display: flex; justify-content: space-between; border-bottom: 1px solid #ccc; padding-bottom: 6px; font-size: 11px; color: #555; }
          img { max-width: 100%; max-height: 250mm; object-fit: contain; box-shadow: 0 0 4px rgba(0,0,0,0.1); }
          .footer { margin-top: 10px; font-size: 10px; color: #777; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <div><strong>Court Filing Exhibit:</strong> ${docRefCode}</div>
          <div><strong>Case:</strong> CRT2601-3344 (Maruf vs Al Yarmook)</div>
          <div><strong>Date:</strong> ${new Date().toISOString().slice(0, 10)}</div>
        </div>
        <img src="${dataUrl}" />
        <div class="footer">Digitally captured & certified under Oman Labour Law (Royal Decree 53/2023)</div>
        <script>
          window.onload = function() { window.print(); }
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>
                  {lang === 'bn'
                    ? 'আদালতের নথি স্ক্যানার (ক্যামেরা ও গ্রেস্কেল কনভার্টার)'
                    : lang === 'ar'
                    ? 'الماسح الضوئي للمستندات والتحويل للأبيض والأسود'
                    : 'Court Document Camera Scanner & Grayscale Converter'}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Legal Grade
                </span>
              </h2>
              <div className="text-[11px] text-slate-400">
                {step === 'camera'
                  ? lang === 'bn'
                    ? 'কাগজটি ক্যামেরার সামনে সোজা রাখুন এবং ক্যাপচার চাপুন'
                    : lang === 'ar'
                    ? 'ضع المستند أمام الكاميرا داخل الإطار واضغط التقاط'
                    : 'Align document inside the frame guidance and click capture'
                  : lang === 'bn'
                  ? 'গ্রেস্কেল ফিল্টার সমন্বয় করুন এবং ভল্টে সংরক্ষণ করুন'
                  : lang === 'ar'
                  ? 'قم بضبط تباين الأبيض والأسود وحفظ المستند في خزانة الأدلة'
                  : 'Adjust grayscale contrast and save directly to Evidence Vault'}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50">
          {step === 'camera' ? (
            /* ================= STEP 1: CAMERA VIEWFINDER ================= */
            <div className="space-y-4">
              <div className="relative w-full aspect-4/3 sm:aspect-16/10 bg-black rounded-xl overflow-hidden shadow-inner border border-slate-800 flex items-center justify-center">
                <video
                  ref={videoRef}
                  playsInline
                  autoPlay
                  muted
                  className="w-full h-full object-cover"
                />

                {/* Document Alignment Overlay Box */}
                <div className="absolute inset-4 sm:inset-8 border-2 border-dashed border-amber-400/80 rounded-xl pointer-events-none flex flex-col justify-between p-3">
                  <div className="flex justify-between items-center text-[11px] font-mono font-bold text-amber-300 bg-black/60 px-2 py-0.5 rounded self-start">
                    <span>A4 / RECEIPT ALIGNMENT</span>
                  </div>
                  {/* Viewfinder corner brackets */}
                  <div className="flex justify-between items-center">
                    <span className="w-6 h-6 border-b-2 border-l-2 border-amber-400" />
                    <span className="w-6 h-6 border-b-2 border-r-2 border-amber-400" />
                  </div>
                </div>

                {/* Camera Error Message */}
                {cameraError && (
                  <div className="absolute inset-0 bg-slate-900/90 text-white p-6 flex flex-col items-center justify-center text-center space-y-3">
                    <AlertCircle className="w-10 h-10 text-amber-400" />
                    <div className="text-sm font-bold">{cameraError}</div>
                    <div className="text-xs text-slate-300 max-w-sm">
                      {lang === 'bn'
                        ? 'আপনার ব্রাউজারে ক্যামেরা পারমিশন না থাকলে নিচের "ছবি ফাইল আপলোড করুন" বিকল্পটি ব্যবহার করতে পারেন।'
                        : lang === 'ar'
                        ? 'إذا كان إذن الكاميرا محجوباً، يمكنك رفع صورة المستند مباشرة وسيقوم النظام بتحويلها للأبيض والأسود.'
                        : 'If camera permission is restricted in your browser, upload an image below to run through the grayscale scanner.'}
                    </div>
                  </div>
                )}
              </div>

              {/* Camera Actions Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={toggleFacingMode}
                    className="px-3 py-2 text-xs font-semibold rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                    <span>Switch Camera ({facingMode === 'environment' ? 'Rear' : 'Front'})</span>
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-2 text-xs font-semibold rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5 text-slate-500" />
                    <span>Upload Image File</span>
                  </button>
                </div>

                {/* Big Capture Trigger */}
                <button
                  type="button"
                  onClick={captureFrame}
                  className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 font-black text-sm flex items-center gap-2 shadow-md cursor-pointer transition-all"
                >
                  <Camera className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'ক্যাপচার করুন' : lang === 'ar' ? 'التقاط المستند' : 'Capture Document'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* ================= STEP 2: GRAYSCALE FILTER & FILING EDIT ================= */
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Left Column: Canvas Preview (7 cols) */}
              <div className="md:col-span-7 flex flex-col items-center justify-center space-y-3">
                <div className="w-full bg-slate-900 rounded-xl p-3 border border-slate-300 shadow-sm flex items-center justify-center min-h-[360px] overflow-hidden">
                  <canvas
                    ref={canvasRef}
                    className="max-h-[460px] max-w-full object-contain rounded shadow"
                  />
                </div>

                {/* Quick adjustments bar */}
                <div className="flex items-center gap-2 w-full justify-center">
                  <button
                    type="button"
                    onClick={() => setRotation((prev) => (prev + 90) % 360)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 hover:bg-slate-100 flex items-center gap-1.5"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-slate-600" />
                    <span>Rotate 90° ({rotation}°)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setStep('camera');
                      setRawImage(null);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-600"
                  >
                    Re-take / إلغاء
                  </button>
                </div>
              </div>

              {/* Right Column: Legal Conversion & Filing Metadata (5 cols) */}
              <div className="md:col-span-5 space-y-4">
                
                {/* Filter Selector */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-amber-500" />
                    <span>{lang === 'bn' ? 'আদালতের ফিল্টার মোড' : lang === 'ar' ? 'نمط المعالجة القضائية' : 'Court Document Filter'}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setFilterMode('grayscale')}
                      className={`p-2 text-xs font-bold rounded-lg border text-center transition-all ${
                        filterMode === 'grayscale'
                          ? 'bg-[#0b1f3a] text-white border-[#0b1f3a] shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Grayscale (رمادي)
                    </button>
                    <button
                      type="button"
                      onClick={() => setFilterMode('enhanced_bw')}
                      className={`p-2 text-xs font-bold rounded-lg border text-center transition-all ${
                        filterMode === 'enhanced_bw'
                          ? 'bg-[#0b1f3a] text-white border-[#0b1f3a] shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      B&W Legal (أبيض/أسود)
                    </button>
                    <button
                      type="button"
                      onClick={() => setFilterMode('color')}
                      className={`p-2 text-xs font-bold rounded-lg border text-center transition-all ${
                        filterMode === 'color'
                          ? 'bg-[#0b1f3a] text-white border-[#0b1f3a] shadow-2xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Color (ملون)
                    </button>
                  </div>

                  {/* Contrast and Brightness Sliders */}
                  {filterMode !== 'color' && (
                    <div className="space-y-2 pt-2 border-t border-slate-100 text-[11px]">
                      <div>
                        <div className="flex justify-between text-slate-600 mb-1">
                          <span>Contrast (التباين): {contrast}%</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="200"
                          value={contrast}
                          onChange={(e) => setContrast(Number(e.target.value))}
                          className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        />
                      </div>
                      <div>
                        <div className="flex justify-between text-slate-600 mb-1">
                          <span>Brightness (السطوع): {brightness}%</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="180"
                          value={brightness}
                          onChange={(e) => setBrightness(Number(e.target.value))}
                          className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Evidence Metadata Inputs */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3 text-xs">
                  <div className="text-xs font-bold text-slate-800">
                    {lang === 'bn' ? 'নথির পরিচিতি ও মামলা রেফারেন্স' : lang === 'ar' ? 'بيانات المستند ومطابقة الدعوى' : 'Filing Reference & Category'}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Document Title</label>
                    <input
                      type="text"
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      placeholder="e.g. Bank Muscat WPS Deposit Slip / Medical Cert"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-slate-50 text-xs font-medium focus:ring-1 focus:ring-amber-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">Exhibit Ref</label>
                      <input
                        type="text"
                        value={docRefCode}
                        onChange={(e) => setDocRefCode(e.target.value)}
                        placeholder="EX-001"
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-slate-50 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">Category</label>
                      <select
                        value={docCategory}
                        onChange={(e) => setDocCategory(e.target.value as EvidenceCategory)}
                        className="w-full px-2 py-1.5 border border-slate-300 rounded-lg bg-slate-50 text-xs"
                      >
                        <option value="wps_financial">WPS Financial Proof</option>
                        <option value="gov_id">Govt ID & Summons</option>
                        <option value="role_mismatch">Role Mismatch Proof</option>
                        <option value="rebuttal_breaches">Employer Breaches</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Export / Save Actions */}
                <div className="space-y-2 pt-2">
                  <button
                    type="button"
                    onClick={handleSaveDocument}
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-400 hover:bg-amber-300 active:scale-98 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>
                      {lang === 'bn'
                        ? 'এভিডেন্স ভল্টে সংরক্ষণ করুন'
                        : lang === 'ar'
                        ? 'حفظ في خزانة الأدلة الرقمية'
                        : 'Save to Evidence Vault (Synced)'}
                    </span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={handleDownloadJpg}
                      className="py-2 px-3 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5 text-slate-500" />
                      <span>JPG (Grayscale)</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadPdf}
                      className="py-2 px-3 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1"
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-600" />
                      <span>Print Legal PDF</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
