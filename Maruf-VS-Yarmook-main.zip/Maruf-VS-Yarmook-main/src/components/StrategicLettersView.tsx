import React, { useState } from 'react';
import { Mail, Copy, Check, Printer, FileText, Send } from 'lucide-react';
import { Language } from '../data/translations';
import { STRATEGIC_LETTERS } from '../data/forensicData';

interface StrategicLettersViewProps {
  lang: Language;
  onPrint: () => void;
}

export const StrategicLettersView: React.FC<StrategicLettersViewProps> = ({
  lang,
  onPrint
}) => {
  const [activeTrack, setActiveTrack] = useState<'track1' | 'track2'>('track1');
  const [copied, setCopied] = useState(false);

  const activeLetter = STRATEGIC_LETTERS[activeTrack];

  const handleCopy = () => {
    navigator.clipboard.writeText(
      `${activeLetter.title}\nDate: ${activeLetter.date}\nTo:\n${activeLetter.recipient}\n\n${activeLetter.content}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Mail className="w-3.5 h-3.5 text-amber-600" />
              <span>Section 5 · Strategic Diplomatic Correspondence</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'কৌশলগত চিঠি ও আনুষ্ঠানিক আপিল (ট্র্যাক ১ ও ২)' : lang === 'ar' ? 'الخطابات الاستراتيجية الرسمية (المسار الأول والثاني)' : 'Strategic Legal & Settlement Letters'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'মামলা দায়েরের পূর্বে কোম্পানি বরাবর পাঠানো আনুষ্ঠানিক আপিল পত্র এবং এনওসি (NOC) বা স্পন্সরশিপ ট্রান্সফারের আবেদন।'
                : lang === 'ar'
                ? 'خطابات رسمية موثقة تثبت سعي العامل للتسوية الودية، والمطالبة بوقف الخصم التعسفي ومنح شهادة عدم الممانعة (NOC).'
                : 'Authenticated formal correspondence establishing good-faith attempts at amicable resolution and NOC release requests.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopy}
              className="px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Letter'}</span>
            </button>
            <button
              onClick={onPrint}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'চিঠি প্রিন্ট' : lang === 'ar' ? 'طباعة الخطاب' : 'Print Letter'}</span>
            </button>
          </div>
        </div>

        {/* Track Selector Tabs */}
        <div className="flex items-center gap-2 mt-4 pt-2">
          <button
            onClick={() => setActiveTrack('track1')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
              activeTrack === 'track1'
                ? 'bg-[#0b1f3a] text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Track 1: Formal Legal Appeal (02/02/2026)
          </button>
          <button
            onClick={() => setActiveTrack('track2')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
              activeTrack === 'track2'
                ? 'bg-[#0b1f3a] text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Track 2: NOC & Unconditional Release Request
          </button>
        </div>
      </div>

      {/* Formatted Letter Paper Preview */}
      <div className="bg-white border border-slate-300 rounded-xl p-8 sm:p-12 shadow-sm max-w-4xl mx-auto font-serif text-slate-900 leading-relaxed">
        
        {/* Letter Head */}
        <div className="flex flex-col sm:flex-row justify-between items-start pb-6 mb-6 border-b border-slate-200 text-xs sm:text-sm">
          <div>
            <div className="font-sans font-bold text-slate-900 text-base">Habibur Rahman Abdul Barak (Maruf)</div>
            <div className="font-mono text-slate-600 mt-0.5">Civil ID: 103352388 | Work Permit: 10706994</div>
            <div className="font-mono text-slate-500">Phone: +968 96522902 | Barka, Sultanate of Oman</div>
          </div>
          <div className="mt-3 sm:mt-0 sm:text-right font-mono">
            <div className="text-slate-500 text-xs">Date of Dispatch:</div>
            <div className="font-bold text-slate-900">{activeLetter.date}</div>
          </div>
        </div>

        {/* Recipient */}
        <div className="mb-6 text-xs sm:text-sm text-slate-800 font-sans whitespace-pre-line bg-slate-50 p-4 rounded-lg border border-slate-200">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">To:</div>
          {activeLetter.recipient}
        </div>

        {/* Letter Body */}
        <div className="text-xs sm:text-sm text-slate-800 leading-relaxed font-sans whitespace-pre-line space-y-4">
          {activeLetter.content}
        </div>

        {/* Signature */}
        <div className="mt-12 pt-6 border-t border-slate-200 flex justify-between items-end text-xs font-sans">
          <div>
            <div className="text-slate-500">Claimant:</div>
            <div className="font-bold text-slate-900 mt-1">Habibur Rahman Abdul Barak</div>
            <div className="w-40 border-b border-slate-800 mt-6 pt-1 text-slate-400 text-[10px]">
              Signature
            </div>
          </div>
          <div className="font-mono text-slate-400 text-right text-[11px]">
            Delivered to Al Yarmook Head Office
          </div>
        </div>

      </div>

    </div>
  );
};
