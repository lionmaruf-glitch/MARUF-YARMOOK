import React, { useState, useMemo, useEffect } from 'react';
import { Search, X, Filter, Eye, ShieldCheck, Landmark, FileText, Calendar, DollarSign, Check, ExternalLink, Camera, Sparkles } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { EvidenceCategory, EvidenceItem, EvidenceStatus } from '../types/case';
import { EVIDENCE_RECORDS } from '../data/evidenceData';
import { DocumentScannerModal } from './DocumentScannerModal';
import { auth, syncEvidenceToFirestore } from '../firebase';

interface EvidenceVaultProps {
  lang: Language;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onInspectEvidence: (item: EvidenceItem) => void;
}

export const EvidenceVault: React.FC<EvidenceVaultProps> = ({
  lang,
  selectedCategory,
  onSelectCategory,
  onInspectEvidence
}) => {
  const t = TRANSLATIONS[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [customRecords, setCustomRecords] = useState<EvidenceItem[]>(() => {
    try {
      const saved = localStorage.getItem('marufedge_scanned_evidence');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const allRecords = useMemo(() => {
    return [...customRecords, ...EVIDENCE_RECORDS];
  }, [customRecords]);

  const categories = [
    { id: 'all', label: t.filterAll },
    { id: 'gov_id', label: t.filterCat1 },
    { id: 'wps_financial', label: t.filterCat2 },
    { id: 'role_mismatch', label: t.filterCat3 },
    { id: 'rebuttal_breaches', label: t.filterCat4 }
  ];

  const statuses = [
    { id: 'all', label: t.filterStatusAll },
    { id: 'verified_mol', label: lang === 'bn' ? 'শ্রম মন্ত্রণালয় প্রত্যায়িত' : lang === 'ar' ? 'معتمد من وزارة العمل' : 'Verified by MOL' },
    { id: 'bank_certified', label: lang === 'bn' ? 'ব্যাংক সার্টিফিকেট ও WPS' : lang === 'ar' ? 'كشوف بنكية رسمية' : 'Bank Certified (WPS)' },
    { id: 'accounting_system', label: lang === 'bn' ? 'অ্যাকাউন্টিং ERP রেকর্ড' : lang === 'ar' ? 'سجلات النظام المحاسبي' : 'Accounting ERP' },
    { id: 'court_exhibit', label: lang === 'bn' ? 'আদালতের প্রদর্শনী' : lang === 'ar' ? 'مستند قضائي معتمد' : 'Court Exhibit' }
  ];

  const handleSaveScannedEvidence = (itemData: Partial<EvidenceItem>, base64Data: string, mimeType: string) => {
    const newItem: EvidenceItem = {
      id: itemData.id || `scan-${Date.now()}`,
      refCode: itemData.refCode || `SCAN-${Date.now().toString().slice(-5)}`,
      category: itemData.category || 'wps_financial',
      documentType: itemData.documentType || 'Legal Grayscale Document Scan',
      titleEn: itemData.titleEn || 'Scanned Legal Document',
      titleBn: itemData.titleBn || 'স্ক্যান করা আদালতের নথি',
      titleAr: itemData.titleAr || 'مستند قضائي ممسوح ضوئياً',
      date: itemData.date || new Date().toISOString().slice(0, 10),
      status: 'court_exhibit',
      descriptionEn: itemData.descriptionEn || 'Scanned legal document converted to high contrast grayscale.',
      descriptionBn: itemData.descriptionBn || 'হাই কনট্রাস্ট গ্রেস্কেলে কনভার্ট করা ডিজিটাল এভিডেন্স।',
      descriptionAr: itemData.descriptionAr || 'مستند قانوني ممسوح ضوئياً ومحول للأبيض والأسود.',
      legalArticle: itemData.legalArticle || 'Royal Decree 53/2023',
      judgeHighlightEn: 'Authenticated grayscale document capture for judicial filing.',
      judgeHighlightBn: 'আদালতে পেশের জন্য অনুমোদিত গ্রেস্কেল স্ক্যান কপি।',
      judgeHighlightAr: 'صورة وثيقة ممسوحة ضوئياً بالأبيض والأسود معتمدة للملف القضائي.',
      keyExhibitNumber: itemData.refCode,
      previewUrl: base64Data
    };

    const updated = [newItem, ...customRecords];
    setCustomRecords(updated);
    try {
      localStorage.setItem('marufedge_scanned_evidence', JSON.stringify(updated));
    } catch (e) {
      console.warn('Storage quota limit reached:', e);
    }

    if (auth.currentUser) {
      syncEvidenceToFirestore(auth.currentUser.uid, [newItem]);
    }
  };

  const filteredRecords = useMemo(() => {
    return allRecords.filter((item) => {
      // Category match
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }

      // Status match
      if (statusFilter !== 'all' && item.status !== statusFilter) {
        return false;
      }

      // Search query match
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const matchRef = item.refCode.toLowerCase().includes(q);
      const matchExhibit = item.keyExhibitNumber?.toLowerCase().includes(q);
      const matchDate = item.date.includes(q);
      const matchLegal = item.legalArticle.toLowerCase().includes(q);
      const matchDoc = item.documentType.toLowerCase().includes(q);
      const matchAmount = item.amountOMR?.toString().includes(q);
      const matchTitle =
        item.titleEn.toLowerCase().includes(q) ||
        item.titleBn.toLowerCase().includes(q) ||
        item.titleAr.toLowerCase().includes(q);
      const matchDesc =
        item.descriptionEn.toLowerCase().includes(q) ||
        item.descriptionBn.toLowerCase().includes(q) ||
        item.descriptionAr.toLowerCase().includes(q);

      return (
        matchRef ||
        matchExhibit ||
        matchDate ||
        matchLegal ||
        matchDoc ||
        matchAmount ||
        matchTitle ||
        matchDesc
      );
    });
  }, [searchQuery, selectedCategory, statusFilter]);

  const getStatusBadge = (status: EvidenceStatus) => {
    switch (status) {
      case 'verified_mol':
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />,
          label: lang === 'bn' ? 'MOL ভেরিফাইড' : lang === 'ar' ? 'توثيق وزارة العمل' : 'Verified by MOL'
        };
      case 'bank_certified':
        return {
          bg: 'bg-blue-50 text-blue-800 border-blue-200',
          icon: <Landmark className="w-3.5 h-3.5 text-blue-600" />,
          label: lang === 'bn' ? 'ব্যাংক সার্টিফিকেট' : lang === 'ar' ? 'كشف بنكي رسمي' : 'Bank Certified'
        };
      case 'accounting_system':
        return {
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          icon: <FileText className="w-3.5 h-3.5 text-amber-600" />,
          label: lang === 'bn' ? 'সিস্টেম লেজার' : lang === 'ar' ? 'نظام المحاسبة' : 'ERP System Ledger'
        };
      case 'court_exhibit':
        return {
          bg: 'bg-purple-50 text-purple-800 border-purple-200',
          icon: <Check className="w-3.5 h-3.5 text-purple-600" />,
          label: lang === 'bn' ? 'কোর্ট প্রদর্শনী' : lang === 'ar' ? 'مستند المحكمة' : 'Court Exhibit'
        };
      default:
        return {
          bg: 'bg-slate-50 text-slate-800 border-slate-200',
          icon: <FileText className="w-3.5 h-3.5 text-slate-600" />,
          label: 'Official Record'
        };
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header & Controls */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {t.navEvidenceVault}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
              {lang === 'bn'
                ? 'সিব ও বারকা আদালতের বিচারকদের জন্য সংরক্ষিত মূল প্রমাণের ডিজিটাল সংগ্রহশালা (WPS, সমন, ডিপোজিট স্লিপ, অডিট)'
                : lang === 'ar'
                ? 'خزانة الأدلة الرقمية المعتمدة لمحكمتي السيب وبركاء وقضايا وزارة العمل'
                : 'Digital evidentiary vault cataloging 79+ authenticated records for Seeb and Barka Primary Courts.'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-start md:self-auto">
            <button
              onClick={() => setIsScannerOpen(true)}
              className="px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 rounded-lg shadow-2xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>
                {lang === 'bn' ? 'নথি স্ক্যান করুন (ক্যামেরা)' : lang === 'ar' ? 'مسح مستند بالكاميرا (B&W)' : 'Scan Document (Camera)'}
              </span>
            </button>

            <div className="flex items-center gap-1.5 text-xs font-mono font-semibold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-lg shrink-0">
              <span>{filteredRecords.length} / {allRecords.length}</span>
              <span>{t.recordsFound}</span>
            </div>
          </div>
        </div>

        {/* Live Search Bar */}
        <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-10 pr-9 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Status Dropdown */}
          <div className="relative shrink-0">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full sm:w-auto px-3 py-2.5 text-xs font-medium bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/30"
            >
              {statuses.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          {(searchQuery || selectedCategory !== 'all' || statusFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchQuery('');
                onSelectCategory('all');
                setStatusFilter('all');
              }}
              className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            >
              {t.clearFilters}
            </button>
          )}
        </div>

        {/* Category Segmented Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-4 mt-2 border-t border-slate-100 no-scrollbar">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => onSelectCategory(c.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors shrink-0 ${
                selectedCategory === c.id
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Evidence Cards Grid */}
      {filteredRecords.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Filter className="w-8 h-8 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">
            {lang === 'bn' ? 'কোনো প্রমাণ রেকর্ড মেলেনি' : lang === 'ar' ? 'لم يتم العثور على أي مستندات مطابقة' : 'No matching evidence found'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {lang === 'bn'
              ? 'আপনার অনুসন্ধান শব্দ বা ফিল্টার পরিবর্তন করে আবার চেষ্টা করুন।'
              : lang === 'ar'
              ? 'يرجى تجربة كلمات بحث أخرى أو إعادة ضبط التصفية.'
              : 'Try clearing your search query or switching categories.'}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              onSelectCategory('all');
              setStatusFilter('all');
            }}
            className="mt-4 px-4 py-2 text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg transition-colors"
          >
            {t.clearFilters}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRecords.map((item) => {
            const statusInfo = getStatusBadge(item.status);

            return (
              <div
                key={item.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-amber-400/80 hover:shadow-sm transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Top line metadata */}
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 pb-2.5 mb-2.5 border-b border-slate-100">
                    <div className="flex items-center gap-1.5 font-mono font-bold text-amber-800">
                      <span>{item.keyExhibitNumber || 'EXHIBIT'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-600 font-medium">{item.refCode}</span>
                    </div>

                    <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border ${statusInfo.bg}`}>
                      {statusInfo.icon}
                      <span>{statusInfo.label}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                    {lang === 'bn' ? item.titleBn : lang === 'ar' ? item.titleAr : item.titleEn}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {lang === 'bn' ? item.descriptionBn : lang === 'ar' ? item.descriptionAr : item.descriptionEn}
                  </p>

                  {/* Highlights and Judge Attention Point */}
                  <div className="mt-3 p-3 rounded-lg bg-amber-50/70 border border-amber-200/60 text-xs">
                    <span className="font-bold text-amber-950 block mb-0.5">
                      {t.judgeAttention}
                    </span>
                    <span className="text-amber-900 leading-normal">
                      {lang === 'bn' ? item.judgeHighlightBn : lang === 'ar' ? item.judgeHighlightAr : item.judgeHighlightEn}
                    </span>
                  </div>
                </div>

                {/* Footer details: Date, Amount, Legal Article, Inspect button */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap text-xs">
                  <div className="flex items-center gap-3 text-slate-500 font-mono">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.date}</span>
                    </div>
                    {item.amountOMR !== undefined && (
                      <div className="flex items-center gap-1 font-bold text-slate-900">
                        <DollarSign className="w-3.5 h-3.5 text-amber-600" />
                        <span className="tabular-nums">{item.amountOMR.toLocaleString('en-US', { minimumFractionDigits: 3 })} OMR</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
                      {item.legalArticle}
                    </span>
                    <button
                      onClick={() => onInspectEvidence(item)}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-900 hover:text-white bg-amber-400 hover:bg-[#0b1f3a] rounded-md transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>{t.viewDetails}</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Document Camera Scanner Modal */}
      <DocumentScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        lang={lang}
        onSaveToVault={handleSaveScannedEvidence}
      />

    </div>
  );
};
