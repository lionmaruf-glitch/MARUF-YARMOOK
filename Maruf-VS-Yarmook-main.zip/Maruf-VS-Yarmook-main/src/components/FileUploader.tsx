import React, { useState, useRef } from 'react';
import { UploadCloud, File, Trash2, Eye, Download, FileText, CheckCircle2, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { EvidenceCategory } from '../types/case';

interface UploadedDoc {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadedAt: string;
  category: EvidenceCategory;
  notes: string;
  previewUrl?: string;
}

interface FileUploaderProps {
  lang: Language;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<UploadedDoc | null>(null);

  // Initial seed documents representing the real case files
  const [uploadedFiles, setUploadedFiles] = useState<UploadedDoc[]>([
    {
      id: 'doc-01',
      name: 'MOL-Complaint-Slip-REF2603150080.pdf',
      size: '1.4 MB',
      type: 'application/pdf',
      uploadedAt: '2026-03-15',
      category: 'gov_id',
      notes: 'Ministry of Labour complaint registration slip for non-payment of wages.'
    },
    {
      id: 'doc-02',
      name: 'Bank-Muscat-WPS-Statement-250OMR.pdf',
      size: '2.8 MB',
      type: 'application/pdf',
      uploadedAt: '2026-04-02',
      category: 'wps_financial',
      notes: 'Bank Muscat WPS statement proving regular 250 OMR monthly salary credit.'
    },
    {
      id: 'doc-03',
      name: 'Grievance-REFXG20261009001-Desertion-Appeal.png',
      size: '890 KB',
      type: 'image/png',
      uploadedAt: '2026-10-09',
      category: 'gov_id',
      notes: 'Ministry of Labour desertion grievance submission against runaway notice DCA-20260802114.'
    },
    {
      id: 'doc-04',
      name: 'Barka-Aluminium-Sales-Ledger-53K.pdf',
      size: '4.2 MB',
      type: 'application/pdf',
      uploadedAt: '2026-05-18',
      category: 'role_mismatch',
      notes: 'Branch sales records showing 53,000 OMR/month under user MARUF.'
    },
    {
      id: 'doc-05',
      name: 'Ooredoo-Commercial-Notice-217OMR.jpg',
      size: '1.1 MB',
      type: 'image/jpeg',
      uploadedAt: '2026-01-27',
      category: 'wps_financial',
      notes: 'Legal notice for commercial internet line registered under Civil ID 103352388.'
    }
  ]);

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newDocs: UploadedDoc[] = [];
    Array.from(files).forEach((file) => {
      const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
      const isImg = file.type.startsWith('image/');

      const newDoc: UploadedDoc = {
        id: `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name: file.name,
        size: `${sizeMB} MB`,
        type: file.type,
        uploadedAt: new Date().toISOString().split('T')[0],
        category: 'rebuttal_breaches',
        notes: 'User uploaded court exhibit file.',
        previewUrl: isImg ? URL.createObjectURL(file) : undefined
      };
      newDocs.push(newDoc);
    });

    setUploadedFiles((prev) => [...newDocs, ...prev]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleDelete = (id: string) => {
    setUploadedFiles((prev) => prev.filter((d) => d.id !== id));
  };

  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="pb-4 border-b border-slate-100">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            {t.uploaderTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
            {t.uploaderSubtitle}
          </p>
        </div>

        {/* Drag and drop zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`mt-6 border-2 border-dashed rounded-xl p-8 sm:p-12 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-amber-500 bg-amber-50/50 scale-[1.01]'
              : 'border-slate-300 hover:border-amber-400 bg-slate-50/50 hover:bg-slate-50'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            multiple
            accept=".pdf,.png,.jpg,.jpeg"
            onChange={(e) => handleFiles(e.target.files)}
            className="hidden"
          />

          <div className="w-14 h-14 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto mb-3 shadow-xs">
            <UploadCloud className="w-7 h-7" />
          </div>

          <h3 className="text-sm sm:text-base font-bold text-slate-900">
            {t.dropzoneTitle}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {t.dropzoneSubtitle}
          </p>
          <p className="text-[11px] text-amber-800 font-medium mt-3">
            {lang === 'bn'
              ? '✓ ফাইলগুলো আদালতের ফাইলিং ডসিয়ারে স্বয়ংক্রিয়ভাবে সূচিবদ্ধ হবে'
              : lang === 'ar'
              ? '✓ يتم فهرسة الوثائق آلياً ضمن ملف القضية'
              : '✓ Files are securely indexed for court dossier cross-referencing'}
          </p>
        </div>
      </div>

      {/* Uploaded Documents List */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {lang === 'bn' ? 'সংরক্ষিত প্রমাণের ফাইলসমূহ' : lang === 'ar' ? 'سجل الوثائق والمستندات المحفوظة' : 'Stored Case Documents'}
            </h2>
            <p className="text-xs text-slate-500">
              {uploadedFiles.length} {t.uploadedFilesCount}
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {uploadedFiles.map((doc) => (
            <div
              key={doc.id}
              className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 px-2 rounded-lg transition-colors"
            >
              <div className="flex items-start sm:items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 shrink-0">
                  {doc.type.includes('image') ? (
                    <ImageIcon className="w-5 h-5 text-amber-600" />
                  ) : (
                    <FileText className="w-5 h-5 text-blue-600" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                    {doc.name}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <span className="font-mono">{doc.size}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{doc.uploadedAt}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-amber-800 font-medium">{doc.category}</span>
                  </div>
                  {doc.notes && (
                    <div className="text-[11px] text-slate-500 mt-0.5 truncate max-w-xl">
                      {doc.notes}
                    </div>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                <button
                  onClick={() => setPreviewDoc(doc)}
                  className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'প্রিভিউ' : lang === 'ar' ? 'معاينة' : 'Preview'}</span>
                </button>
                <button
                  onClick={() => handleDelete(doc.id)}
                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                  title="Remove file"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2 min-w-0">
                <File className="w-5 h-5 text-amber-600 shrink-0" />
                <h3 className="font-bold text-slate-900 text-sm sm:text-base truncate">
                  {previewDoc.name}
                </h3>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="text-slate-400 hover:text-slate-700 text-sm font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="my-6 p-6 bg-slate-50 border border-slate-200 rounded-lg text-center min-h-[160px] flex flex-col items-center justify-center">
              {previewDoc.previewUrl ? (
                <img
                  src={previewDoc.previewUrl}
                  alt={previewDoc.name}
                  className="max-h-72 object-contain rounded shadow-xs"
                />
              ) : (
                <>
                  <FileText className="w-12 h-12 text-slate-400 mb-2" />
                  <div className="text-sm font-bold text-slate-800">{previewDoc.name}</div>
                  <div className="text-xs text-slate-500 font-mono mt-1">{previewDoc.size} · {previewDoc.type}</div>
                  <div className="text-xs text-emerald-700 font-semibold mt-2">
                    ✓ Verified Court Evidence Entry
                  </div>
                </>
              )}
            </div>

            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500">
                Category: <b className="text-slate-800">{previewDoc.category}</b>
              </span>
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 bg-[#0b1f3a] text-white font-bold rounded-lg hover:bg-slate-800"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : lang === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
