import React, { useState, useEffect } from 'react';
import { CheckSquare, Square, RotateCcw, Printer, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { MASTER_CHECKLIST } from '../data/evidenceData';

interface EvidenceChecklistProps {
  lang: Language;
  onPrint: () => void;
}

export const EvidenceChecklist: React.FC<EvidenceChecklistProps> = ({
  lang,
  onPrint
}) => {
  const t = TRANSLATIONS[lang];
  const [checkedState, setCheckedState] = useState<Record<string, { set1: boolean; set2: boolean; set3: boolean }>>(() => {
    try {
      const saved = localStorage.getItem('maruf_evidence_checklist_v2');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('maruf_evidence_checklist_v2', JSON.stringify(checkedState));
    } catch {
      // storage unavailable
    }
  }, [checkedState]);

  const toggleCheck = (itemId: string, setKey: 'set1' | 'set2' | 'set3') => {
    setCheckedState((prev) => {
      const currentItem = prev[itemId] || { set1: false, set2: false, set3: false };
      return {
        ...prev,
        [itemId]: {
          ...currentItem,
          [setKey]: !currentItem[setKey]
        }
      };
    });
  };

  const handleReset = () => {
    if (window.confirm(lang === 'bn' ? 'সব টিক চিহ্ন মুছে ফেলবেন?' : lang === 'ar' ? 'هل تريد إعادة ضبط القائمة بالكامل؟' : 'Reset all checkmarks?')) {
      setCheckedState({});
    }
  };

  // Compute total progress
  const totalItems = MASTER_CHECKLIST.reduce((acc, cat) => acc + cat.items.length, 0);
  const totalPossibleChecks = totalItems * 3; // 3 sets
  let checkedCount = 0;
  Object.values(checkedState).forEach((item) => {
    if (item.set1) checkedCount++;
    if (item.set2) checkedCount++;
    if (item.set3) checkedCount++;
  });

  const progressPercent = Math.round((checkedCount / totalPossibleChecks) * 100);

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Barka & Seeb Primary Courts Master Verification</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {t.checklistTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {t.checklistSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.resetChecklist}</span>
            </button>
            <button
              onClick={onPrint}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'চেকলিস্ট প্রিন্ট' : lang === 'ar' ? 'طباعة القائمة' : 'Print Checklist'}</span>
            </button>
          </div>
        </div>

        {/* Progress Tracker */}
        <div className="mt-4 pt-2">
          <div className="flex items-center justify-between text-xs font-semibold mb-2">
            <span className="text-slate-700">
              {lang === 'bn' ? 'আদালতের ৩টি সেটের প্রস্তুতি অগ্রগতি:' : lang === 'ar' ? 'نسبة اكتمال تجهيز الملفات الثلاثة:' : 'Overall 3-Set Verification Readiness:'}
            </span>
            <span className="font-mono text-amber-800 font-bold">
              {checkedCount} / {totalPossibleChecks} ({progressPercent}%)
            </span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* 3 Sets Legend */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 text-xs font-medium">
          <div className="p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-blue-950 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0" />
            <span><b>Set 1:</b> {lang === 'bn' ? 'মাননীয় বিচারকের কপি (Court Judge)' : lang === 'ar' ? 'نسخة فضيلة القاضي' : 'Presiding Judge Set'}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-950 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-600 shrink-0" />
            <span><b>Set 2:</b> {lang === 'bn' ? 'আদালত ক্লার্ক কপি (Court Clerk)' : lang === 'ar' ? 'نسخة أمين سر الجلسة' : 'Court Clerk Set'}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 shrink-0" />
            <span><b>Set 3:</b> {lang === 'bn' ? 'মারুফের ব্যক্তিগত কপি (Personal File)' : lang === 'ar' ? 'النسخة الشخصية للعامل' : 'Personal Worker Set'}</span>
          </div>
        </div>
      </div>

      {/* Checklist Sections */}
      <div className="space-y-4">
        {MASTER_CHECKLIST.map((category) => (
          <div key={category.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h2 className="text-sm sm:text-base font-bold text-slate-900 pb-2 mb-3 border-b border-slate-100 flex items-center justify-between">
              <span>{lang === 'bn' ? category.categoryBn : lang === 'ar' ? category.categoryAr : category.categoryEn}</span>
              <span className="text-xs font-mono text-slate-500 font-normal">
                {category.items.length} {lang === 'bn' ? 'টি নথি' : lang === 'ar' ? 'وثائق' : 'items'}
              </span>
            </h2>

            <div className="divide-y divide-slate-100">
              {category.items.map((item) => {
                const itemState = checkedState[item.id] || { set1: false, set2: false, set3: false };
                const isFullyComplete = itemState.set1 && itemState.set2 && itemState.set3;

                return (
                  <div
                    key={item.id}
                    className={`py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                      isFullyComplete ? 'bg-emerald-50/50 -mx-2 px-2 rounded-lg' : ''
                    }`}
                  >
                    <div className="flex-1 text-xs sm:text-sm font-medium text-slate-800">
                      <span className={isFullyComplete ? 'line-through text-emerald-800' : ''}>
                        {lang === 'bn' ? item.labelBn : lang === 'ar' ? item.labelAr : item.labelEn}
                      </span>
                    </div>

                    {/* 3 Set Checkboxes */}
                    <div className="flex items-center gap-2 sm:gap-3 shrink-0 text-xs">
                      {/* Set 1 */}
                      <button
                        onClick={() => toggleCheck(item.id, 'set1')}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] font-semibold transition-all ${
                          itemState.set1
                            ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                            : 'bg-white text-slate-600 border-slate-300 hover:border-blue-400'
                        }`}
                        title="Set 1 (Judge)"
                      >
                        {itemState.set1 ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5 text-slate-400" />}
                        <span>Set 1</span>
                      </button>

                      {/* Set 2 */}
                      <button
                        onClick={() => toggleCheck(item.id, 'set2')}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] font-semibold transition-all ${
                          itemState.set2
                            ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                            : 'bg-white text-slate-600 border-slate-300 hover:border-amber-400'
                        }`}
                        title="Set 2 (Clerk)"
                      >
                        {itemState.set2 ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5 text-slate-400" />}
                        <span>Set 2</span>
                      </button>

                      {/* Set 3 */}
                      <button
                        onClick={() => toggleCheck(item.id, 'set3')}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] font-semibold transition-all ${
                          itemState.set3
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                            : 'bg-white text-slate-600 border-slate-300 hover:border-emerald-400'
                        }`}
                        title="Set 3 (Personal)"
                      >
                        {itemState.set3 ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5 text-slate-400" />}
                        <span>Set 3</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
