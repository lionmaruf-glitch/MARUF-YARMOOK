import React, { useState } from 'react';
import { Printer, FileText, ShieldCheck, AlertCircle, QrCode, BookOpen } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { CASE_METADATA } from '../data/evidenceData';

interface CourtPetitionViewProps {
  lang: Language;
  onPrint: () => void;
}

export const CourtPetitionView: React.FC<CourtPetitionViewProps> = ({
  lang,
  onPrint
}) => {
  const t = TRANSLATIONS[lang];
  const [activeScreenTab, setActiveScreenTab] = useState<'ar' | 'en' | 'cover' | 'bn'>('ar');

  const { plaintiff, defendant, courts, ministry } = CASE_METADATA;

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Print Action Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs no-print">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <span className="text-amber-700 font-bold">Supreme Judicial Council A4 Print Standard</span>
              <span aria-hidden="true">·</span>
              <span>Royal Decree No. 53/2023</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'আদালতের পিটিশন ও ৩-সেট কভার পেজ' : lang === 'ar' ? 'مذكرة المحكمة وحافظة مستندات الأدلة (A4)' : 'Court Petition & Master Folder Cover'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'সিব ও বারকা আদালতের বিচারক, ক্লার্ক ও আপনার জন্য ৩টি পূর্ণাঙ্গ সেট প্রস্তুতের ৩-পেজের অফিসিয়াল জুডিশিয়াল ফাইল। প্রিন্ট দিলে স্বয়ংক্রিয়ভাবে শুধুমাত্র আরবি ও ইংরেজি A4 পেজগুলোই বের হবে।'
                : lang === 'ar'
                ? 'المذكرة القضائية المتكاملة لعدالة المحكمة مرفقة بحافظة المستندات وفهرس الطيات الأربع لتقديم المجموعات الثلاث المعتمدة.'
                : 'Official judicial petition and evidence folder index sheet formatted strictly for A4 print submission.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onPrint}
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-extrabold rounded-lg shadow-sm flex items-center gap-2 transition-transform active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>{t.printButton}</span>
            </button>
          </div>
        </div>

        {/* View Switcher on Screen */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4 pt-2">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg flex-wrap">
            <button
              onClick={() => setActiveScreenTab('ar')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${
                activeScreenTab === 'ar'
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📄 1. المذكرة العربية (Arabic Petition)
            </button>
            <button
              onClick={() => setActiveScreenTab('en')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${
                activeScreenTab === 'en'
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📄 2. English Petition (Official)
            </button>
            <button
              onClick={() => setActiveScreenTab('cover')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${
                activeScreenTab === 'cover'
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📁 3. حافظة الأدلة (Folder Cover & Index)
            </button>
            <button
              onClick={() => setActiveScreenTab('bn')}
              className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${
                activeScreenTab === 'bn'
                  ? 'bg-[#0b1f3a] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📘 4. বাংলা সহায়িকা (Screen Guide)
            </button>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{t.printPreviewNotice}</span>
          </div>
        </div>
      </div>

      {/* ========================================================
          PRINT CONTAINER (Contains Arabic, English, and Cover A4 pages)
          Bangla is screen only and hidden in print!
      ======================================================== */}
      <div className="print-container space-y-8">
        
        {/* ========================================================
            PAGE 1: ARABIC FOLDER COVER & MASTER EVIDENCE INDEX SHEET
        ======================================================== */}
        <div
          id="court-cover-ar"
          dir="rtl"
          className={`a4-page bg-white p-8 sm:p-12 border border-slate-300 shadow-md max-w-[210mm] mx-auto text-slate-950 font-['Cairo','Amiri',serif] leading-relaxed relative ${
            activeScreenTab === 'cover' ? 'block' : 'hidden print:block'
          }`}
          style={{ minHeight: '297mm' }}
        >
          {/* QR Code Area */}
          <div className="absolute top-10 left-10 w-24 h-24 border border-dashed border-slate-400 p-1.5 rounded flex flex-col items-center justify-center text-center bg-white shadow-2xs">
            <svg viewBox="0 0 100 100" className="w-16 h-16 fill-slate-900">
              <rect x="0" y="0" width="30" height="30" rx="3" fill="#0b1f3a" />
              <rect x="6" y="6" width="18" height="18" rx="2" fill="#ffffff" />
              <rect x="11" y="11" width="8" height="8" rx="1" fill="#0b1f3a" />
              <rect x="70" y="0" width="30" height="30" rx="3" fill="#0b1f3a" />
              <rect x="76" y="6" width="18" height="18" rx="2" fill="#ffffff" />
              <rect x="81" y="11" width="8" height="8" rx="1" fill="#0b1f3a" />
              <rect x="0" y="70" width="30" height="30" rx="3" fill="#0b1f3a" />
              <rect x="6" y="76" width="18" height="18" rx="2" fill="#ffffff" />
              <rect x="11" y="81" width="8" height="8" rx="1" fill="#0b1f3a" />
              <rect x="40" y="5" width="8" height="8" fill="#0b1f3a" />
              <rect x="52" y="15" width="8" height="8" fill="#0b1f3a" />
              <rect x="40" y="25" width="8" height="8" fill="#0b1f3a" />
              <rect x="10" y="45" width="8" height="8" fill="#0b1f3a" />
              <rect x="45" y="45" width="12" height="12" fill="#0b1f3a" />
              <rect x="65" y="45" width="8" height="8" fill="#0b1f3a" />
              <rect x="40" y="65" width="8" height="8" fill="#0b1f3a" />
              <rect x="55" y="75" width="8" height="8" fill="#0b1f3a" />
              <rect x="75" y="65" width="15" height="8" fill="#0b1f3a" />
              <rect x="75" y="80" width="8" height="15" fill="#0b1f3a" />
            </svg>
            <span className="text-[7.5px] font-mono font-bold text-slate-700 tracking-tighter mt-1">
              Google Drive Cloud
            </span>
          </div>

          {/* Header */}
          <div className="text-center pb-5 mb-5 border-b-2 border-double border-amber-600/70">
            <div className="text-xs font-bold tracking-wider text-slate-800">
              سلطنة عمان — المجلس الأعلى للقضاء
            </div>
            <div className="text-xs text-slate-600 mt-1">
              المحكمة الابتدائية بالسيب / بركاء — الدائرة العمالية
            </div>
            <div className="text-base sm:text-lg font-extrabold text-[#0b1f3a] mt-2">
              حافظة مستندات وأدلة قضائية (Master Evidence Cover Sheet)
            </div>
            <div className="text-xs font-mono text-slate-700 mt-1">
              رقم الدعوى القضائية: <span className="font-bold">CRT2601-3344 / 1005-1215-2026</span>
            </div>
            <div className="text-xs font-mono text-slate-600">
              رقم شكوى وزارة العمل: {ministry.firstComplaintRef} / {ministry.secondComplaintRef} | التظلم: {ministry.grievanceRef}
            </div>
          </div>

          {/* Parties */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs mb-4">
            <div className="font-bold text-slate-900 mb-1">أولاً: بيانات أطراف الدعوى</div>
            <div><b>المدعي (العامل):</b> {plaintiff.fullName} (معروف) | <b>الرقم المدني:</b> {plaintiff.civilId} | <b>تصريح العمل:</b> {plaintiff.workPermit}</div>
            <div><b>المدعى عليها (صاحب العمل):</b> {defendant.companyNameAr} (سجل تجاري: {defendant.crNumber})</div>
            <div><b>مدة الخدمة المطالب بها:</b> من يوليو 2015م حتى 2026م (خدمة مستمرة لأكثر من 11 سنة)</div>
          </div>

          {/* 4 Tabs Index Checklist */}
          <div className="text-xs space-y-3 mb-6">
            <div className="font-bold text-slate-900 border-b border-amber-500 pb-1">
              ثانياً: جدول الفهرس والمحتويات للطيّات الأربع (Evidence Index Checklist)
            </div>

            {/* Tab 1 */}
            <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
              <div className="font-bold text-[#0b1f3a] mb-1">الطيّة الأولى: وثائق الهوية والشكاوى والتظلمات الرسمية (Tab 1)</div>
              <ul className="list-disc list-inside text-[11px] text-slate-700 space-y-0.5">
                <li>صورة البطاقة المدنية المقيمة (103352388) سارية المفعول برقم تصريح العمل (10706994).</li>
                <li>صورة جواز السفر وإقرار احتجاز الجواز الأصلي تعسفياً لدى الكفيل (المادة 6 و 147).</li>
                <li>إيصال تسجيل الشكوى العمالية الأولى (REF2603150080) المؤرخة 15/03/2026م.</li>
                <li>إيصال إعادة فتح الشكوى (REF2607290085) المؤرخة 29/07/2026م لجلسة 10/08/2026م.</li>
                <li>إشعار وقيد التظلم الرسمي (REFXG20261009001) لإلغاء بلاغ ترك العمل الكيدي DCA-20260802114.</li>
                <li>إشعار استدعاء المحكمة الابتدائية (CRT2601-3344 / 1005/1215/2026).</li>
              </ul>
            </div>

            {/* Tab 2 */}
            <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
              <div className="font-bold text-[#0b1f3a] mb-1">الطيّة الثانية: كشوفات الحساب والرواتب والخصومات غير القانونية (Tab 2)</div>
              <ul className="list-disc list-inside text-[11px] text-slate-700 space-y-0.5">
                <li>كشوفات حساب بنك مسقط (WPS): إثبات تحويل الراتب الأساسي (250 ر.ع) ونفي ادعاء عقد الـ 60 ر.ع المزور.</li>
                <li>كشوفات الحساب الفرعي للنظام المحاسبي (MARUF LOAN A/C): إثبات الاستقطاع التعسفي (50 ر.ع شهرياً).</li>
                <li>إيصالات وتكاليف حجر كوفيد-19 والتذاكر (600 ر.ع) المقتطعة تعسفياً من الراتب.</li>
                <li>الإنذار القضائي الرسمي لشركة أوريدو (217 ر.ع): خصم قيمة خط الإنترنت التجاري للورشة من الراتب.</li>
                <li>إيصالات الإيداعات البنكية اليومية للفرع مدموغة بالرقم المدني للعامل.</li>
              </ul>
            </div>

            {/* Tab 3 */}
            <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
              <div className="font-bold text-[#0b1f3a] mb-1">الطيّة الثالثة: إثبات المسمى الوظيفي والمبيعات ومخالفة التأشيرة (Tab 3)</div>
              <ul className="list-disc list-inside text-[11px] text-slate-700 space-y-0.5">
                <li>إثبات مخالفة المهنة والتأشيرة: بطاقات مقيم تثبت تسجيل مهنة صورية (نادل طعام / عامل شحن) مقابل عمل فعلي كمدير فرع.</li>
                <li>كشوفات برنامج المحاسبة (250 DR) الصادرة باسم المستخدم (MARUF).</li>
                <li>سجلات مبيعات فرع بركاء القياسية: إدارة مبيعات تصل إلى (53,000 ر.ع شهرياً).</li>
                <li>كشوفات الحسابات الجارية الموقعة للزبائن وإدارة الائتمان التجاري.</li>
              </ul>
            </div>

            {/* Tab 4 */}
            <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
              <div className="font-bold text-[#0b1f3a] mb-1">الطيّة الرابعة: إثبات التلاعب الإداري والرد على ادعاءات الكفيل (Tab 4)</div>
              <ul className="list-disc list-inside text-[11px] text-slate-700 space-y-0.5">
                <li>سجلات تغيير كلمة سر النظام المحاسبي واصطناع عجز وهمي (2,200 ر.ع) أثناء إجازة العامل.</li>
                <li>شهادة الإجازة المرضية المعتمدة (27/01/2026م) المحمية بالمادة (66).</li>
                <li>خطابات الاعتراض والاحتجاج المكتوبة المسلمة للإدارة اعتراضاً على الخصومات.</li>
              </ul>
            </div>
          </div>

          {/* Financial Summary */}
          <div className="bg-amber-400 text-slate-950 p-2.5 rounded font-bold text-xs flex justify-between items-center mb-6">
            <span>إجمالي المطالبات العمالية الواجبة الأداء (7,642.000 OMR):</span>
            <span className="font-mono text-sm">7,642.000 ر.ع</span>
          </div>

          {/* Signature */}
          <div className="pt-3 border-t border-slate-300 flex justify-between items-end text-xs">
            <div>
              <span className="text-slate-500">توقيع مقدم الملف (العامل):</span>
              <div className="w-40 border-b border-slate-700 mt-6 pt-1 text-[10px] text-slate-400">التوقيع / البصمة</div>
            </div>
            <div className="text-left font-mono">
              <span className="text-slate-500">التاريخ:</span>
              <div className="font-bold text-slate-900 mt-1">____ / ____ / 2026م</div>
            </div>
          </div>
        </div>

        {/* Page Break for Print */}
        <div className="page-break hidden print:block" />

        {/* ========================================================
            PAGE 2: ARABIC COURT PETITION (OFFICIAL SUBMISSION)
        ======================================================== */}
        <div
          id="court-petition-ar"
          dir="rtl"
          className={`a4-page bg-white p-8 sm:p-12 border border-slate-300 shadow-md max-w-[210mm] mx-auto text-slate-950 font-['Cairo','Amiri',serif] leading-relaxed relative ${
            activeScreenTab === 'ar' ? 'block' : 'hidden print:block'
          }`}
          style={{ minHeight: '297mm' }}
        >
          {/* Header */}
          <div className="text-center pb-5 mb-5 border-b-2 border-double border-amber-600/70">
            <div className="text-xs font-bold tracking-wider text-slate-800">سلطنة عمان — المجلس الأعلى للقضاء</div>
            <div className="text-xs text-slate-600 mt-1">المحكمة الابتدائية بالسيب — الدائرة العمالية</div>
            <div className="text-xs font-mono text-slate-700 mt-1">
              رقم الدعوى: <span className="font-bold text-slate-900">CRT2601-3344</span> | الشكوى: {ministry.firstComplaintRef} / {ministry.secondComplaintRef}
            </div>
          </div>

          <div className="bg-slate-100 p-2.5 rounded border border-slate-300 font-bold text-xs sm:text-sm text-center mb-4">
            الموضوع: مذكرة شارحة ومطالبة بحقوق عمالية وتفنيد ادعاءات الخصم (7,642.000 ر.ع)
          </div>

          {/* Parties */}
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-xs mb-4 space-y-1">
            <div><b>المدعي (العامل):</b> {plaintiff.fullName} (معروف) | <b>الرقم المدني:</b> {plaintiff.civilId} | <b>تصريح العمل:</b> {plaintiff.workPermit}</div>
            <div><b>المدعى عليها:</b> {defendant.companyNameAr} | <b>س.ت:</b> {defendant.crNumber}</div>
          </div>

          {/* Facts */}
          <div className="text-xs space-y-1.5 mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">أولاً: وقائع الدعوى والتعسف الإداري</div>
            <p>1. أعمل لدى الشركة المدعى عليها منذ يوليو 2015م (خدمة مستمرة لأكثر من 11 سنة) كمدير لفرع بركاء ومسؤول مبيعات الألمنيوم والزجاج بمبيعات بلغت 53,000 ر.ع شهرياً، رغم تسجيل مهنتي صورياً كـ (نادل طعام / عامل شحن).</p>
            <p>2. راتبي التعاقدي الأساسي الثابت بكشوفات بنك مسقط (WPS) هو 250 ريالاً عمانياً، إلا أن الشركة سجلت عقداً صورياً بـ 60 ريالاً تحايلاً على القانون.</p>
            <p>3. قامت الشركة بخصم 50 ر.ع شهرياً من راتبي تعسفياً، واقتطاع 600 ر.ع تكاليف حجر كوفيد-19، و217 ر.ع فواتير أوريدو للفرع، ليصل صافي ما أستلمه إلى 60–80 ر.ع فقط.</p>
            <p>4. سجلت الشركة بلاغ ترك عمل كيدي برقم (DCA-20260802114) أثناء وجود شكوى عمالية نشطة، وقد تقدمت بتظلم رسمي برقم (REFXG 20261009001).</p>
          </div>

          {/* Legal Basis */}
          <div className="text-xs space-y-1 mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">ثانياً: الأسانيد القانونية (المرسوم السلطاني رقم 53/2023)</div>
            <p>• <b>المادة (37):</b> استحقاق مكافأة نهاية الخدمة الشاملة عن 11 سنة خدمة متواصلة على أساس الأجر الفعلي 250 ر.ع.</p>
            <p>• <b>المادتان (55 و 58):</b> حظر الخصم الاستقطاعي من أجر العامل دون موافقة كتابية أو حكم قضائي، واعتماد كشوفات البنك (WPS) كإثبات قاطع للأجر.</p>
            <p>• <b>المادة (66):</b> استحقاق بدل الإجازات السنوية والمرضية المدفوعة.</p>
            <p>• <b>المادة (114):</b> حق العامل في البقاء المشروع داخل عمان حتى الفصل النهائي.</p>
          </div>

          {/* Claims Table */}
          <div className="mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5 text-xs mb-2">ثالثاً: جدول المطالبات المالية التفصيلية</div>
            <table className="w-full text-xs border border-slate-300 border-collapse">
              <thead>
                <tr className="bg-[#0b1f3a] text-white">
                  <th className="p-2 text-right">بند المطالبة</th>
                  <th className="p-2 text-right">السند القانوني</th>
                  <th className="p-2 text-left">المبلغ (ر.ع)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr><td>1. مكافأة نهاية الخدمة (EOSB)</td><td>المادة (37) — 11 سنة</td><td className="p-2 text-left font-mono font-bold">2,125.000 OMR</td></tr>
                <tr className="bg-slate-50"><td>2. أجور فترة كورونا المتأخرة</td><td>حماية الأجور — 12 شهراً</td><td className="p-2 text-left font-mono font-bold">3,000.000 OMR</td></tr>
                <tr><td>3. استرداد الخصومات غير القانونية</td><td>المواد (55, 58, 59)</td><td className="p-2 text-left font-mono font-bold">1,417.000 OMR</td></tr>
                <tr className="bg-slate-50"><td>4. بدل الإجازات السنوية المجمعة</td><td>المادة (66) — 11 سنة</td><td className="p-2 text-left font-mono font-bold">1,100.000 OMR</td></tr>
                <tr className="bg-amber-400 text-slate-950 font-bold">
                  <td colSpan={2} className="p-2 font-extrabold">إجمالي المبالغ المطالب بها</td>
                  <td className="p-2 text-left font-mono font-extrabold">7,642.000 OMR</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Prayers */}
          <div className="text-xs space-y-1 mb-5">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">رابعاً: الطلبات الختامية</div>
            <p>1. إلزام المدعى عليها بدفع إجمالي المستحقات العمالية وقدرها (7,642.000 ر.ع).</p>
            <p>2. إبطال وشطب بلاغ ترك العمل الكيدي (DCA-20260802114) نهائياً.</p>
            <p>3. إلزام المدعى عليها بتسليم جواز السفر الأصلي المحتجز تعسفياً.</p>
            <p>4. منح العامل موافقة نقل الكفالة (التنازل) للعمل لدى صاحب عمل آخر.</p>
          </div>

          {/* Signature */}
          <div className="pt-3 border-t border-slate-300 flex justify-between items-end text-xs">
            <div>
              <span className="text-slate-500">مقدم الطلب (العامل):</span>
              <div className="font-bold text-slate-900 mt-0.5">{plaintiff.fullName} (معروف)</div>
              <div className="w-40 border-b border-slate-700 mt-5 pt-1 text-[10px] text-slate-400">التوقيع / البصمة</div>
            </div>
            <div className="text-left font-mono">
              <span className="text-slate-500">التاريخ:</span>
              <div className="font-bold text-slate-900 mt-0.5">____ / ____ / 2026م</div>
            </div>
          </div>
        </div>

        {/* Page Break for Print */}
        <div className="page-break hidden print:block" />

        {/* ========================================================
            PAGE 3: ENGLISH OFFICIAL PETITION
        ======================================================== */}
        <div
          id="court-petition-en"
          dir="ltr"
          className={`a4-page bg-white p-8 sm:p-12 border border-slate-300 shadow-md max-w-[210mm] mx-auto text-slate-950 font-['Plus_Jakarta_Sans',system-ui,sans-serif] leading-relaxed relative ${
            activeScreenTab === 'en' ? 'block' : 'hidden print:block'
          }`}
          style={{ minHeight: '297mm' }}
        >
          {/* Header */}
          <div className="text-center pb-5 mb-5 border-b-2 border-double border-amber-600/70">
            <div className="text-xs font-bold tracking-wider text-slate-800 uppercase">Sultanate of Oman — Supreme Judicial Council</div>
            <div className="text-xs text-slate-600 mt-1">SEEB PRIMARY COURT — LABOUR CIRCUIT</div>
            <div className="text-xs font-mono text-slate-700 mt-1">
              Case No: <span className="font-bold text-slate-900">CTR2601-3344</span> | MOL Ref: {ministry.firstComplaintRef} / {ministry.secondComplaintRef}
            </div>
          </div>

          <div className="bg-slate-100 p-2.5 rounded border border-slate-300 font-bold text-xs sm:text-sm text-center mb-4">
            Subject: Statement of Labour Claim & Rebuttal of Malicious Absconding Report (7,642.000 OMR)
          </div>

          {/* Parties */}
          <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-xs mb-4 space-y-1">
            <div><b>Claimant:</b> {plaintiff.fullName} ("Maruf") | <b>Civil ID:</b> {plaintiff.civilId} | <b>Work Permit:</b> {plaintiff.workPermit}</div>
            <div><b>Defendant:</b> {defendant.companyName} | <b>CR No:</b> {defendant.crNumber}</div>
          </div>

          {/* Facts */}
          <div className="text-xs space-y-1.5 mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">1. Statement of Facts & Employer Breaches</div>
            <p>1. Claimant served continuously for 11 years (July 2015–2026) as Barka Branch Manager achieving 53,000 OMR/month sales, despite employer misclassifying his visa title as "Waiter/Loader".</p>
            <p>2. The contractual basic wage established via Bank Muscat WPS is 250 OMR, refuting any simulated 60 OMR paper contract.</p>
            <p>3. Employer unlawfully deducted 50 OMR/month, 600 OMR COVID penalty, and 217 OMR Ooredoo line charges, slashing net payouts to 60–80 OMR.</p>
            <p>4. Employer retaliated with false runaway report (DCA-20260802114) while labour complaint was pending.</p>
          </div>

          {/* Legal Basis */}
          <div className="text-xs space-y-1 mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">2. Statutory Grounds (Royal Decree No. 53/2023)</div>
            <p>• <b>Article 37:</b> Statutory End of Service Benefits (EOSB) for 11 years on 250 OMR baseline.</p>
            <p>• <b>Articles 55 & 58:</b> Prohibition of arbitrary wage deductions and primacy of WPS records.</p>
            <p>• <b>Article 66:</b> Statutory accrued annual and paid sick leave compensation.</p>
            <p>• <b>Article 114:</b> Right to remain lawfully in Oman until final court judgment.</p>
          </div>

          {/* Claims Table */}
          <div className="mb-4">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5 text-xs mb-2">3. Itemised Financial Claims Breakdown</div>
            <table className="w-full text-xs border border-slate-300 border-collapse">
              <thead>
                <tr className="bg-[#0b1f3a] text-white">
                  <th className="p-2 text-left">Claim Item</th>
                  <th className="p-2 text-left">Statutory Basis</th>
                  <th className="p-2 text-right">Amount (OMR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr><td>1. End of Service Benefits (EOSB)</td><td>Article 37 — 11 Years</td><td className="p-2 text-right font-mono font-bold">2,125.000 OMR</td></tr>
                <tr className="bg-slate-50"><td>2. COVID-19 Unpaid Wages</td><td>Wage Protection — 12 Mos</td><td className="p-2 text-right font-mono font-bold">3,000.000 OMR</td></tr>
                <tr><td>3. Refund of Illegal Deductions</td><td>Articles 55, 58 & 59</td><td className="p-2 text-right font-mono font-bold">1,417.000 OMR</td></tr>
                <tr className="bg-slate-50"><td>4. Accrued Annual Leave Pay</td><td>Article 66 — 11 Years</td><td className="p-2 text-right font-mono font-bold">1,100.000 OMR</td></tr>
                <tr className="bg-amber-400 text-slate-950 font-bold">
                  <td colSpan={2} className="p-2 font-extrabold">TOTAL STATUTORY DEMAND</td>
                  <td className="p-2 text-right font-mono font-extrabold">7,642.000 OMR</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Prayers */}
          <div className="text-xs space-y-1 mb-5">
            <div className="font-bold text-[#0b1f3a] border-b border-amber-500 pb-0.5">4. Formal Prayers for Judicial Relief</div>
            <p>1. Order Defendant to remit total employment entitlements of <b>7,642.000 OMR</b>.</p>
            <p>2. Quash and expunge false absconding report <b>DCA-20260802114</b>.</p>
            <p>3. Order unconditional surrender of Claimant original passport.</p>
            <p>4. Grant permission for sponsorship transfer (NOC release).</p>
          </div>

          {/* Signature */}
          <div className="pt-3 border-t border-slate-300 flex justify-between items-end text-xs">
            <div>
              <span className="text-slate-500">Claimant:</span>
              <div className="font-bold text-slate-900 mt-0.5">{plaintiff.fullName} ("Maruf")</div>
              <div className="w-40 border-b border-slate-700 mt-5 pt-1 text-[10px] text-slate-400">Signature</div>
            </div>
            <div className="text-right font-mono">
              <span className="text-slate-500">Date:</span>
              <div className="font-bold text-slate-900 mt-0.5">____ / ____ / 2026</div>
            </div>
          </div>
        </div>

        {/* ========================================================
            PAGE 4: SCREEN-ONLY BANGLA GUIDE
        ======================================================== */}
        {activeScreenTab === 'bn' && (
          <div className="bn-screen-guide bg-white p-8 sm:p-12 border border-amber-300 rounded-xl shadow-md max-w-[210mm] mx-auto text-slate-950 font-['Hind_Siliguri',sans-serif] leading-relaxed relative no-print">
            <div className="p-3 bg-amber-50 border border-amber-300 rounded-lg text-xs text-amber-900 mb-6 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <b>মারুফ ভাইয়ের জন্য আদালত সহায়িকা:</b> এই ৩টি অফিসিয়াল পেজ (কভার পেজ, আরবি পিটিশন ও ইংরেজি পিটিশন) প্রিন্ট করে ৩টি সেটে সাজিয়ে নিন। আদালতে জমা দিলে কোনো ক্লার্ক বা বিচারক আপনার ফাইল ফিরিয়ে দিতে পারবে না।
              </span>
            </div>

            <h2 className="text-base font-bold text-[#0b1f3a] mb-2">আদালত ফাইলিংয়ের ৩টি সেটের নিয়ম</h2>
            <div className="space-y-2 text-xs text-slate-700 mb-4">
              <p><b>সেট ১ (বিচারক):</b> আরবি কভার পেজ + আরবি পিটিশন + QR কোডসহ মূল কাগজপত্রের রঙিন কপি।</p>
              <p><b>সেট ২ (ক্লার্ক / বিবাদী):</b> পূর্ণাঙ্গ কপি যা আদালতের ফাইলে জমা থাকবে।</p>
              <p><b>সেট ৩ (আপনার নিজের কাছে):</b> শুনানির দিন সাথে রাখার কপি।</p>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-xs font-mono space-y-1">
              <div className="flex justify-between"><span>১. চাকরির সমাপ্তি সুবিধা (EOSB):</span><b>2,125.000 OMR</b></div>
              <div className="flex justify-between"><span>২. করোনাকালীন অনাদায়ী বেতন:</span><b>3,000.000 OMR</b></div>
              <div className="flex justify-between"><span>৩. অবৈধ কর্তনের ফেরত:</span><b>1,417.000 OMR</b></div>
              <div className="flex justify-between"><span>৪. সঞ্চিত বাৎসরিক ছুটির বেতন:</span><b>1,100.000 OMR</b></div>
              <div className="flex justify-between pt-2 border-t border-slate-300 text-sm font-bold text-amber-800">
                <span>সর্বমোট দাবি:</span><span>7,642.000 OMR</span>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
