import React from 'react';
import { FileSpreadsheet, AlertTriangle, Copy, Check, Printer, Scale, ArrowRight } from 'lucide-react';
import { Language } from '../data/translations';
import { FORENSIC_AUDIT_ITEMS, FORENSIC_AUDIT_TOTAL, JAN_FEB_2026_RECONSTRUCTION } from '../data/forensicData';

interface ForensicAuditViewProps {
  lang: Language;
  onNavigate: (section: string) => void;
  onPrint: () => void;
}

export const ForensicAuditView: React.FC<ForensicAuditViewProps> = ({
  lang,
  onNavigate,
  onPrint
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopyReconstruction = () => {
    navigator.clipboard.writeText(JAN_FEB_2026_RECONSTRUCTION);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span>Forensic Ledger Accounting Report · Section 3</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'ফরেনসিক অডিট ও বেতন পুনর্গঠন প্রতিবেদন' : lang === 'ar' ? 'التقرير المحاسبي الجنائي وإعادة بناء الرواتب' : 'Forensic Audit & Wage Reconstruction Report'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'আল ইয়ারমুক ট্রেডিং কর্তৃক ১১ বছরে জোরপূর্বক কেটে নেওয়া ১,৯৪৭.৭০০ রিয়াল বেআইনি কর্তনের বিস্তারিত অডিট এবং জানুয়ারি-ফেব্রুয়ারি ২০২৬ এর পে-রোল পুনর্গঠন।'
                : lang === 'ar'
                ? 'تدقيق محاسبي جنائي يوثق استقطاع 1,947.700 ر.ع من رواتب العامل دون وجه حق، مع تفكيك وتوزيع راتب يناير/فبراير 2026م.'
                : 'Itemized forensic accounting audit documenting 1,947.700 OMR in unlawful salary confiscations, with payroll reconstruction.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onPrint}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'অডিট প্রিন্ট' : lang === 'ar' ? 'طباعة التقرير' : 'Print Audit'}</span>
            </button>
            <button
              onClick={() => onNavigate('sub-ledger-contamination')}
              className="px-3 py-2 text-xs font-semibold text-amber-900 bg-amber-400 hover:bg-amber-300 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <span>{lang === 'bn' ? 'সাব-লেজার টেম্পারিং' : lang === 'ar' ? 'تلوث السجل' : 'Sub-Ledger Logs'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Total Summary Highlight */}
        <div className="mt-4 p-4 rounded-xl bg-red-50 border border-red-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold text-lg shrink-0">
              🚨
            </div>
            <div>
              <div className="text-xs font-bold text-red-950 uppercase tracking-wider">
                {lang === 'bn' ? 'মোট বেআইনি কর্তনের অডিট পরিমাণ' : lang === 'ar' ? 'إجمالي الخصومات غير القانونية الموثقة' : 'Total Documented Unlawful Deductions'}
              </div>
              <div className="text-xs text-red-800 mt-0.5">
                {lang === 'bn' ? 'ওমান শ্রম আইনের ৫৫, ৫৮ ও ৫৯ ধারার সুস্পষ্ট বরখেলাপ' : lang === 'ar' ? 'مخالفة صريحة للمواد 55 و 58 و 59 من قانون العمل' : 'Direct violation of Articles 55, 58 & 59 (RD 53/2023)'}
              </div>
            </div>
          </div>
          <div className="text-right sm:border-l sm:border-red-200 sm:pl-6">
            <div className="text-2xl sm:text-3xl font-extrabold text-red-700 font-mono tabular-nums">
              {FORENSIC_AUDIT_TOTAL.toFixed(3)}
              <span className="text-xs font-sans font-bold text-slate-700 ml-1.5">OMR</span>
            </div>
          </div>
        </div>
      </div>

      {/* Forensic Audit Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 mb-1">
          {lang === 'bn' ? '১,৯৪৭.৭০০ রিয়াল বেআইনি কর্তনের পূর্ণাঙ্গ সারণি' : lang === 'ar' ? 'جدول التدقيق الجنائي للخصومات السبعة' : 'Forensic Audit Schedule of 7 Unlawful Deductions'}
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          All entries cross-referenced against Bank Muscat statements, Mohammed Hanif ERP ledgers, and court filings.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-[#0b1f3a] text-white">
                <th className="py-3 px-3 w-12 font-semibold">#</th>
                <th className="py-3 px-4 font-semibold">{lang === 'bn' ? 'খাতের বিবরণ' : lang === 'ar' ? 'البند' : 'Audit Item'}</th>
                <th className="py-3 px-4 font-semibold">{lang === 'bn' ? 'বাস্তব প্রমাণ ও পটভূমি' : lang === 'ar' ? 'التصنيف والوقائع' : 'Classification & Facts'}</th>
                <th className="py-3 px-4 font-semibold text-right">{lang === 'bn' ? 'পরিমাণ (OMR)' : lang === 'ar' ? 'المبلغ (ر.ع)' : 'Amount (OMR)'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              {FORENSIC_AUDIT_ITEMS.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-slate-500">{item.id}</td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {lang === 'bn' ? item.itemBn : lang === 'ar' ? item.itemAr : item.itemEn}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600">
                    {lang === 'bn' ? item.classificationBn : lang === 'ar' ? item.classificationAr : item.classificationEn}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-red-700 tabular-nums">
                    {item.amountOMR.toFixed(3)}
                  </td>
                </tr>
              ))}
              <tr className="bg-amber-400 text-slate-950 font-bold border-t-2 border-amber-600">
                <td colSpan={3} className="py-3.5 px-4 font-extrabold uppercase">
                  {lang === 'bn' ? 'সর্বমোট পুনরুদ্ধারযোগ্য অবৈধ কর্তন' : lang === 'ar' ? 'إجمالي الخصومات التعسفية المطلوب استردادها' : 'TOTAL FORENSIC AUDIT DEDUCTIONS'}
                </td>
                <td className="py-3.5 px-4 text-right font-mono font-extrabold text-base tabular-nums">
                  {FORENSIC_AUDIT_TOTAL.toFixed(3)} OMR
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Jan/Feb 2026 Salary Reconstruction Monospace Block */}
      <div className="bg-[#0b1f3a] text-slate-200 rounded-xl p-6 shadow-md border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <h3 className="font-mono font-bold text-sm text-white uppercase tracking-wider">
              {lang === 'bn' ? 'জানুয়ারি/ফেব্রুয়ারি ২০২৬ পে-রোল পুনর্গঠন বিশ্লেষণ' : lang === 'ar' ? 'إعادة بناء وتفكيك راتب يناير وفبراير 2026م' : 'Forensic Payroll Reconstruction: Jan/Feb 2026'}
            </h3>
          </div>
          <button
            onClick={handleCopyReconstruction}
            className="self-start sm:self-auto px-3 py-1.5 text-xs font-mono font-semibold bg-slate-800 hover:bg-slate-700 text-amber-300 rounded flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Breakdown'}</span>
          </button>
        </div>

        <pre className="font-mono text-xs sm:text-[13px] text-amber-200/90 bg-slate-950/80 p-4 rounded-lg overflow-x-auto leading-relaxed border border-slate-800">
          {JAN_FEB_2026_RECONSTRUCTION}
        </pre>

        <div className="mt-4 text-xs text-slate-400 leading-relaxed border-t border-slate-800 pt-3">
          <b className="text-amber-400">Judicial Takeaway:</b> The employer split payout into an 80 OMR bank error plus 77.300 OMR cash following Maruf's written objection, proving employer consciousness of unlawful wage slashing.
        </div>
      </div>

    </div>
  );
};
