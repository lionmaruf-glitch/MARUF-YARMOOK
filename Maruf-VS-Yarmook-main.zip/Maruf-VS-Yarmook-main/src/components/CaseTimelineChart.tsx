import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
  Cell
} from 'recharts';
import {
  Calendar,
  Clock,
  AlertTriangle,
  Scale,
  Building2,
  FileText,
  ShieldAlert,
  ChevronRight,
  ExternalLink,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { Language } from '../data/translations';

export interface MilestoneEvent {
  id: string;
  dateStr: string;
  timestamp: number; // for chronological sorting
  year: number;
  labelEn: string;
  labelAr: string;
  labelBn: string;
  phase: 'service' | 'covid_breach' | 'mol_filing' | 'court_action' | 'legal_future';
  phaseNameEn: string;
  phaseNameAr: string;
  phaseNameBn: string;
  severity: number; // 1 to 5 scale
  financialExposureOMR: number; // Cumulative or event claim amount
  cumulativeClaimOMR: number;
  caseRef?: string;
  statutoryArticle: string;
  summaryEn: string;
  summaryAr: string;
  summaryBn: string;
  evidenceRefId?: string;
  actionRequired: string;
}

export const CASE_MILESTONES: MilestoneEvent[] = [
  {
    id: 'm1',
    dateStr: '2015-07-01',
    timestamp: new Date('2015-07-01').getTime(),
    year: 2015,
    labelEn: 'Contract Start & Oman Arrival',
    labelAr: 'بدء العمل والقدوم إلى سلطنة عمان',
    labelBn: 'চাকরি শুরু ও ওমানে আগমন',
    phase: 'service',
    phaseNameEn: 'Employment & Building Barka',
    phaseNameAr: 'الخدمة وتأسيس فرع بركاء',
    phaseNameBn: 'চাকরিকাল ও বারকা শাখা প্রতিষ্ঠা',
    severity: 1,
    financialExposureOMR: 300,
    cumulativeClaimOMR: 0,
    caseRef: 'CIVIL-ID-103352388',
    statutoryArticle: 'Royal Decree 53/2023 - Art. 6 (Passport retention)',
    summaryEn: 'Recruited in July 2015. Visa title designated as Waiter/Loader (60 OMR dummy contract), but actual role was Barka store in-charge at 300 OMR gross. Passport unlawfully retained from day one.',
    summaryAr: 'بدء العمل براتب إجمالي 300 ر.ع. المسمى في التأشيرة نادل طعام بينما الوظيفة الفعلية مسؤول فرع بركاء. تم حجز الجواز بالمخالفة للمادة 6.',
    summaryBn: 'জুলাই ২০১৫ এ যোগদান। পাসপোর্টে ভুয়া পদবি (ওয়েটার/লোডার) কিন্তু মূল কাজ বারকা শাখা ইনচার্জ। প্রথম দিন থেকেই পাসপোর্ট জোরপূর্বক জব্দ।',
    evidenceRefId: 'CIVIL-ID-103352388',
    actionRequired: 'Grounding 11 years unbroken service proof under Oman Labour Law.'
  },
  {
    id: 'm2',
    dateStr: '2018-01-15',
    timestamp: new Date('2018-01-15').getTime(),
    year: 2018,
    labelEn: 'Barka Industrial Branch Founded',
    labelAr: 'تأسيس فرع بركاء الصناعية من الصفر',
    labelBn: 'বারকা শিল্পনগরী শাখা প্রতিষ্ঠা',
    phase: 'service',
    phaseNameEn: 'Employment & Building Barka',
    phaseNameAr: 'الخدمة وتأسيس فرع بركاء',
    phaseNameBn: 'চাকরিকাল ও বারকা শাখা প্রতিষ্ঠা',
    severity: 2,
    financialExposureOMR: 0,
    cumulativeClaimOMR: 0,
    caseRef: 'BARKA-BRANCH-EST-2018',
    statutoryArticle: 'Commercial Agency & Actual Managerial Role',
    summaryEn: 'Built Barka Sanaiya branch from ground zero. Expanded sales to 53,000 OMR/month with 180+ clients. Proves true executive management capacity over fabricated manual laborer visa title.',
    summaryAr: 'بناء فرع بركاء الصناعية للألمنيوم والزجاج ورفع المبيعات الشهرية إلى 53,000 ر.ع عبر 180 عميل، مما يثبت الإدارة الفعلية وينسف مسمى نادل.',
    summaryBn: 'বারকা শিল্প এলাকায় নতুন শাখা শূন্য থেকে দাঁড় করানো এবং মাসিক ৫৩,০০০ রিয়াল লেনদেনে উন্নীত করা, যা ম্যানেজারের দায়িত্ব প্রমাণ করে।',
    evidenceRefId: 'ROLE-BARKA-STORE-01',
    actionRequired: 'Submit sales records and client deposit receipts to disprove manual worker status.'
  },
  {
    id: 'm3',
    dateStr: '2020-04-01',
    timestamp: new Date('2020-04-01').getTime(),
    year: 2020,
    labelEn: 'COVID Wage Freeze & Arbitrary Cuts',
    labelAr: 'إغلاق كورونا واقتطاع الرواتب التعسفي',
    labelBn: 'করোনাকালীন বেতন স্থগিত ও অবৈধ কর্তন',
    phase: 'covid_breach',
    phaseNameEn: 'Employer Breaches & Cuts',
    phaseNameAr: 'المخالفات والاقتطاعات التعسفية',
    phaseNameBn: 'কোম্পানির চুক্তি লঙ্ঘন ও অবৈধ কর্তন',
    severity: 4,
    financialExposureOMR: 3000,
    cumulativeClaimOMR: 3000,
    caseRef: 'COVID-WAGE-CUTS-2020',
    statutoryArticle: 'RD 53/2023 - Articles 53, 55 & 58',
    summaryEn: 'Forced salary demotion to 250 OMR basic; commission stripped. 12 months wages withheld during lockdown disruptions (3,000 OMR) plus 50 OMR/month illegal quarantine deduction (600 OMR).',
    summaryAr: 'تجميد الرواتب وخصم 12 شهراً بقيمة 3,000 ر.ع واقتطاع 50 ر.ع شهرياً بزعم الحجر الصحي دون إذن قضائي أو كتابي.',
    summaryBn: 'করোনা লকডাউনের অজুহাতে ১২ মাসের ৩,০০০ রিয়াল বেতন স্থগিত এবং প্রতি মাসে ৫০ রিয়াল করে ৬০০ রিয়াল অবৈধ কর্তন।',
    evidenceRefId: 'COVID-FLIGHT-TICKETS-01',
    actionRequired: 'Produce cancelled airline ticket vouchers & WPS unremitted logs.'
  },
  {
    id: 'm4',
    dateStr: '2024-07-06',
    timestamp: new Date('2024-07-06').getTime(),
    year: 2024,
    labelEn: 'Nazar Ledger Closed & Contaminated',
    labelAr: 'إقفال دفتر النزار وتلويث السجل الفرعي',
    labelBn: 'নজর ডায়েরি ক্লোজিং ও ভুয়া লোন যুক্তকরণ',
    phase: 'covid_breach',
    phaseNameEn: 'Employer Breaches & Cuts',
    phaseNameAr: 'المخالفات والاقتطاعات التعسفية',
    phaseNameBn: 'কোম্পানির চুক্তি লঙ্ঘন ও অবৈধ কর্তন',
    severity: 4,
    financialExposureOMR: 400,
    cumulativeClaimOMR: 4417,
    caseRef: 'LEDGER-CONTAMINATION-2024',
    statutoryArticle: 'RD 53/2023 - Art. 58 (Prohibition of unauthorised deductions)',
    summaryEn: 'Sub-ledger closed on 06/07/2024 with a net CREDIT balance of 21.80 OMR in Maruf’s favor. Employer fabricated third-party debts of Shah Jahan (300 OMR) and Hafez (100 OMR) onto Maruf.',
    summaryAr: 'إقفال حساب سلفيات معروف برصيد دائن 21.80 ر.ع لصالحه، مع دس سلفيات عمال آخرين (شاه جهان 300 وحافظ 100) لإلصاق دين وهمي به.',
    summaryBn: '০৬/০৭/২০২৪ তারিখে হিসাব মারুফের পক্ষে ২১.৮০ ওমানি রিয়াল ক্রেডিট দিয়ে ক্লোজ হয়। পরবর্তীতে শাহজাহান ও হাফেজের ঋণ জোরপূর্বক যুক্ত করা হয়।',
    evidenceRefId: 'CONTAM-SHAHJAHAN-300',
    actionRequired: 'Forensic audit submission exposing cross-worker ledger pollution.'
  },
  {
    id: 'm5',
    dateStr: '2026-03-15',
    timestamp: new Date('2026-03-15').getTime(),
    year: 2026,
    labelEn: 'MOL Complaint #1 Filed',
    labelAr: 'قيد الشكوى العمالية الأولى بوزارة العمل',
    labelBn: 'শ্রম মন্ত্রণালয়ে ১ম আনুষ্ঠানিক অভিযোগ দায়ের',
    phase: 'mol_filing',
    phaseNameEn: 'Ministry & Grievance Actions',
    phaseNameAr: 'إجراءات وزارة العمل والتظلمات',
    phaseNameBn: 'শ্রম মন্ত্রণালয়ের বিচারিক পদক্ষেপ',
    severity: 3,
    financialExposureOMR: 7642,
    cumulativeClaimOMR: 7642,
    caseRef: 'REF2603150080',
    statutoryArticle: 'RD 53/2023 - Art. 114 (Labour Dispute Protection)',
    summaryEn: 'Official complaint REF2603150080 registered with the Ministry of Labour demanding 7,642 OMR in full legal entitlements. Triggers statutory protection under Article 114.',
    summaryAr: 'تسجيل الشكوى الرسمية رقم REF2603150080 للمطالبة بـ 7,642 ر.ع وتفعيل الحماية القانونية من الإجراءات الانتقامية وفق المادة 114.',
    summaryBn: 'শ্রম মন্ত্রণালয়ে REF2603150080 নম্বরে অভিযোগ দায়ের করে ৭,৬৪২ রিয়াল দাবি। শ্রম আইনের ১১৪ ধারা অনুযায়ী আইনি সুরক্ষা বলবৎ।',
    evidenceRefId: 'MOL-COMPLAINT-REF2603150080',
    actionRequired: 'Verify certified MOL electronic timestamp prior to employer absconding attempts.'
  },
  {
    id: 'm6',
    dateStr: '2026-04-21',
    timestamp: new Date('2026-04-21').getTime(),
    year: 2026,
    labelEn: 'MOL Settlement Session (Employer Rejected)',
    labelAr: 'جلسة تسوية وزارة العمل (رفض صاحب العمل)',
    labelBn: 'শ্রম মন্ত্রণালয়ের আপস বৈঠক (মালিকের অস্বীকৃতি)',
    phase: 'mol_filing',
    phaseNameEn: 'Ministry & Grievance Actions',
    phaseNameAr: 'إجراءات وزارة العمل والتظلمات',
    phaseNameBn: 'শ্রম মন্ত্রণালয়ের বিচারিক পদক্ষেপ',
    severity: 3,
    financialExposureOMR: 7642,
    cumulativeClaimOMR: 7642,
    caseRef: 'MOL-HEARING-2026-04',
    statutoryArticle: 'RD 53/2023 - Amicable Conciliation Procedure',
    summaryEn: 'Labour conciliator summoned employer Mohammed Hanif Group. Employer refused to settle 11 years EOSB and COVID arrears, insisting on the 60 OMR dummy contract figure.',
    summaryAr: 'انعقاد جلسة التسوية الودية ورفض ممثل الشركة دفع المستحقات الحقيقية متمسكاً براتب العقد الصوري (60 ر.ع).',
    summaryBn: 'আপস নিষ্পত্তির বৈঠকে মালিকপক্ষ ১১ বছরের গ্র্যাচুইটি ও বেতন দিতে অস্বীকৃতি জানিয়ে ভুয়া ৬০ রিয়ালের চুক্তির অজুহাত দেয়।',
    evidenceRefId: 'MOL-FIRST-HEARING-2026-04-21',
    actionRequired: 'Record employer bad-faith refusal for the Labour Court dossier.'
  },
  {
    id: 'm7',
    dateStr: '2026-06-15',
    timestamp: new Date('2026-06-15').getTime(),
    year: 2026,
    labelEn: 'False Absconding Attempt #1 REJECTED by MOL',
    labelAr: 'رفض بلاغ الهروب الكيدي الأول من وزارة العمل',
    labelBn: 'শ্রম মন্ত্রণালয় কর্তৃক ১ম মিথ্যা পলায়ন নোটিশ প্রত্যাখ্যান',
    phase: 'mol_filing',
    phaseNameEn: 'Ministry & Grievance Actions',
    phaseNameAr: 'إجراءات وزارة العمل والتظلمات',
    phaseNameBn: 'শ্রম মন্ত্রণালয়ের বিচারিক পদক্ষেপ',
    severity: 4,
    financialExposureOMR: 0,
    cumulativeClaimOMR: 7642,
    caseRef: 'DCA-20260615063',
    statutoryArticle: 'RD 53/2023 - Art. 114 & Anti-Retaliation Regulations',
    summaryEn: 'Employer attempted to lodge false absconding report DCA-20260615063. Ministry of Labour system immediately REJECTED it due to the pending labor dispute and court hearings.',
    summaryAr: 'وزارة العمل ترفض آلياً محاولة الشركة قيد بلاغ هروب كيدي لوجود نزاع عمالي قائم وجلسات قضائية منظورة.',
    summaryBn: 'মালিকপক্ষ প্রতিহিংসামূলকভাবে প্রথম পলায়ন রিপোর্ট করার চেষ্টা করলে বিচারাধীন মামলার কারণে শ্রম মন্ত্রণালয় তাৎক্ষণিক বাতিল করে।',
    evidenceRefId: 'MOL-REJECTED-ABSCOND-01',
    actionRequired: 'Use this official rejection to prove employer systematic retaliatory intent.'
  },
  {
    id: 'm8',
    dateStr: '2026-06-29',
    timestamp: new Date('2026-06-29').getTime(),
    year: 2026,
    labelEn: 'Barka Primary Court Hearing (09:00 AM)',
    labelAr: 'جلسة المحكمة الابتدائية ببركاء (الدائرة فردي مدني)',
    labelBn: 'বারকা প্রাথমিক আদালতে শুনানি (সকাল ৯:০০)',
    phase: 'court_action',
    phaseNameEn: 'Court Hearings & Judicial Decisions',
    phaseNameAr: 'الجلسات والأحكام القضائية',
    phaseNameBn: 'আদালতের শুনানি ও বিচারিক রায়',
    severity: 5,
    financialExposureOMR: 300,
    cumulativeClaimOMR: 7642,
    caseRef: '1005/1215/2026',
    statutoryArticle: 'Civil & Commercial Court Jurisdiction',
    summaryEn: 'Hearing in Barka Primary Court (Case 1005/1215/2026) regarding disputed 300 OMR loan and company assets. Defense presented proving loan belonged to co-worker Shah Jahan.',
    summaryAr: 'انعقاد جلسة محكمة بركاء في الدعوى رقم 1005/1215/2026 والدفع ببطلان ادعاء السلفة بمبلغ 300 ر.ع وإثبات أنها لسائق آخر (شاه جهان).',
    summaryBn: 'বারকা আদালতে শুনানি। ৩০০ রিয়াল ঋণের ভুয়া দাবি খণ্ডন করে প্রমাণ করা হয় যে এটি অন্য কর্মচারী শাহজাহানের।',
    evidenceRefId: 'COURT-BARKA-SUMMONS-2026',
    actionRequired: 'Submit certified minutes of session to Seeb Labour Circuit.'
  },
  {
    id: 'm9',
    dateStr: '2026-07-29',
    timestamp: new Date('2026-07-29').getTime(),
    year: 2026,
    labelEn: 'Reopened MOL Complaint #2 Registered',
    labelAr: 'إعادة قيد الشكوى العمالية الثانية (REF2607290085)',
    labelBn: 'শ্রম মন্ত্রণালয়ে ২য় অভিযোগ নবায়ন ও পুনঃদায়ের',
    phase: 'mol_filing',
    phaseNameEn: 'Ministry & Grievance Actions',
    phaseNameAr: 'إجراءات وزارة العمل والتظلمات',
    phaseNameBn: 'শ্রম মন্ত্রণালয়ের বিচারিক পদক্ষেপ',
    severity: 3,
    financialExposureOMR: 7642,
    cumulativeClaimOMR: 7642,
    caseRef: 'REF2607290085',
    statutoryArticle: 'Formal Referral to Labour Judiciary',
    summaryEn: 'Second formal complaint REF2607290085 opened to finalize court referral for Seeb Primary Court, documenting company continued refusal to remit basic wages and withholdings.',
    summaryAr: 'إعادة قيد الشكوى رسمياً تمهيداً للإحالة القضائية لمحكمة السيب، وتوثيق استمرار الامتناع عن سداد الأجور.',
    summaryBn: 'সিব আদালতে মামলা হস্তান্তরের প্রস্তুতি হিসেবে ২য় অভিযোগ REF2607290085 নথিভুক্ত করা হয়।',
    evidenceRefId: 'MOL-REOPEN-REF2607290085',
    actionRequired: 'Finalize referral protocol CTR-2601-33444.'
  },
  {
    id: 'm10',
    dateStr: '2026-08-02',
    timestamp: new Date('2026-08-02').getTime(),
    year: 2026,
    labelEn: 'Malicious Absconding Report DCA-20260802114',
    labelAr: 'بلاغ الهروب الكيدي الباطل (DCA-20260802114)',
    labelBn: 'মালিকের প্রতিহিংসামূলক ভুয়া পলায়ন নোটিশ',
    phase: 'covid_breach',
    phaseNameEn: 'Employer Breaches & Cuts',
    phaseNameAr: 'المخالفات والاقتطاعات التعسفية',
    phaseNameBn: 'কোম্পানির চুক্তি লঙ্ঘন ও অবৈধ কর্তন',
    severity: 5,
    financialExposureOMR: 0,
    cumulativeClaimOMR: 7642,
    caseRef: 'DCA-20260802114',
    statutoryArticle: 'RD 53/2023 - Art. 114 (Retaliation illegal while litigation active)',
    summaryEn: 'Employer filed malicious absconding notice DCA-20260802114 just 4 days after Maruf reopened MOL complaint, attempting to freeze residency and cause wrongful deportation.',
    summaryAr: 'قيد بلاغ هروب كيدي انتقامي بعد 4 أيام فقط من تجديد الشكوى، في انتهاك صارخ للمادة 114 وحظر البلاغات أثناء التقاضي.',
    summaryBn: 'অভিযোগ নবায়নের মাত্র ৪ দিন পর প্রতিশোধপরায়ণ হয়ে ভুয়া পলায়ন রিপোর্ট জারি করে যাতে দেশ থেকে বিতাড়ন করা যায়। এটি ১১৪ ধারার স্পষ্ট লঙ্ঘন।',
    evidenceRefId: 'ABSCOND-NOTICE-DCA-20260802114',
    actionRequired: 'Demand immediate cancellation and employer statutory fine under Omani Labour Law.'
  },
  {
    id: 'm11',
    dateStr: '2026-08-10',
    timestamp: new Date('2026-08-10').getTime(),
    year: 2026,
    labelEn: 'MOL Formal Referral to Seeb Court (CTR-2601-33444)',
    labelAr: 'إحالة النزاع رسمياً للمحكمة الابتدائية بالسيب',
    labelBn: 'সিব শ্রম আদালতে শ্রম মন্ত্রণালয়ের আনুষ্ঠানিক রেফারাল',
    phase: 'court_action',
    phaseNameEn: 'Court Hearings & Judicial Decisions',
    phaseNameAr: 'الجلسات والأحكام القضائية',
    phaseNameBn: 'আদালতের শুনানি ও বিচারিক রায়',
    severity: 4,
    financialExposureOMR: 7642,
    cumulativeClaimOMR: 7642,
    caseRef: 'CTR-2601-33444',
    statutoryArticle: 'RD 53/2023 - Art. 120 (Exemption from court fees)',
    summaryEn: 'Ministry of Labour formally closed conciliation and transmitted case docket to the Supreme Judicial Council / Seeb Primary Court under Referral CTR-2601-33444 with fee exemption.',
    summaryAr: 'إحالة الشكوى رسمياً من وزارة العمل إلى المحكمة الابتدائية بالسيب الدائرة العمالية مع الإعفاء الكامل من الرسوم القضائية (المادة 120).',
    summaryBn: 'শ্রম মন্ত্রণালয় আপস ব্যর্থ ঘোষণা করে সিব প্রাথমিক আদালতে কেস রেফার করে। ১২০ ধারা অনুযায়ী সম্পূর্ণ কোর্ট ফি মওকুফ।',
    evidenceRefId: 'MOL-REFERRAL-MEMO-2026',
    actionRequired: 'Submit comprehensive 79+ piece evidentiary dossier to Court Registrar.'
  },
  {
    id: 'm12',
    dateStr: '2026-10-09',
    timestamp: new Date('2026-10-09').getTime(),
    year: 2026,
    labelEn: 'Official Ministerial Grievance Filed',
    labelAr: 'قيد التظلم الرسمي لرفع بلاغ الهروب الكيدي',
    labelBn: 'মিথ্যা পলায়ন বাতিলের আনুষ্ঠানিক মন্ত্রণালয় আপিল',
    phase: 'mol_filing',
    phaseNameEn: 'Ministry & Grievance Actions',
    phaseNameAr: 'إجراءات وزارة العمل والتظلمات',
    phaseNameBn: 'শ্রম মন্ত্রণালয়ের বিচারিক পদক্ষেপ',
    severity: 4,
    financialExposureOMR: 0,
    cumulativeClaimOMR: 7642,
    caseRef: 'REFXG 20261009001',
    statutoryArticle: 'Ministerial Grievance Procedures & Art. 114',
    summaryEn: 'Formal grievance REFXG 20261009001 submitted to the Directorate of Absconding Work Reports demanding expedited cancellation based on judicial hearing dates.',
    summaryAr: 'تقديم تظلم قانوني رسمي موجه لمدير دائرة متابعة بلاغات ترك العمل لإلغاء البلاغ الكيدي استناداً لأسبقية الدعوى العمالية.',
    summaryBn: 'পলায়ন সংক্রান্ত অধিদপ্তরে REFXG 20261009001 নম্বরে আনুষ্ঠানিক রিভিউ আবেদন দায়ের।',
    evidenceRefId: 'GRIEVANCE-MOL-REFXG20261009001',
    actionRequired: 'Follow up electronic decree cancellation and obtain NOC certificate.'
  },
  {
    id: 'm13',
    dateStr: '2026-10-15',
    timestamp: new Date('2026-10-15').getTime(),
    year: 2026,
    labelEn: 'Seeb Primary Court Labour Circuit Hearing',
    labelAr: 'جلسة المحكمة الابتدائية بالسيب (الدائرة العمالية)',
    labelBn: 'সিব প্রাথমিক শ্রম আদালতে মূল বিচারিক শুনানি',
    phase: 'court_action',
    phaseNameEn: 'Court Hearings & Judicial Decisions',
    phaseNameAr: 'الجلسات والأحكام القضائية',
    phaseNameBn: 'আদালতের শুনানি ও বিচারিক রায়',
    severity: 5,
    financialExposureOMR: 7642,
    cumulativeClaimOMR: 7642,
    caseRef: 'CTR2601-3344',
    statutoryArticle: 'RD 53/2023 - Complete Chapter 5 & 11 Claims',
    summaryEn: 'Primary adjudication hearing before the Labour Circuit Judge. Plaintiff claims 7,642 OMR backed by Bank Muscat WPS proofs, quashing of absconding notice, and return of retained passport.',
    summaryAr: 'الجلسة الرئيسية أمام قاضي الدائرة العمالية للحكم بكامل مبلغ 7,642 ر.ع واسترداد جواز السفر وشطب بلاغ الهروب الكيدي.',
    summaryBn: 'বিচারকের সামনে চূড়ান্ত শুনানি: ৭,৬৪২ রিয়াল ক্ষতিপূরণ ডিক্রি, পাসপোর্ট ফেরত ও মিথ্যা পলায়ন মামলা স্থায়ীভাবে প্রত্যাহার আদেশ।',
    evidenceRefId: 'COURT-SEEB-NOTICE-2026',
    actionRequired: 'Deliver 3-set color printed evidentiary dossier with QR codes to the presiding judge.'
  },
  {
    id: 'm14',
    dateStr: '2027-09-06',
    timestamp: new Date('2027-09-06').getTime(),
    year: 2027,
    labelEn: 'Resident Card & Work Permit Expiry',
    labelAr: 'انتهاء سريان بطاقة المقيم وتصريح العمل',
    labelBn: 'রেসিডেন্ট কার্ড ও ওয়ার্ক পারমিটের মেয়াদ সমাপ্তি',
    phase: 'legal_future',
    phaseNameEn: 'Future Statutory Deadlines',
    phaseNameAr: 'الآجال القانونية المستقبلية',
    phaseNameBn: 'ভবিষ্যত আইনি সময়সীমা',
    severity: 2,
    financialExposureOMR: 0,
    cumulativeClaimOMR: 7642,
    caseRef: 'CIVIL-ID-VALIDITY-2027',
    statutoryArticle: 'ROP Immigration & Residency Regulations',
    summaryEn: 'Current Resident Card 103352388 remains legally valid until 06/09/2027. Affords complete lawful status to pursue judicial claims in the Sultanate without fear of immediate immigration expiry.',
    summaryAr: 'بطاقة المقيم سارية المفعول حتى 06/09/2027 مما يوفر غطاءً قانونياً كاملاً لمتابعة التقاضي حتى التحصيل النهائي.',
    summaryBn: 'রেসিডেন্ট কার্ডের বৈধতা ২০২৭ সালের সেপ্টেম্বর পর্যন্ত বিদ্যমান। আইনগত বৈধতার কোনো সংকট নেই।',
    evidenceRefId: 'CIVIL-ID-103352388',
    actionRequired: 'Ensure court settlement and sponsorship transfer (NOC) before final visa expiration.'
  }
];

interface CaseTimelineChartProps {
  lang: Language;
  onSelectMilestone?: (milestone: MilestoneEvent) => void;
  onNavigateToSection?: (section: string) => void;
  compactMode?: boolean;
}

export const CaseTimelineChart: React.FC<CaseTimelineChartProps> = ({
  lang,
  onSelectMilestone,
  onNavigateToSection,
  compactMode = false
}) => {
  const [selectedPhase, setSelectedPhase] = useState<string>('all');
  const [activeMilestone, setActiveMilestone] = useState<MilestoneEvent>(CASE_MILESTONES[12]); // default to Seeb Hearing
  const [chartViewMode, setChartViewMode] = useState<'chronology' | 'cumulative_claims'>('chronology');

  const filteredMilestones = CASE_MILESTONES.filter((m) => {
    if (selectedPhase === 'all') return true;
    return m.phase === selectedPhase;
  });

  // Chart data formatting
  const chartData = filteredMilestones.map((m, idx) => ({
    name: m.dateStr,
    displayDate: m.dateStr.slice(5),
    fullDate: m.dateStr,
    year: m.year,
    index: idx + 1,
    severity: m.severity,
    severityLabel: `Level ${m.severity}/5`,
    cumulativeClaim: m.cumulativeClaimOMR,
    financialExposure: m.financialExposureOMR,
    title: lang === 'bn' ? m.labelBn : lang === 'ar' ? m.labelAr : m.labelEn,
    milestone: m,
    fillColor:
      m.severity === 5
        ? '#ef4444' // Red critical
        : m.severity === 4
        ? '#f97316' // Orange high
        : m.severity === 3
        ? '#eab308' // Amber medium
        : '#3b82f6' // Blue routine
  }));

  const handlePointClick = (data: any) => {
    if (data && data.milestone) {
      setActiveMilestone(data.milestone);
      if (onSelectMilestone) onSelectMilestone(data.milestone);
    }
  };

  const getPhaseBadge = (phase: string) => {
    switch (phase) {
      case 'court_action':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'mol_filing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'covid_breach':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'service':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-600 border border-amber-500/20">
              <Calendar className="w-4 h-4" />
            </span>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              {lang === 'bn'
                ? 'মামলার মূল তারিখ ও বিচারিক টাইমলাইন (Recharts Chronology)'
                : lang === 'ar'
                ? 'المخطط الزمني للأحداث القضائية والوقائع الجوهرية (Recharts)'
                : 'Critical Case Milestones & Judicial Timeline (Recharts)'}
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {lang === 'bn'
              ? '২০১৫ সালের চাকরি শুরু থেকে ২০২৬ সালের সিব আদালত এবং ২০২৭ সালের রেসিডেন্ট কার্ডের মেয়াদ পর্যন্ত প্রতিটি গুরুত্বপূর্ণ ঘটনার ইন্টারঅ্যাক্টিভ চিত্র।'
              : lang === 'ar'
              ? 'تتبع زمني دقيق من بدء العمل 2015 وحتى جلسة محكمة السيب 2026 وسريان الإقامة 2027 مع مستويات الخطورة والمطالبات المالية.'
              : 'Interactive chronology mapping 11 years from recruitment in 2015, COVID arbitrary cuts, Ministry filings, through Seeb Court hearing 2026.'}
          </p>
        </div>

        {/* View Mode Toggle & Phase Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-xs font-semibold">
            <button
              onClick={() => setChartViewMode('chronology')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                chartViewMode === 'chronology'
                  ? 'bg-[#0b1f3a] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'গুরুত্ব ইনডেক্স (১-৫)' : lang === 'ar' ? 'مؤشر الجدية (1-5)' : 'Severity Index'}
            </button>
            <button
              onClick={() => setChartViewMode('cumulative_claims')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                chartViewMode === 'cumulative_claims'
                  ? 'bg-[#0b1f3a] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'bn' ? 'দাবিকৃত অর্থ (৭,৬৪২ OMR)' : lang === 'ar' ? 'تراكم المطالبات (7,642 ر.ع)' : 'Claims (7,642 OMR)'}
            </button>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-4 sm:px-5 py-2.5 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto text-xs bg-white scrollbar-thin">
        <span className="text-slate-400 font-medium shrink-0 flex items-center gap-1">
          <Layers className="w-3.5 h-3.5" /> Filter:
        </span>
        {[
          { id: 'all', labelEn: 'All Events (14)', labelAr: 'كافة الوقائع (14)', labelBn: 'সকল ঘটনা (১৪)' },
          { id: 'service', labelEn: 'Service & Barka (2)', labelAr: 'الخدمة وفرع بركاء', labelBn: 'চাকরি ও বারকা' },
          { id: 'covid_breach', labelEn: 'Employer Breaches (3)', labelAr: 'المخالفات والاقتطاعات', labelBn: 'বেতন কর্তন ও লঙ্ঘন' },
          { id: 'mol_filing', labelEn: 'Ministry Actions (4)', labelAr: 'وزارة العمل والتظلمات', labelBn: 'শ্রম মন্ত্রণালয় পদক্ষেপ' },
          { id: 'court_action', labelEn: 'Court Hearings (4)', labelAr: 'جلسات المحاكم', labelBn: 'আদালতের শুনানি' },
          { id: 'legal_future', labelEn: 'Residency (1)', labelAr: 'سريان الإقامة 2027', labelBn: 'ভবিষ্যত মেয়াদ' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedPhase(tab.id)}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap font-medium transition-colors ${
              selectedPhase === tab.id
                ? 'bg-amber-100 text-amber-900 font-bold border border-amber-300'
                : 'text-slate-600 hover:bg-slate-100 border border-transparent'
            }`}
          >
            {lang === 'bn' ? tab.labelBn : lang === 'ar' ? tab.labelAr : tab.labelEn}
          </button>
        ))}
      </div>

      {/* Interactive Recharts Container */}
      <div className="p-4 sm:p-5">
        <div className="h-64 sm:h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartData}
              margin={{ top: 20, right: 20, bottom: 20, left: 10 }}
              onClick={(e: any) => {
                if (e && e.activePayload && e.activePayload[0]) {
                  handlePointClick(e.activePayload[0].payload);
                }
              }}
            >
              <defs>
                <linearGradient id="claimGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0b1f3a" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0b1f3a" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="severityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.02} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />

              <XAxis
                dataKey="name"
                tickLine={false}
                stroke="#64748b"
                fontSize={11}
                tickFormatter={(val: string) => {
                  const parts = val.split('-');
                  return `${parts[1]}/${parts[0]?.slice(2)}`;
                }}
              />

              {chartViewMode === 'chronology' ? (
                <YAxis
                  domain={[0, 5]}
                  ticks={[1, 2, 3, 4, 5]}
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={(val: number) => `Lvl ${val}`}
                  width={42}
                />
              ) : (
                <YAxis
                  domain={[0, 8000]}
                  stroke="#64748b"
                  fontSize={11}
                  tickFormatter={(val: number) => `${val} OMR`}
                  width={68}
                />
              )}

              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    const m: MilestoneEvent = data.milestone;
                    return (
                      <div className="bg-slate-900 text-white p-3 rounded-lg shadow-xl border border-slate-700 max-w-xs text-xs space-y-1.5 z-50">
                        <div className="flex items-center justify-between gap-2 border-b border-slate-700 pb-1">
                          <span className="font-mono text-amber-400 font-bold">{m.dateStr}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              m.severity >= 4 ? 'bg-red-900/80 text-red-200' : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            Severity {m.severity}/5
                          </span>
                        </div>
                        <div className="font-bold text-white text-sm">
                          {lang === 'bn' ? m.labelBn : lang === 'ar' ? m.labelAr : m.labelEn}
                        </div>
                        <div className="text-slate-300 line-clamp-2">
                          {lang === 'bn' ? m.summaryBn : lang === 'ar' ? m.summaryAr : m.summaryEn}
                        </div>
                        <div className="text-[11px] text-amber-300 font-mono">
                          Ref: {m.caseRef} · {m.cumulativeClaimOMR ? `${m.cumulativeClaimOMR} OMR Total` : 'Entitlement Protected'}
                        </div>
                        <div className="text-[10px] text-slate-400 italic">Click node to inspect full details</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />

              {/* Reference line for Seeb Court Formal Hearing */}
              <ReferenceLine
                x="2026-10-15"
                stroke="#dc2626"
                strokeDasharray="4 4"
                label={{
                  value: 'Seeb Court CTR2601-3344',
                  fill: '#dc2626',
                  fontSize: 10,
                  position: 'top'
                }}
              />

              {chartViewMode === 'chronology' ? (
                <>
                  <Area
                    type="monotone"
                    dataKey="severity"
                    stroke="#d97706"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#severityGradient)"
                  />
                  <Bar dataKey="severity" barSize={12} radius={[4, 4, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.milestone.id === activeMilestone.id ? '#1e3a8a' : entry.fillColor}
                      />
                    ))}
                  </Bar>
                </>
              ) : (
                <>
                  <Area
                    type="monotone"
                    dataKey="cumulativeClaim"
                    stroke="#0b1f3a"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#claimGradient)"
                  />
                  <Line
                    type="monotone"
                    dataKey="cumulativeClaim"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={{ r: 4, fill: '#f59e0b', strokeWidth: 1, stroke: '#fff' }}
                    activeDot={{ r: 7, fill: '#ef4444' }}
                  />
                </>
              )}
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Legend & Quick Hint */}
        <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-500 border-t border-slate-100 pt-3 gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" />
              Critical Judicial Hearing (5/5)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500 inline-block" />
              Malicious Absconding / Tampering (4/5)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
              Ministry Complaint (3/5)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" />
              Baseline Operations & ID (1-2/5)
            </span>
          </div>

          <span className="text-[11px] text-amber-700 font-medium">
            💡 {lang === 'bn' ? 'গ্রাফের পয়েন্ট বা নিচের কার্ডে ক্লিক করে বিস্তারিত জানুন' : 'Click any node to inspect court actions'}
          </span>
        </div>
      </div>

      {/* Selected Milestone Active Inspector Box */}
      {activeMilestone && (
        <div className="border-t border-slate-200 bg-slate-50 p-4 sm:p-5">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div className="space-y-2 max-w-3xl">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-slate-900 text-white">
                  📅 {activeMilestone.dateStr}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-xs font-semibold border ${getPhaseBadge(
                    activeMilestone.phase
                  )}`}
                >
                  {lang === 'bn'
                    ? activeMilestone.phaseNameBn
                    : lang === 'ar'
                    ? activeMilestone.phaseNameAr
                    : activeMilestone.phaseNameEn}
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-mono font-semibold bg-amber-100 text-amber-900 border border-amber-200">
                  Ref: {activeMilestone.caseRef}
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-xs font-bold ${
                    activeMilestone.severity >= 4
                      ? 'bg-red-100 text-red-800 border border-red-200'
                      : 'bg-slate-200 text-slate-800'
                  }`}
                >
                  Severity {activeMilestone.severity} / 5
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                {lang === 'bn'
                  ? activeMilestone.labelBn
                  : lang === 'ar'
                  ? activeMilestone.labelAr
                  : activeMilestone.labelEn}
              </h3>

              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                {lang === 'bn'
                  ? activeMilestone.summaryBn
                  : lang === 'ar'
                  ? activeMilestone.summaryAr
                  : activeMilestone.summaryEn}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-xs">
                  <span className="font-semibold text-slate-500 block mb-0.5">
                    ⚖️ Statutory Basis (RD 53/2023):
                  </span>
                  <span className="font-mono text-slate-800 font-medium">
                    {activeMilestone.statutoryArticle}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-xs">
                  <span className="font-semibold text-slate-500 block mb-0.5">
                    🎯 Judicial Action Required:
                  </span>
                  <span className="text-slate-800 font-medium">
                    {activeMilestone.actionRequired}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex md:flex-col items-center gap-2 shrink-0">
              {onNavigateToSection && (
                <button
                  onClick={() => onNavigateToSection('ai-research-lab')}
                  className="w-full px-3.5 py-2 bg-[#0b1f3a] text-white hover:bg-slate-800 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'bn' ? 'এআই দিয়ে বিশ্লেষণ' : lang === 'ar' ? 'بحث ودراسة بالذكاء الاصطناعي' : 'Research with AI'}</span>
                </button>
              )}

              {onNavigateToSection && (
                <button
                  onClick={() => onNavigateToSection('evidence-vault')}
                  className="w-full px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  <span>{lang === 'bn' ? 'প্রমাণ ফাইলে যান' : lang === 'ar' ? 'عرض في مخزن الأدلة' : 'View in Evidence Vault'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Horizontal Scrollable Event Cards Strip (Compact view or expanded list) */}
      {!compactMode && (
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-white">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              {lang === 'bn' ? 'সম্পূর্ণ কালানুক্রমিক ঘটনা তালিকা' : lang === 'ar' ? 'سرد الوقائع بترتيب التواريخ' : 'Chronological Milestone Catalog'}
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              {filteredMilestones.length} milestones
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredMilestones.map((m) => {
              const isSelected = activeMilestone.id === m.id;
              return (
                <div
                  key={m.id}
                  onClick={() => {
                    setActiveMilestone(m);
                    if (onSelectMilestone) onSelectMilestone(m);
                  }}
                  className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[#0b1f3a] bg-blue-50/40 ring-1 ring-[#0b1f3a] shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50/50 hover:bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-xs font-mono font-bold text-slate-700">
                      {m.dateStr}
                    </span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        m.severity === 5
                          ? 'bg-red-100 text-red-800'
                          : m.severity === 4
                          ? 'bg-orange-100 text-orange-800'
                          : m.severity === 3
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      Lvl {m.severity}
                    </span>
                  </div>

                  <div className="font-bold text-xs text-slate-900 line-clamp-1 mb-1">
                    {lang === 'bn' ? m.labelBn : lang === 'ar' ? m.labelAr : m.labelEn}
                  </div>

                  <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                    {lang === 'bn' ? m.summaryBn : lang === 'ar' ? m.summaryAr : m.summaryEn}
                  </p>

                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                    <span className="truncate max-w-[140px]">{m.caseRef}</span>
                    {m.cumulativeClaimOMR > 0 && (
                      <span className="text-amber-700 font-bold">{m.cumulativeClaimOMR} OMR</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
