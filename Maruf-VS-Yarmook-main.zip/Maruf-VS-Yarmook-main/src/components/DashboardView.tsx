import React from 'react';
import { ShieldCheck, AlertTriangle, FileText, Calculator, ArrowRight, Ban, Award, CheckCircle2, Building2, User, Scale, Sparkles, Calendar } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { CASE_METADATA, STATUTORY_CLAIMS, TOTAL_CLAIM_OMR } from '../data/evidenceData';
import { CaseTimelineChart } from './CaseTimelineChart';

interface DashboardViewProps {
  lang: Language;
  onNavigate: (tab: string) => void;
  onSelectEvidenceCategory: (category: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  lang,
  onNavigate,
  onSelectEvidenceCategory
}) => {
  const t = TRANSLATIONS[lang];
  const { plaintiff, defendant, courts, ministry } = CASE_METADATA;

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Case Dossier Summary */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1.5">
              <span>{t.courtJurisdiction}</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-700 font-medium">Supreme Judicial Council</span>
              <span aria-hidden="true">·</span>
              <span>Royal Decree 53/2023</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {plaintiff.fullName} <span className="text-amber-600 font-bold">({plaintiff.alias})</span> vs {defendant.companyName}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl">
              {lang === 'bn' 
                ? 'ওমান শ্রম আইনের অধীনে ১১ বছরের বকেয়া সার্ভিস বেনিফিট, করোনাকালীন অনাদায়ী বেতন এবং অবৈধ কর্তনের বিরুদ্ধে ৭,৬৪২ ওমানি রিয়াল আদায়ের বিচারিক ডিজিটাল ডসিয়ার।'
                : lang === 'ar'
                ? 'ملف قضائي وأدلة رقمية متكاملة للمطالبة بمستحقات نهاية الخدمة والرواتب المتأخرة والخصومات التعسفية بقيمة 7,642 ر.ع بموجب قانون العمل العماني.'
                : 'Comprehensive evidentiary dossier claiming 7,642 OMR for 11 years unbroken service benefits, COVID arrears, and arbitrary wage deductions under Oman Labour Law.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('petition')}
              className="px-4 py-2 bg-[#0b1f3a] text-white hover:bg-slate-800 text-xs font-bold rounded-lg flex items-center gap-2 shadow-xs transition-colors"
            >
              <FileText className="w-4 h-4 text-amber-400" />
              <span>{t.navPetition}</span>
            </button>
            <button
              onClick={() => onNavigate('calculator')}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg flex items-center gap-2 shadow-xs transition-colors"
            >
              <Calculator className="w-4 h-4" />
              <span>{t.navCalculator}</span>
            </button>
          </div>
        </div>

        {/* Litigants & Key Case Numbers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          
          {/* Plaintiff */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <User className="w-3.5 h-3.5 text-blue-600" />
              <span>{t.plaintiffTitle}</span>
            </div>
            <div className="font-bold text-slate-900 text-sm">{plaintiff.fullName}</div>
            <div className="text-xs text-slate-600 mt-1 font-mono">Civil ID: {plaintiff.civilId}</div>
            <div className="text-xs text-slate-500 font-mono">Work Permit: {plaintiff.workPermit}</div>
            <div className="text-[11px] text-amber-700 font-medium mt-1">Tel: {plaintiff.phone}</div>
          </div>

          {/* Defendant */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Building2 className="w-3.5 h-3.5 text-slate-700" />
              <span>{t.defendantTitle}</span>
            </div>
            <div className="font-bold text-slate-900 text-sm">{defendant.companyName}</div>
            <div className="text-xs text-slate-600 mt-1 font-mono">CR No: {defendant.crNumber}</div>
            <div className="text-xs text-slate-500 truncate" title={defendant.branch}>{defendant.branch}</div>
            <div className="text-[11px] text-slate-500">{defendant.businessActivity}</div>
          </div>

          {/* Primary Court References */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span>Seeb Primary Court</span>
            </div>
            <div className="font-bold text-slate-900 text-sm font-mono">{courts.seebCourt.caseNo}</div>
            <div className="text-xs text-slate-600 mt-1">{courts.seebCourt.circuit}</div>
            <div className="text-xs text-slate-500 mt-0.5">Hearing: <span className="font-mono text-slate-800 font-semibold">{courts.seebCourt.hearingDate}</span></div>
            <div className="text-[11px] text-emerald-700 font-semibold mt-1">Barka Ref: {courts.barkaCourt.caseNo}</div>
          </div>

          {/* Ministry & Grievance References */}
          <div className="p-4 rounded-lg bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>MOL & Grievance Ref</span>
            </div>
            <div className="font-bold text-slate-900 text-sm font-mono">{ministry.firstComplaintRef}</div>
            <div className="text-xs text-slate-600 mt-1 font-mono">Reopen: {ministry.secondComplaintRef}</div>
            <div className="text-xs text-red-700 font-mono mt-0.5 font-semibold">Appeal: {ministry.grievanceRef}</div>
            <div className="text-[11px] text-amber-700 font-semibold mt-1">Absconding: {ministry.falseAbsconding2} (False)</div>
          </div>

        </div>
      </div>

      {/* 4 Primary KPI Highlight Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Claim Demanded */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t.totalClaimDemanded}</div>
          <div className="my-2">
            <div className="text-3xl font-extrabold text-[#0b1f3a] font-mono tabular-nums">
              {TOTAL_CLAIM_OMR.toLocaleString('en-US', { minimumFractionDigits: 3 })}
              <span className="text-sm font-sans font-medium text-amber-700 ml-1.5">OMR</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lang === 'bn' ? '৪টি আইনি খাতে পূর্ণ দাবি' : lang === 'ar' ? 'إجمالي المطالبات المستحقة' : 'Full statutory claim across 4 heads'}
            </div>
          </div>
          <button
            onClick={() => onNavigate('calculator')}
            className="text-xs font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1 mt-2 pt-2 border-t border-slate-100"
          >
            <span>{t.navCalculator}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Proven WPS Salary */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t.basicSalaryWps}</div>
          <div className="my-2">
            <div className="text-3xl font-extrabold text-emerald-700 font-mono tabular-nums">
              250.000
              <span className="text-sm font-sans font-medium text-slate-600 ml-1.5">OMR / mo</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Bank Muscat WPS (vs 60 OMR fake claim)
            </div>
          </div>
          <button
            onClick={() => onSelectEvidenceCategory('wps_financial')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 mt-2 pt-2 border-t border-slate-100"
          >
            <span>{lang === 'bn' ? 'WPS প্রমাণপত্র দেখুন' : lang === 'ar' ? 'معاينة كشوف البنك' : 'View WPS Proofs'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Service Tenure */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t.yearsOfTenure}</div>
          <div className="my-2">
            <div className="text-3xl font-extrabold text-blue-900 font-mono tabular-nums">
              11 <span className="text-xl font-bold font-sans text-slate-600">Years</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              July 2015 – Sept 2026 (Unbroken Service)
            </div>
          </div>
          <button
            onClick={() => onSelectEvidenceCategory('gov_id')}
            className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-1 mt-2 pt-2 border-t border-slate-100"
          >
            <span>{lang === 'bn' ? 'সরকারি নথি দেখুন' : lang === 'ar' ? 'معاينة وثائق الإقامة' : 'View Govt Filings'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Branch Peak Sales */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {lang === 'bn' ? 'বারকা শাখার মাসিক সেলস' : lang === 'ar' ? 'مبيعات فرع بركاء المدارة' : 'Barka Branch Managed Sales'}
          </div>
          <div className="my-2">
            <div className="text-3xl font-extrabold text-amber-700 font-mono tabular-nums">
              53,000
              <span className="text-sm font-sans font-medium text-slate-600 ml-1.5">OMR / mo</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              180 Accounts (Proves Branch Manager role)
            </div>
          </div>
          <button
            onClick={() => onSelectEvidenceCategory('role_mismatch')}
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 flex items-center gap-1 mt-2 pt-2 border-t border-slate-100"
          >
            <span>{lang === 'bn' ? 'ম্যানেজার প্রমাণ দেখুন' : lang === 'ar' ? 'معاينة أدلة الإدارة' : 'View Role Proofs'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

      </div>

      {/* Visual Case Dates Chronology Chart (Recharts) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-[#0b1f3a] text-white">
              <Calendar className="w-3.5 h-3.5" />
            </span>
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'bn' ? 'মামলার মূল কালানুক্রম ও বিচারিক টাইমলাইন (Recharts)' : lang === 'ar' ? 'التسلسل الزمني للوقائع والجلسات القضائية (Recharts)' : 'Critical Case Milestones & Dates (Recharts Overview)'}
            </h3>
          </div>
          <button
            onClick={() => onNavigate('case-timeline')}
            className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
          >
            <span>{lang === 'bn' ? 'পূর্ণাঙ্গ টাইমলাইন ও বিবরণী' : lang === 'ar' ? 'عرض المخطط الموسع' : 'Expand Full Timeline'}</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <CaseTimelineChart
          lang={lang}
          compactMode={true}
          onNavigateToSection={onNavigate}
        />
      </div>

      {/* 4 Crucial Legal Protection Banners */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs sm:text-sm flex items-start gap-3">
          <Ban className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-red-950 mb-0.5">{lang === 'bn' ? 'পাসপোর্ট জব্দ রাখা গুরুতর ফৌজদারি অপরাধ' : lang === 'ar' ? 'حظر احتجاز جواز السفر نهائياً' : 'Passport Confiscation is a Serious Offence'}</div>
            <p className="text-red-900/90 leading-relaxed">
              {t.alertPassport}
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs sm:text-sm flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-amber-950 mb-0.5">{lang === 'bn' ? 'WPS ৩ দিনের বাধ্যবাধকতা' : lang === 'ar' ? 'إلزامية نظام حماية الأجور' : 'WPS Strict 3-Day Rule'}</div>
            <p className="text-amber-900/90 leading-relaxed">
              {t.alertWps}
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs sm:text-sm flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-emerald-950 mb-0.5">{lang === 'bn' ? 'ওমানে বৈধ অবস্থানের পূর্ণ অধিকার' : lang === 'ar' ? 'حق البقاء المشروع بعمان' : 'Statutory Right to Lawful Stay'}</div>
            <p className="text-emerald-900/90 leading-relaxed">
              {t.alertStayRight}
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs sm:text-sm flex items-start gap-3">
          <Award className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-blue-950 mb-0.5">{lang === 'bn' ? 'শ্রমিকদের আদালত ফি ১০০% মওকুফ' : lang === 'ar' ? 'إعفاء شامل من الرسوم القضائية' : '100% Exemption from Court Fees'}</div>
            <p className="text-blue-900/90 leading-relaxed">
              {t.alertFeeExemption}
            </p>
          </div>
        </div>
      </div>

      {/* Claims Breakdown Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {lang === 'bn' ? 'আদালতে পেশকৃত আর্থিক দাবির পূর্ণ হিসাব' : lang === 'ar' ? 'جدول تصفية المطالبات المالية العمالية' : 'Itemized Financial Claims Table'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Royal Decree No. 53/2023 Articles 37, 55, 58, 66
            </p>
          </div>
          <button
            onClick={() => onNavigate('calculator')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors self-start sm:self-auto"
          >
            <Calculator className="w-3.5 h-3.5 text-slate-600" />
            <span>{lang === 'bn' ? 'ক্যালকুলেটরে পরিবর্তন করুন' : lang === 'ar' ? 'تعديل بالأرقام' : 'Adjust in Calculator'}</span>
          </button>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-[#0b1f3a] text-white">
                <th className="py-3 px-4 font-semibold">{lang === 'bn' ? 'খাতের বিবরণ' : lang === 'ar' ? 'بند المطالبة' : 'Claim Item'}</th>
                <th className="py-3 px-4 font-semibold">{lang === 'bn' ? 'আইনি ভিত্তি' : lang === 'ar' ? 'السند القانوني' : 'Legal Basis'}</th>
                <th className="py-3 px-4 font-semibold hidden md:table-cell">{lang === 'bn' ? 'হিসাব পদ্ধতি' : lang === 'ar' ? 'الأساس الحسابي' : 'Calculation Formula'}</th>
                <th className="py-3 px-4 font-semibold text-right">{lang === 'bn' ? 'পরিমাণ (OMR)' : lang === 'ar' ? 'المبلغ (ر.ع)' : 'Amount (OMR)'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              {STATUTORY_CLAIMS.map((claim) => (
                <tr key={claim.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-medium text-slate-900">
                    {lang === 'bn' ? claim.nameBn : lang === 'ar' ? claim.nameAr : claim.nameEn}
                  </td>
                  <td className="py-3 px-4 text-xs font-mono text-slate-600">
                    {claim.legalBasis}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-500 hidden md:table-cell">
                    {claim.calculationNote}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                    {claim.amountOMR.toLocaleString('en-US', { minimumFractionDigits: 3 })}
                  </td>
                </tr>
              ))}
              <tr className="bg-amber-400 text-slate-950 font-bold border-t-2 border-amber-500">
                <td colSpan={2} className="py-3.5 px-4 text-sm font-extrabold uppercase">
                  {lang === 'bn' ? 'সর্বমোট আদায়যোগ্য পাওনা' : lang === 'ar' ? 'الإجمالي العام للمطالبات' : 'TOTAL DEMANDED CLAIM'}
                </td>
                <td className="py-3.5 px-4 text-xs text-slate-900 hidden md:table-cell font-mono">
                  Seeb Court Case #CTR2601-3344
                </td>
                <td className="py-3.5 px-4 text-right text-base font-mono font-extrabold tabular-nums">
                  {TOTAL_CLAIM_OMR.toLocaleString('en-US', { minimumFractionDigits: 3 })} OMR
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 3 Pillars of Counter-Evidence */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 mb-1">
          {t.keyPillarsTitle}
        </h2>
        <p className="text-xs text-slate-500 mb-5">
          {lang === 'bn'
            ? 'কোম্পানির আনীত প্রতিটি মিথ্যা দাবির বিপরীতে আমাদের উপস্থাপিত অকাট্য আইনি অবস্থান'
            : lang === 'ar'
            ? 'الركائز الجوهرية لدحض ادعاءات المنشأة وإثبات سوء النية'
            : 'The 3 structural pillars invalidating employer fabrications'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono font-bold text-amber-700 mb-1">PILLAR 01</div>
              <h3 className="font-bold text-slate-900 text-sm mb-2">{t.pillar1Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.pillar1Desc}</p>
            </div>
            <button
              onClick={() => onSelectEvidenceCategory('role_mismatch')}
              className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-slate-800 hover:text-amber-700 flex items-center justify-between"
            >
              <span>{lang === 'bn' ? 'প্রমাণপত্রসমূহ' : lang === 'ar' ? 'عرض الأدلة' : 'Inspect Evidence'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono font-bold text-red-700 mb-1">PILLAR 02</div>
              <h3 className="font-bold text-slate-900 text-sm mb-2">{t.pillar2Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.pillar2Desc}</p>
            </div>
            <button
              onClick={() => onSelectEvidenceCategory('rebuttal_breaches')}
              className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-slate-800 hover:text-red-700 flex items-center justify-between"
            >
              <span>{lang === 'bn' ? 'লঙ্ঘন রিপোর্ট' : lang === 'ar' ? 'عرض المخالفات' : 'Inspect Violations'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="text-xs font-mono font-bold text-blue-700 mb-1">PILLAR 03</div>
              <h3 className="font-bold text-slate-900 text-sm mb-2">{t.pillar3Title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.pillar3Desc}</p>
            </div>
            <button
              onClick={() => onSelectEvidenceCategory('wps_financial')}
              className="mt-4 pt-3 border-t border-slate-200/80 text-xs font-semibold text-slate-800 hover:text-blue-700 flex items-center justify-between"
            >
              <span>{lang === 'bn' ? 'ব্যাংক অডিট প্রমাণ' : lang === 'ar' ? 'كشوفات البنك' : 'Inspect Audit Proofs'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};
