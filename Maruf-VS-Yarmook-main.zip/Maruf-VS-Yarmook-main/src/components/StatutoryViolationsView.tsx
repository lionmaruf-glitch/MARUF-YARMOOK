import React from 'react';
import { AlertOctagon, Ban, Scale, ShieldAlert, Award, FileWarning, ArrowRight, Printer } from 'lucide-react';
import { Language } from '../data/translations';
import { STATUTORY_BREACHES } from '../data/forensicData';

interface StatutoryViolationsViewProps {
  lang: Language;
  onNavigate: (section: string) => void;
  onPrint: () => void;
}

export const StatutoryViolationsView: React.FC<StatutoryViolationsViewProps> = ({
  lang,
  onNavigate,
  onPrint
}) => {
  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span>Oman Labour Law (Royal Decree No. 53/2023) Legal Audit</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {lang === 'bn' ? 'মালিকপক্ষের ৫টি প্রধান আইনি লঙ্ঘন' : lang === 'ar' ? 'المخالفات الخمس الجوهرية لقانون العمل' : '5 Core Statutory Violations by Employer'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
              {lang === 'bn'
                ? 'রয়্যাল ডিক্রি ৫৩/২০২৩ এর সুনির্দিষ্ট ধারার অধীনে আল ইয়ারমুক ট্রেডিং এলএলসি কর্তৃক সংঘটিত দণ্ডনীয় অপরাধ ও আইন লঙ্ঘনের বিবরণ।'
                : lang === 'ar'
                ? 'بيان مفصل للمخالفات الجسيمة المرتكبة من شركة اليرموك الحديثة للتجارة والمجرمة بنصوص قانون العمل العماني.'
                : 'Formal legal analysis of serious statutory infractions committed by Al Yarmook Modern Trading LLC.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onPrint}
              className="px-4 py-2 text-xs font-bold bg-[#0b1f3a] text-white hover:bg-slate-800 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'লঙ্ঘন প্রতিবেদন প্রিন্ট' : lang === 'ar' ? 'طباعة تقرير المخالفات' : 'Print Breach Report'}</span>
            </button>
          </div>
        </div>

        {/* 4 General Judicial Alerts Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-950 text-xs">
            <div className="font-bold mb-1 flex items-center gap-1.5 text-red-700">
              <Ban className="w-4 h-4" />
              <span>পাসপোর্ট জব্দ জরিমানা</span>
            </div>
            <p className="leading-relaxed text-[11px] text-red-900">
              ৫০০–১,০০০ OMR জরিমানা প্রতি শ্রমিকের জন্য (পুনরাবৃত্তিতে দ্বিগুণ ও লাইসেন্স স্থগিত)।
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs">
            <div className="font-bold mb-1 flex items-center gap-1.5 text-amber-700">
              <FileWarning className="w-4 h-4" />
              <span>WPS ৩ দিনের বাধ্যবাধকতা</span>
            </div>
            <p className="leading-relaxed text-[11px] text-amber-900">
              MD 729/2024: বেতন দিতে ৩ দিনের বেশি দেরি করলে ৫০ OMR জরিমানা ও ভিসা ব্লক।
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs">
            <div className="font-bold mb-1 flex items-center gap-1.5 text-emerald-700">
              <Award className="w-4 h-4" />
              <span>বৈধ অবস্থানের পূর্ণ অধিকার</span>
            </div>
            <p className="leading-relaxed text-[11px] text-emerald-900">
              ধারা ১১৪: আদালত ও মন্ত্রণালয়ের চূড়ান্ত নিষ্পত্তি পর্যন্ত ওমানে থাকার পূর্ণ আইনি অধিকার।
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-950 text-xs">
            <div className="font-bold mb-1 flex items-center gap-1.5 text-blue-700">
              <Scale className="w-4 h-4" />
              <span>আদালত ফি ১০০% মওকুফ</span>
            </div>
            <p className="leading-relaxed text-[11px] text-blue-900">
              ধারা ১২০: প্রাথমিক আদালত, আপিল ও সুপ্রিম কোর্ট পর্যন্ত সব ফি সম্পূর্ণ ফ্রি।
            </p>
          </div>
        </div>
      </div>

      {/* 5 Legal Breach Cards */}
      <div className="space-y-4">
        {STATUTORY_BREACHES.map((b, idx) => {
          const isRed = b.color === 'red';
          const isAmber = b.color === 'amber';
          const isPurple = b.color === 'purple';
          const isBlue = b.color === 'blue';

          return (
            <div
              key={b.id}
              className={`bg-white rounded-xl border p-6 shadow-xs transition-all ${
                isRed
                  ? 'border-red-200 hover:border-red-400'
                  : isAmber
                  ? 'border-amber-200 hover:border-amber-400'
                  : isPurple
                  ? 'border-purple-200 hover:border-purple-400'
                  : 'border-blue-200 hover:border-blue-400'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                      isRed
                        ? 'bg-red-100 text-red-800'
                        : isAmber
                        ? 'bg-amber-100 text-amber-900'
                        : isPurple
                        ? 'bg-purple-100 text-purple-900'
                        : 'bg-blue-100 text-blue-900'
                    }`}
                  >
                    VIOLATION 0{idx + 1} · {b.article}
                  </span>
                  <span className="text-xs font-bold text-slate-500">
                    {b.badge}
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-400 font-mono">
                  Royal Decree 53/2023
                </div>
              </div>

              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                {lang === 'bn' ? b.titleBn : lang === 'ar' ? b.titleAr : b.titleEn}
              </h2>

              <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                {lang === 'bn' ? b.descBn : lang === 'ar' ? b.descAr : b.descEn}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono">
                  Evidence cross-ref: Barka & Seeb Labour Circuit Case
                </span>
                <button
                  onClick={() => onNavigate('evidence-vault')}
                  className="font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
                >
                  <span>{lang === 'bn' ? 'প্রমাণ ফাইলে দেখুন' : lang === 'ar' ? 'عرض الدليل' : 'View Exhibit'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
