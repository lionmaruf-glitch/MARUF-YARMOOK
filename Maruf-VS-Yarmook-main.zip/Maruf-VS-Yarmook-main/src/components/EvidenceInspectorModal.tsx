import React from 'react';
import { X, Scale, Calendar, DollarSign, ShieldCheck, Printer, FileText, CheckCircle2 } from 'lucide-react';
import { Language } from '../data/translations';
import { EvidenceItem } from '../types/case';

interface EvidenceInspectorModalProps {
  item: EvidenceItem | null;
  lang: Language;
  onClose: () => void;
}

export const EvidenceInspectorModal: React.FC<EvidenceInspectorModalProps> = ({
  item,
  lang,
  onClose
}) => {
  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 my-8">
        
        {/* Top Header */}
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-700 mb-1">
              <span>{item.keyExhibitNumber || 'COURT EXHIBIT'}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-600">{item.refCode}</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700">{item.documentType}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 leading-snug">
              {lang === 'bn' ? item.titleBn : lang === 'ar' ? item.titleAr : item.titleEn}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 text-lg font-bold rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Core Content Body */}
        <div className="py-5 space-y-5 text-xs sm:text-sm">
          
          {/* Metadata Badges Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div>
              <span className="text-[11px] text-slate-500 font-semibold block">Date / Timestamp</span>
              <span className="font-mono font-bold text-slate-800">{item.date}</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-semibold block">Claim Amount</span>
              <span className="font-mono font-bold text-amber-800">
                {item.amountOMR !== undefined ? `${item.amountOMR.toFixed(3)} OMR` : 'N/A (Evidentiary)'}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-semibold block">Statutory Basis</span>
              <span className="font-mono font-bold text-blue-900">{item.legalArticle}</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-semibold block">Verification Status</span>
              <span className="font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Court Accepted</span>
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="font-bold text-slate-900 mb-1 text-xs uppercase tracking-wider">
              {lang === 'bn' ? 'নথির বিস্তারিত বিবরণ ও বাস্তবতা:' : lang === 'ar' ? 'تفاصيل المستند والواقع المادي:' : 'Document Background & Fact Summary:'}
            </h3>
            <p className="text-slate-700 leading-relaxed bg-slate-50/50 p-3 rounded-lg border border-slate-100">
              {lang === 'bn' ? item.descriptionBn : lang === 'ar' ? item.descriptionAr : item.descriptionEn}
            </p>
          </div>

          {/* Presiding Judge Attention Callout */}
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-950">
            <div className="flex items-center gap-2 font-bold mb-1.5 text-xs sm:text-sm">
              <Scale className="w-4 h-4 text-amber-700" />
              <span>
                {lang === 'bn'
                  ? 'মাননীয় বিচারক ও তদন্তকারী কর্মকর্তার দৃষ্টি আকর্ষণ:'
                  : lang === 'ar'
                  ? 'ملاحظة جوهرية لعدالة المحكمة والمحقق العمالي:'
                  : 'Critical Evidentiary Insight for the Presiding Judge:'}
              </span>
            </div>
            <p className="leading-relaxed text-amber-900">
              {lang === 'bn' ? item.judgeHighlightBn : lang === 'ar' ? item.judgeHighlightAr : item.judgeHighlightEn}
            </p>
          </div>

          {/* Trilingual Title Cross-reference */}
          <div className="pt-2 border-t border-slate-100 text-xs text-slate-500 space-y-1">
            <div><b>AR:</b> {item.titleAr}</div>
            <div><b>EN:</b> {item.titleEn}</div>
            <div><b>BN:</b> {item.titleBn}</div>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-mono">
            Part of Seeb & Barka 79+ Evidence Dossier
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg flex items-center gap-1.5 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'প্রিন্ট' : lang === 'ar' ? 'طباعة' : 'Print'}</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition-colors"
            >
              {lang === 'bn' ? 'বন্ধ করুন' : lang === 'ar' ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
