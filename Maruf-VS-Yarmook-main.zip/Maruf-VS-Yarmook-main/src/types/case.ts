export type EvidenceCategory = 'gov_id' | 'wps_financial' | 'role_mismatch' | 'rebuttal_breaches';

export type EvidenceStatus = 'verified_mol' | 'bank_certified' | 'court_exhibit' | 'accounting_system' | 'under_review';

export interface EvidenceItem {
  id: string;
  refCode: string;
  category: EvidenceCategory;
  date: string;
  amountOMR?: number;
  titleEn: string;
  titleBn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionBn: string;
  descriptionAr: string;
  legalArticle: string;
  status: EvidenceStatus;
  documentType: 'Official Gov Slip' | 'Bank Statement' | 'ERP Ledger' | 'Legal Notice' | 'Medical Certificate' | 'Ticket / Travel' | 'ID / License' | 'Legal Grayscale Document Scan' | 'Legal Filing Scan (PDF/JPG)';
  keyExhibitNumber?: string;
  judgeHighlightBn: string;
  judgeHighlightAr: string;
  judgeHighlightEn: string;
  previewUrl?: string;
}

export interface ClaimItem {
  id: string;
  nameEn: string;
  nameBn: string;
  nameAr: string;
  legalBasis: string;
  amountOMR: number;
  calculationNote: string;
}

export interface CaseMetadata {
  plaintiff: {
    fullName: string;
    alias: string;
    civilId: string;
    workPermit: string;
    nationality: string;
    phone: string;
    email: string;
    residence: string;
    tenure: string;
    actualRole: string;
    visaRole: string;
  };
  defendant: {
    companyName: string;
    companyNameAr: string;
    crNumber: string;
    branch: string;
    businessActivity: string;
  };
  courts: {
    seebCourt: {
      caseNo: string;
      circuit: string;
      circuitAr: string;
      hearingDate: string;
      totalClaimOMR: number;
    };
    barkaCourt: {
      caseNo: string;
      circuit: string;
      circuitAr: string;
      hearingDate: string;
      subject: string;
    };
  };
  ministry: {
    firstComplaintRef: string;
    firstComplaintDate: string;
    firstHearingDate: string;
    secondComplaintRef: string;
    secondComplaintDate: string;
    secondHearingDate: string;
    falseAbsconding1: string;
    falseAbsconding1Status: string;
    falseAbsconding2: string;
    falseAbsconding2Date: string;
    grievanceRef: string;
    grievanceDate: string;
    grievanceStatus: string;
  };
}
