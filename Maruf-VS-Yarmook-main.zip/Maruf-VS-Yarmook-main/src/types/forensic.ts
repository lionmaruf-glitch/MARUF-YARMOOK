export type LedgerType = 'HABIBUR_PERSONAL' | 'OWNER_CORPORATE';

export interface LedgerEntry {
  id: string;
  date: string;
  total_sales: number;
  bank_deposit: number;
  expenses_paid: number;
  deduction: number;
  ledger_type: LedgerType;
  note: string;
  short_amount: number; // computed: total_sales - bank_deposit - expenses_paid
}

export interface ForensicAuditItem {
  id: number;
  itemEn: string;
  itemAr: string;
  itemBn: string;
  classificationEn: string;
  classificationAr: string;
  classificationBn: string;
  amountOMR: number;
}

export interface ContaminationEntry {
  date: string;
  voucher: string;
  narrative: string;
  debit: number | null;
  credit: number | null;
  highlight?: boolean;
}

export interface AIProviderConfig {
  provider: 'gemini' | 'openrouter' | 'groq';
  model: string;
  apiKey: string;
}

export interface AppSettings {
  name: string;
  civilId: string;
  workPermit: string;
  crNumber: string;
  phone: string;
  theme: 'light' | 'dark';
}
