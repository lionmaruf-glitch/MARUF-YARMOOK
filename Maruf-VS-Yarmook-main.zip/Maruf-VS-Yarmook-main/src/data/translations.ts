export type Language = 'bn' | 'en' | 'ar';

export interface TranslationDictionary {
  appName: string;
  appSubtitle: string;
  caseBadge: string;
  navDashboard: string;
  navEvidenceVault: string;
  navCalculator: string;
  navPetition: string;
  navChecklist: string;
  navUploader: string;
  printButton: string;
  printPreviewNotice: string;
  printTargetDisclaimer: string;

  // Dashboard
  courtJurisdiction: string;
  hearingSchedule: string;
  plaintiffTitle: string;
  defendantTitle: string;
  totalClaimDemanded: string;
  yearsOfTenure: string;
  basicSalaryWps: string;
  fakeContractClaimed: string;
  alertPassport: string;
  alertWps: string;
  alertStayRight: string;
  alertFeeExemption: string;
  keyPillarsTitle: string;
  pillar1Title: string;
  pillar1Desc: string;
  pillar2Title: string;
  pillar2Desc: string;
  pillar3Title: string;
  pillar3Desc: string;

  // Evidence Vault
  searchPlaceholder: string;
  filterAll: string;
  filterCat1: string;
  filterCat2: string;
  filterCat3: string;
  filterCat4: string;
  filterStatusAll: string;
  recordsFound: string;
  clearFilters: string;
  viewDetails: string;
  exhibitNumber: string;
  refCodeLabel: string;
  legalBasisLabel: string;
  dateLabel: string;
  amountLabel: string;
  documentTypeLabel: string;
  judgeAttention: string;

  // Calculator
  calculatorTitle: string;
  calculatorSubtitle: string;
  calcEosbTitle: string;
  calcCovidTitle: string;
  calcDeductionsTitle: string;
  calcLeaveTitle: string;
  tenureYearsInput: string;
  basicSalaryInput: string;
  monthlyDeductionInput: string;
  covidMonthsInput: string;
  ooredooInput: string;
  calculateReset: string;
  totalCalculatedOutput: string;
  royalDecreeCitation: string;

  // Petition
  petitionHeaderSjc: string;
  petitionHeaderMol: string;
  petitionHeaderCourt: string;
  petitionHeaderCaseRef: string;
  petitionSubject: string;
  petitionPartiesTitle: string;
  petitionFactsTitle: string;
  petitionLegalTitle: string;
  petitionClaimsTitle: string;
  petitionPrayersTitle: string;
  petitionSignatureTitle: string;
  petitionPrintAction: string;
  petitionLanguageNote: string;

  // Checklist
  checklistTitle: string;
  checklistSubtitle: string;
  setsInstruction: string;
  resetChecklist: string;
  completedItems: string;

  // Uploader
  uploaderTitle: string;
  uploaderSubtitle: string;
  dropzoneTitle: string;
  dropzoneSubtitle: string;
  uploadedFilesCount: string;
}

export const TRANSLATIONS: Record<Language, TranslationDictionary> = {
  bn: {
    appName: 'Maruf AI Case Study Lab',
    appSubtitle: 'ওমান শ্রম আদালত (রয়্যাল ডিক্রি ৫৩/২০২৩) ডিজিটাল প্রমাণ ও আইনি পোর্টাল',
    caseBadge: 'মামলা #CTR2601-3344 / #1005/1215/2026',
    navDashboard: 'ড্যাশবোর্ড',
    navEvidenceVault: 'ডিজিটাল প্রমাণ ভল্ট',
    navCalculator: 'স্বয়ংক্রিয় ক্ষতিপূরণ ক্যালকুলেটর',
    navPetition: 'আদালতের পিটিশন (A4)',
    navChecklist: '১২-দফা মাস্টার চেকলিস্ট',
    navUploader: 'ফাইল আপলোড ও স্ক্যানার',
    printButton: '🖨️ A4 কোর্ট পেটিশন প্রিন্ট (AR + EN)',
    printPreviewNotice: 'প্রিন্ট মোডে শুধুমাত্র অফিসিয়াল আরবি ও ইংরেজি A4 পেজ আসবে — আদালতের জন্য প্রস্তুত।',
    printTargetDisclaimer: 'বাংলা ইন্টারফেস আপনার স্ক্রিনে পড়ার জন্য সংরক্ষিত, প্রিন্ট কপিতে কোনো অনানুষ্ঠানিক ভাষা আসবে না।',

    courtJurisdiction: 'আদালতের এখতিয়ার ও সার্কিট',
    hearingSchedule: 'ধার্য শুনানির তারিখ',
    plaintiffTitle: 'বাদী (শ্রমিক)',
    defendantTitle: 'বিবাদী (নিয়োগকর্তা)',
    totalClaimDemanded: 'মোট আর্থিক দাবি (OMR)',
    yearsOfTenure: 'নিরবচ্ছিন্ন চাকরির মেয়াদ',
    basicSalaryWps: 'ব্যাংক মাস্কাট WPS প্রকৃত মূল বেতন',
    fakeContractClaimed: 'মালিকপক্ষের দাবি করা ভুয়া চুক্তি',
    alertPassport: '🚨 পাসপোর্ট আটকে রাখা দণ্ডনীয় অপরাধ (RD 53/2023 ধারা 6 ও 147 — জরিমানা ৫০০–১,০০০ রিয়াল প্রতি কর্মী)।',
    alertWps: '⚠️ ৩ দিনের মধ্যে WPS-এ বেতন পরিশোধ বাধ্যতামূলক (MD 729/2024 — বরখেলাপে কোম্পানি লাইসেন্স স্থগিত)।',
    alertStayRight: '✅ মামলা নিষ্পত্তি না হওয়া পর্যন্ত ওমানে বৈধ অবস্থানের আইনগত অধিকার (ধারা 114)।',
    alertFeeExemption: 'ℹ️ শ্রমিকদের জন্য আদালত ও আপিল ফি ১০০% সম্পূর্ণ মওকুফ (ধারা 120)।',
    keyPillarsTitle: 'মালিকপক্ষের ৩টি বেআইনি অপকৌশল ও আমাদের প্রতিরোধ',
    pillar1Title: '১. ভিসা মিসক্লাসিফিকেশন',
    pillar1Desc: '৮ বছর ধরে ব্রাঞ্চ ম্যানেজার ও মাসে ৫৩,০০০ রিয়াল সেলস পরিচালনা করলেও কাগজে ওয়েটার/লোডার বানিয়ে রাখা হয়।',
    pillar2Title: '২. পাসপোর্ট জব্দ রাখা',
    pillar2Desc: 'শ্রমিক যেন স্বাধীনভাবে অন্য প্রতিষ্ঠানে যেতে না পারেন বা অধিকার না চাইতে পারেন সেজন্য ১১ বছর মূল পাসপোর্ট আটকে রাখা।',
    pillar3Title: '৩. জবরদস্তিমূলক চুক্তি ও ভুয়া কর্তন',
    pillar3Desc: 'কাগজের ৬০ রিয়ালের ভিত্তিহীন চুক্তি এবং ছুটি থেকে ফেরার পর ২,২০০ রিয়ালের ভুয়া সফটওয়্যার ঘাটতি চাপিয়ে দেওয়া।',

    searchPlaceholder: 'রেফারেন্স নম্বর, তারিখ, পরিমাণ (OMR), বা কি-ওয়ার্ড দিয়ে তাৎক্ষণিক খুঁজুন...',
    filterAll: 'সকল প্রমাণ (৭৯+)',
    filterCat1: '১. পরিচিতি ও সরকারি নথি',
    filterCat2: '২. WPS ব্যাংক ও আর্থিক প্রমাণ',
    filterCat3: '৩. পদবি ও ভিসা মিসম্যাচ',
    filterCat4: '৪. দাবি খণ্ডন ও মালিকপক্ষের লঙ্ঘন',
    filterStatusAll: 'সব স্ট্যাটাস',
    recordsFound: 'টি রেকর্ড পাওয়া গেছে',
    clearFilters: 'ফিল্টার মুছুন',
    viewDetails: 'পূর্ণ নথি ও আদালতের পয়েন্ট দেখুন',
    exhibitNumber: 'আদালতের প্রদর্শনী নং',
    refCodeLabel: 'রেফারেন্স কোড',
    legalBasisLabel: 'আইনি ধারা',
    dateLabel: 'তারিখ',
    amountLabel: 'অর্থের পরিমাণ',
    documentTypeLabel: 'দলিলের ধরন',
    judgeAttention: 'আদালত ও বিচারকের দৃষ্টি আকর্ষণীয় মূল বিষয়:',

    calculatorTitle: 'রয়্যাল ডিক্রি ৫৩/২০২৩ ভিত্তিক স্বয়ংক্রিয় বকেয়া ও ক্ষতিপূরণ ক্যালকুলেটর',
    calculatorSubtitle: 'ওমান শ্রম আইনের সুনির্দিষ্ট ধারা অনুযায়ী আপনার প্রাপ্য সার্ভিস বেনিফিট ও বেআইনি কর্তন পুনর্গণনা করুন',
    calcEosbTitle: 'চাকরির সমাপ্তি সুবিধা (EOSB — ধারা ৩৭)',
    calcCovidTitle: 'কোভিডকালীন জোরপূর্বক স্থগিত ১২ মাসের বেতন',
    calcDeductionsTitle: 'অবৈধ কর্তনের পূর্ণ ফেরত (ধারা ৫৫, ৫৮, ৫৯)',
    calcLeaveTitle: '১১ বছরের সঞ্চিত বাৎসরিক ছুটি (ধারা ৬৬)',
    tenureYearsInput: 'চাকরির সময়কাল (বছর)',
    basicSalaryInput: 'প্রকৃত মূল বেতন (OMR)',
    monthlyDeductionInput: 'অবৈধ মাসিক কর্তন (OMR)',
    covidMonthsInput: 'বকেয়া বেতন মাস সংখ্যা',
    ooredooInput: 'অরিডু বা অন্যান্য জরিমানা (OMR)',
    calculateReset: 'ডিফল্ট সূত্রে ফিরিয়ে আনুন',
    totalCalculatedOutput: 'সর্বমোট আইনসম্মত দাবি',
    royalDecreeCitation: 'সকল হিসাব রয়্যাল ডিক্রি ৫৩/২০২৩ এবং ব্যাংক মাস্কাট WPS রেকর্ডের ভিত্তিতে তৈরি।',

    petitionHeaderSjc: 'ওমান সুলতানাত — সুপ্রিম জুডিশিয়াল কাউন্সিল',
    petitionHeaderMol: 'শ্রম মন্ত্রণালয় — বারকা ও সিব শ্রম বিরোধ নিষ্পত্তি শাখা',
    petitionHeaderCourt: 'সিব ও বারকা প্রাথমিক আদালত — শ্রম সার্কিট',
    petitionHeaderCaseRef: 'মামলা নং: CTR2601-3344 / 1005/1215/2026 | শিকায়ত: REF2603150080',
    petitionSubject: 'বিষয়: শ্রম অধিকার ও বকেয়া পাওনা আদায়ের আনুষ্ঠানিক মামলার আরজি',
    petitionPartiesTitle: 'প্রথম: মামলার পক্ষগণের পরিচিতি',
    petitionFactsTitle: 'দ্বিতীয়: মামলার ঘটনা ও মালিকপক্ষের অন্যায়সমূহ',
    petitionLegalTitle: 'তৃতীয়: আইনি ভিত্তি (রয়্যাল ডিক্রি নং ৫৩/২০২৩)',
    petitionClaimsTitle: 'চতুর্থ: আইটেমাইজড আর্থিক দাবির পূর্ণ সারণি',
    petitionPrayersTitle: 'পঞ্চম: মাননীয় আদালতের সমীপে চূড়ান্ত প্রার্থনা',
    petitionSignatureTitle: 'বাদী শ্রমিকের স্বাক্ষর ও তারিখ',
    petitionPrintAction: '🖨️ এখনই আদালতের জন্য A4 প্রিন্ট করুন (English + العربية)',
    petitionLanguageNote: 'আদালতের নিয়মানুযায়ী প্রিন্টে শুধুমাত্র আরবি এবং ইংরেজি পেজ আসবে।',

    checklistTitle: 'আদালতে পেশ করার জন্য ১২-দফা মাস্টার এভিডেন্স চেকলিস্ট',
    checklistSubtitle: 'শুনানির দিনে বিচারক, ক্লার্ক এবং আপনার নিজের জন্য ৩টি পূর্ণাঙ্গ সেট প্রস্তুত রাখুন',
    setsInstruction: 'সুপ্রিম জুডিশিয়াল কাউন্সিল নির্দেশিকা: প্রতিটি সেট স্বচ্ছ ফাইলে আলাদা করে রাখুন।',
    resetChecklist: 'চেকলিস্ট রিসেট করুন',
    completedItems: 'টি সম্পন্ন হয়েছে',

    uploaderTitle: 'ডিজিটাল এভিডেন্স আপলোডার ও লোকাল স্ক্যানার',
    uploaderSubtitle: 'আপনার নতুন ব্যাংক স্লিপ, আদালতের নোটিশ বা স্ক্রিনশট এখানে ড্র্যাগ করে যুক্ত করুন',
    dropzoneTitle: 'ফাইল ড্রপ করুন অথবা নির্বাচন করতে ক্লিক করুন',
    dropzoneSubtitle: 'PDF, JPG, PNG ফাইল সমর্থিত (সর্বোচ্চ ২৫ MB)',
    uploadedFilesCount: 'টি স্থানীয় নথি সংরক্ষিত আছে'
  },
  en: {
    appName: 'Maruf AI Case Study Lab',
    appSubtitle: 'Oman Labour Law (Royal Decree 53/2023) Digital Evidence & Judicial Portal',
    caseBadge: 'Case #CTR2601-3344 / #1005/1215/2026',
    navDashboard: 'Dashboard',
    navEvidenceVault: 'Evidence Vault',
    navCalculator: 'Legal Calculator',
    navPetition: 'Court Petition (A4)',
    navChecklist: 'Master Checklist',
    navUploader: 'File Uploader',
    printButton: '🖨️ Print A4 Court Dossier (AR + EN)',
    printPreviewNotice: 'In print mode, strictly official Arabic & English A4 pages are outputted for the court.',
    printTargetDisclaimer: 'Bangla view is preserved for on-screen guidance and will be suppressed in official print.',

    courtJurisdiction: 'Court Jurisdiction & Circuit',
    hearingSchedule: 'Hearing Date',
    plaintiffTitle: 'Claimant (Employee)',
    defendantTitle: 'Defendant (Employer)',
    totalClaimDemanded: 'Total Financial Claim (OMR)',
    yearsOfTenure: 'Unbroken Service Tenure',
    basicSalaryWps: 'Bank Muscat WPS Actual Basic Salary',
    fakeContractClaimed: 'Employer Claimed Coerced Contract',
    alertPassport: '🚨 Passport confiscation is strictly prohibited (RD 53/2023 Arts. 6 & 147 — Fines: 500–1,000 OMR per worker).',
    alertWps: '⚠️ Wages must be paid via WPS within 3 days (MD 729/2024 — Violations freeze commercial licenses).',
    alertStayRight: '✅ Statutory right to remain lawfully in Oman until final court judgment (Article 114).',
    alertFeeExemption: 'ℹ️ 100% exemption from all court fees across primary, appeal, and Supreme Court (Article 120).',
    keyPillarsTitle: 'Employer Tactics vs Documented Counter-Evidence',
    pillar1Title: '1. Visa Misclassification',
    pillar1Desc: 'Maintained 11-year Branch Sales Manager on "Waiter/Loader" visa to evade Omanization wages.',
    pillar2Title: '2. Passport Confiscation',
    pillar2Desc: 'Illegally confiscated original passport for 11 years to eliminate mobility and suppress statutory rights.',
    pillar3Title: '3. Coerced Contracts & Fabricated Debts',
    pillar3Desc: 'Fabricated 2,200 OMR cash shortage via software password tampering upon return from approved leave.',

    searchPlaceholder: 'Search by reference code, date, amount (OMR), or keyword...',
    filterAll: 'All Evidence (79+)',
    filterCat1: '1. Identity & Government',
    filterCat2: '2. WPS Bank & Financial Proofs',
    filterCat3: '3. Role vs Visa Mismatch',
    filterCat4: '4. Rebuttal & Employer Breaches',
    filterStatusAll: 'All Statuses',
    recordsFound: 'records found',
    clearFilters: 'Clear Filters',
    viewDetails: 'Inspect Document & Court Notes',
    exhibitNumber: 'Court Exhibit No.',
    refCodeLabel: 'Ref Code',
    legalBasisLabel: 'Legal Article',
    dateLabel: 'Date',
    amountLabel: 'Amount',
    documentTypeLabel: 'Document Type',
    judgeAttention: 'Key Legal Insight for the Presiding Judge:',

    calculatorTitle: 'Automated Legal Claims Calculator (Royal Decree 53/2023)',
    calculatorSubtitle: 'Real-time calculation of End of Service Benefits (EOSB), illegal deductions, and statutory entitlements',
    calcEosbTitle: 'End of Service Benefits (Article 37)',
    calcCovidTitle: 'Unpaid Wages during COVID-19 Lockdown',
    calcDeductionsTitle: 'Refund of Illegal Deductions (Articles 55, 58, 59)',
    calcLeaveTitle: 'Accrued Annual Leave Pay (Article 66)',
    tenureYearsInput: 'Tenure (Years)',
    basicSalaryInput: 'Actual Basic Salary (OMR)',
    monthlyDeductionInput: 'Monthly Wage Deductions (OMR)',
    covidMonthsInput: 'Unpaid COVID Lockdown Months',
    ooredooInput: 'Ooredoo / Commercial Penalties (OMR)',
    calculateReset: 'Reset to Case Baseline',
    totalCalculatedOutput: 'Total Statutory Demand',
    royalDecreeCitation: 'Calculated pursuant to Royal Decree No. 53/2023 and authenticated Bank Muscat WPS wage history.',

    petitionHeaderSjc: 'SULTANATE OF OMAN — SUPREME JUDICIAL COUNCIL',
    petitionHeaderMol: 'Ministry of Labour — Barka & Seeb Dispute Settlement Directorates',
    petitionHeaderCourt: 'SEEB & BARKA PRIMARY COURTS — LABOUR CIRCUITS',
    petitionHeaderCaseRef: 'Case No: CTR2601-3344 / 1005/1215/2026 | MOL Complaint: REF2603150080',
    petitionSubject: 'Subject: Formal Statement of Labour Claims & Recovery of Entitlements',
    petitionPartiesTitle: '1. Identification of the Parties',
    petitionFactsTitle: '2. Statement of Facts & Employer Violations',
    petitionLegalTitle: '3. Legal Grounds (Royal Decree No. 53/2023)',
    petitionClaimsTitle: '4. Itemised Financial Claims Breakdown',
    petitionPrayersTitle: '5. Formal Prayers for Judicial Relief',
    petitionSignatureTitle: 'Claimant Signature & Date',
    petitionPrintAction: '🖨️ Print Court A4 Dossier Now (English + Arabic)',
    petitionLanguageNote: 'According to court standards, print output formats exclusively in Arabic and English.',

    checklistTitle: '12-Point Master Judicial Evidence Checklist',
    checklistSubtitle: 'Ensure 3 complete printed physical dossiers are prepared for Judge, Clerk, and Case File',
    setsInstruction: 'Supreme Judicial Council protocol: Keep each physical dossier bound in a clear folder with QR index.',
    resetChecklist: 'Reset Checklist',
    completedItems: 'items verified',

    uploaderTitle: 'Digital Evidence Uploader & Local Scanner',
    uploaderSubtitle: 'Securely upload new deposit slips, summons, or software audit screenshots',
    dropzoneTitle: 'Drag & Drop files here, or click to browse',
    dropzoneSubtitle: 'PDF, JPG, PNG accepted (Max 25 MB)',
    uploadedFilesCount: 'local documents stored in secure vault'
  },
  ar: {
    appName: 'مختبر معروف الذكي للقضايا العمالية',
    appSubtitle: 'إدارة الأدلة الرقمية وحساب المستحقات العمالية (المرسوم السلطاني 53/2023)',
    caseBadge: 'الدعوى #CTR2601-3344 / #1005/1215/2026',
    navDashboard: 'لوحة التحكم',
    navEvidenceVault: 'خزانة الأدلة الرقمية',
    navCalculator: 'حاسبة المستحقات القانونية',
    navPetition: 'المذكرة القضائية (A4)',
    navChecklist: 'قائمة التحقق المعتمدة',
    navUploader: 'مستودع المستندات',
    printButton: '🖨️ طباعة المذكرة القضائية A4 (عربي + إنجليزي)',
    printPreviewNotice: 'تقتصر الطباعة القضائية تلقائياً على الصفحات الرسمية بالعربية والإنجليزية فقط.',
    printTargetDisclaimer: 'الواجهة البنغالية مخصصة للعرض التوضيحي على الشاشة ولا تظهر في طباعة المحكمة.',

    courtJurisdiction: 'الاختصاص القضائي والدائرة',
    hearingSchedule: 'موعد الجلسة المحددة',
    plaintiffTitle: 'المدّعي (العامل)',
    defendantTitle: 'المدّعى عليها (صاحب العمل)',
    totalClaimDemanded: 'إجمالي المطالبات المالية (ر.ع)',
    yearsOfTenure: 'مدة الخدمة المتصلة',
    basicSalaryWps: 'الأجر الأساسي الفعلي (WPS بنك مسقط)',
    fakeContractClaimed: 'العقد الصوري المزعوم من الشركة',
    alertPassport: '🚨 حظر احتجاز جواز السفر: جريمة معاقب عليها بنص المادة (6) و (147) بغرامة 500–1000 ر.ع.',
    alertWps: '⚠️ إلزامية صرف الأجور عبر WPS خلال 3 أيام (القرار الوزاري 729/2024).',
    alertStayRight: '✅ حق العامل في البقاء القانوني داخل سلطنة عمان حتى الفصل النهائي في الدعوى (المادة 114).',
    alertFeeExemption: 'ℹ️ إعفاء كامل وشامل من كافة الرسوم القضائية لجميع درجات التقاضي (المادة 120).',
    keyPillarsTitle: 'مخططات صاحب العمل وتفنيدها بالأدلة القاطعة',
    pillar1Title: '1. التلاعب بالمهن والتعمين',
    pillar1Desc: 'تشغيل العامل مديراً لفرع بركاء ومبيعات 53,000 ر.ع مع تسجيله صورياً كعامل نادل/شحن.',
    pillar2Title: '2. احتجاز جواز السفر',
    pillar2Desc: 'مصادرة وثيقة السفر لمدة 11 عاماً لحرمان العامل من حرية التنقل وملاحقة حقوقه.',
    pillar3Title: '3. اصطناع العجز والخصم غير القانوني',
    pillar3Desc: 'تغيير كلمة سر النظام المحاسبي أثناء إجازة العامل واصطناع عجز 2,200 ر.ع كيدياً.',

    searchPlaceholder: 'البحث برقم المرجع، التاريخ، المبلغ (ر.ع) أو الكلمات المفتاحية...',
    filterAll: 'كافة الأدلة (79+)',
    filterCat1: '1. الهوية والمستندات الحكومية',
    filterCat2: '2. كشوفات WPS والإثباتات المالية',
    filterCat3: '3. إثبات المهنة والمسمى الإداري',
    filterCat4: '4. تفنيد الادعاءات ومخالفات الكفيل',
    filterStatusAll: 'جميع الحالات',
    recordsFound: 'مستندات مطابقة',
    clearFilters: 'مسح التصفية',
    viewDetails: 'عرض تفاصيل المستند وملاحظات القاضي',
    exhibitNumber: 'مستند المحكمة رقم',
    refCodeLabel: 'رمز المرجع',
    legalBasisLabel: 'السند القانوني',
    dateLabel: 'التاريخ',
    amountLabel: 'المبلغ',
    documentTypeLabel: 'نوع المستند',
    judgeAttention: 'نقطة جوهرية لعدالة المحكمة الموقرة:',

    calculatorTitle: 'حاسبة المستحقات والتعويضات العمالية (المرسوم السلطاني 53/2023)',
    calculatorSubtitle: 'احتساب دقيق لمكافأة نهاية الخدمة (EOSB) والخصومات التعسفية وبدل الإجازات',
    calcEosbTitle: 'مكافأة نهاية الخدمة (المادة 37)',
    calcCovidTitle: 'متأخرات أجور فترة إغلاق كورونا (12 شهراً)',
    calcDeductionsTitle: 'استرداد الخصومات غير القانونية (المواد 55، 58، 59)',
    calcLeaveTitle: 'بدل الإجازات السنوية المتراكمة (المادة 66)',
    tenureYearsInput: 'سنوات الخدمة',
    basicSalaryInput: 'الأجر الأساسي الفعلي (ر.ع)',
    monthlyDeductionInput: 'الاستقطاع الشهري غير القانوني (ر.ع)',
    covidMonthsInput: 'أشهر كورونا غير المدفوعة',
    ooredooInput: 'فواتير أوريدو والغرامات (ر.ع)',
    calculateReset: 'استعادة الأرقام الرسمية',
    totalCalculatedOutput: 'إجمالي المستحقات العمالية الواجبة',
    royalDecreeCitation: 'جميع الحسابات تستند لأحكام قانون العمل العماني وكشوف بنك مسقط المعتمدة.',

    petitionHeaderSjc: 'سلطنة عُمان — المجلس الأعلى للقضاء',
    petitionHeaderMol: 'وزارة العمل — دائرة تسوية المنازعات العمالية',
    petitionHeaderCourt: 'المحكمة الابتدائية بالسيب وبركاء — الدوائر العمالية',
    petitionHeaderCaseRef: 'الدعوى رقم: CRT2601-3344 / 1005/1215/2026 | الشكوى: REF2603150080',
    petitionSubject: 'الموضوع: مذكرة دعوى عمالية وبسط وقائع ومطالبة بحقوق ومستحقات عمالية',
    petitionPartiesTitle: 'أولاً: بيانات أطراف الدعوى',
    petitionFactsTitle: 'ثانياً: وقائع الدعوى والتعسف الإداري',
    petitionLegalTitle: 'ثالثاً: الأسانيد القانونية (المرسوم السلطاني 53/2023)',
    petitionClaimsTitle: 'رابعاً: جدول المطالبات المالية التفصيلية',
    petitionPrayersTitle: 'خامساً: الطلبات الختامية المرفوعة لعدالة المحكمة',
    petitionSignatureTitle: 'توقيع وتاريخ مقدم الطلب',
    petitionPrintAction: '🖨️ طباعة المذكرة القضائية الآن (عربي + إنجليزي)',
    petitionLanguageNote: 'بحسب المعايير القضائية، تشمل النسخة المطبوعة اللغتين العربية والإنجليزية فقط.',

    checklistTitle: 'قائمة المستندات والوثائق المعتمدة لجلسة المحكمة',
    checklistSubtitle: 'تجهيز 3 نسخ متكاملة لكل من فضيلة القاضي، أمين السر، وملف العامل',
    setsInstruction: 'تعليمات المجلس الأعلى للقضاء: حفظ كل ملف في حافظة بلاستيكية مستقلة مع رمز QR.',
    resetChecklist: 'إعادة ضبط القائمة',
    completedItems: 'بنود تم التحقق منها',

    uploaderTitle: 'مستودع المستندات والأدلة الإضافية',
    uploaderSubtitle: 'إرفاق إيصالات الإيداع البنكية، الاستدعاءات القضائية، ولقطات شاشات البرامج',
    dropzoneTitle: 'اسحب وأفلت الملفات هنا، أو انقر للاختيار',
    dropzoneSubtitle: 'صيغ PDF, JPG, PNG مدعومة (حتى 25 ميجابايت)',
    uploadedFilesCount: 'ملفات محلية محفوظة بأمان'
  }
};
