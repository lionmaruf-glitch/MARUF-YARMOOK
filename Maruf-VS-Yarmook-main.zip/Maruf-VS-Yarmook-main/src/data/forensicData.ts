import { ContaminationEntry, ForensicAuditItem, LedgerEntry } from '../types/forensic';

export const FORENSIC_AUDIT_ITEMS: ForensicAuditItem[] = [
  {
    id: 1,
    itemEn: 'Unlawful monthly deductions',
    itemAr: 'اقتطاعات شهرية غير قانونية من الراتب',
    itemBn: 'মাসিক বেআইনি বেতন কর্তন',
    classificationEn: '50 OMR × 12 months without written consent',
    classificationAr: '50 ر.ع × 12 شهراً دون موافقة كتابية أو تحقيق',
    classificationBn: 'লিখিত সম্মতি ছাড়া ৫০ রিয়াল × ১২ মাস',
    amountOMR: 600.000
  },
  {
    id: 2,
    itemEn: 'COVID-19 pandemic penalty',
    itemAr: 'غرامة جائحة كوفيد-19 والعودة القسرية',
    itemBn: 'করোনাকালীন জরিমানা ও কোয়ারেন্টাইন খরচ চাপানো',
    classificationEn: 'Employee self-funded quarantine + return tickets, yet salary slashed',
    classificationAr: 'تحمل العامل مصاريف الحجر والتذاكر وقامت الشركة بخصمها تعسفياً',
    classificationBn: 'শ্রমিক নিজে টিকিট ও খরচ বহন করলেও বেতন থেকে কেটে নেওয়া হয়',
    amountOMR: 600.000
  },
  {
    id: 3,
    itemEn: 'Forced liability for customer default',
    itemAr: 'تحميل العامل ديون زبائن متعثرين',
    itemBn: 'কাস্টমার দেনা জোরপূর্বক শ্রমিকের ওপর চাপানো',
    classificationEn: 'Customer bad debt caused by company delivery delay',
    classificationAr: 'ديون تجارية بسبب تأخر توريد الشركة حُملت على العامل',
    classificationBn: 'কোম্পানির ডেলিভারি দেরির কারণে গ্রাহক বকেয়া মারুফের ওপর চাপানো',
    amountOMR: 100.000
  },
  {
    id: 4,
    itemEn: 'Medical leave salary deduction',
    itemAr: 'خصم أجر أيام إجازة مرضية معتمدة',
    itemBn: 'মেডিকেল ছুটির দিনগুলোর বেতন কেটে নেওয়া',
    classificationEn: '3 days × 8.333 OMR deducted despite doctor cert. dated 27/01/2026',
    classificationAr: 'خصم 3 أيام (8.333 ر.ع/يوم) رغم وجود إجازة طبية رسمية 27/01/2026م',
    classificationBn: '২৭/০১/২০২৬ তারিখের ডাক্তার সনদ থাকা সত্ত্বেও ৩ দিনের বেতন কর্তন',
    amountOMR: 25.000
  },
  {
    id: 5,
    itemEn: 'Third-party sub-ledger contamination',
    itemAr: 'تلوث السجل الفرعي بديون عمال آخرين',
    itemBn: 'অন্যান্য শ্রমিকের ঋণ সাব-লেজারে ঢুকিয়ে জালিয়াতি',
    classificationEn: 'SHAJAHAN 300 OMR + HAFEZ 100 OMR mixed into MARUF LOAN A/C',
    classificationAr: 'إقحام سلفيات شاه جهان (300 ر.ع) وحافظ (100 ر.ع) بحساب معروف',
    classificationBn: 'শাহজাহানের ৩০০ রিয়াল ও হাফেজের ১০০ রিয়াল মারুফের লোনে ঢুকিয়ে দেওয়া',
    amountOMR: 400.000
  },
  {
    id: 6,
    itemEn: 'Third-party telecom fine transfer',
    itemAr: 'تحميل غرامات هاتف أوريدو التجاري للورشة',
    itemBn: 'কোম্পানির অরিডু ইন্টারনেট বিল ও জরিমানার দায় চাপানো',
    classificationEn: 'Commercial Ooredoo line defaulted after 7 months by employer',
    classificationAr: 'خط تجاري باسم العامل لخدمة الورشة تعنتت الإدارة عن سداده',
    classificationBn: 'কোম্পানি ওয়ার্কশপের ব্রডব্যান্ড লাইনের বকেয়া বিল মারুফের বেতনে কাটে',
    amountOMR: 220.000
  },
  {
    id: 7,
    itemEn: 'Arbitrary worker tax deduction',
    itemAr: 'خصم ما يسمى "ضريبة عمالية" وهمية',
    itemBn: 'ভুয়া শ্রমিক কর বাবদ টাকা কাটা',
    classificationEn: 'Unilateral arbitrary label invented by payroll clerk',
    classificationAr: 'بند استقطاع وهمي منسوب للمحاسبة دون أي سند قانوني',
    classificationBn: 'কোনো সরকারি ভিত্তি ছাড়া খাতার মধ্যে বসানো মনগড়া কর্তন',
    amountOMR: 2.700
  }
];

export const FORENSIC_AUDIT_TOTAL = 1947.700;

export const CONTAMINATION_ENTRIES: ContaminationEntry[] = [
  {
    date: '13-03-2021',
    voucher: 'Dnt:5',
    narrative: 'BANK MUSCAT NAZAR TICKET / SALARY / ETC MARUF (سداد بنكي)',
    debit: null,
    credit: 509.300,
    highlight: false
  },
  {
    date: '11-12-2021',
    voucher: 'Pmt:2080',
    narrative: 'SHAJAHAN ADVANCE (سلفية عامل آخر: شاه جهان — تم إدراجها دون مسوغ!)',
    debit: 300.000,
    credit: null,
    highlight: true
  },
  {
    date: '20-12-2021',
    voucher: 'Pmt:2110',
    narrative: 'HAFEZ LOAN (قرض عامل آخر: حافظ — تم إقحامه لتضخيم المديونية!)',
    debit: 100.000,
    credit: null,
    highlight: true
  },
  {
    date: '02-01-2022',
    voucher: 'Rct:4608',
    narrative: 'Cash / SHAJAHAN 250 BALANCE (سداد رصيد شاه جهان من حساب المحل)',
    debit: null,
    credit: 50.000,
    highlight: false
  },
  {
    date: '06-07-2024',
    voucher: 'Final Stmt',
    narrative: 'FINAL AUDIT BALANCE: Account settled with +21.800 OMR CREDIT in worker favor!',
    debit: null,
    credit: 21.800,
    highlight: true
  }
];

export const JAN_FEB_2026_RECONSTRUCTION = `═════════════════════════════════════════════════════════════════
FORENSIC SALARY RECONSTRUCTION: JANUARY / FEBRUARY 2026 PAYROLL
Employee: Habibur Rahman (Maruf) | Bank Muscat WPS ID: 0418-XXXXX
═════════════════════════════════════════════════════════════════

(+) Contractual Gross Base Wage (WPS Baseline):       + 250.000 OMR
(-) Shortage / Arbitrary Loan Deduction:             -  50.000 OMR
(-) Unlawful Absence Cut (3 days @ 8.333 OMR):        -  25.000 OMR (Violates Art. 66 Medical Leave)
(-) Coerced Medical Advance Recovery:                -  15.000 OMR
(-) Arbitrary "Worker Tax" Deduction:                 -   2.700 OMR
─────────────────────────────────────────────────────────────────
Total Unlawful Deductions Confiscated:               -  92.700 OMR
═════════════════════════════════════════════════════════════════
NET EXECUTED SALARY DISBURSED:                         157.300 OMR

ACTUAL EXECUTION SPLIT:
 • Bank Muscat WPS Bank Transfer (Error/Slashed):       80.000 OMR  (29/01/2026)
 • Cash Complementary Handed After Written Protest:     77.300 OMR  (02/02/2026)
─────────────────────────────────────────────────────────────────
TOTAL RECEIVED BY WORKER:                              157.300 OMR

[SEPARATE OFF-LEDGER COERCION DETECTED]:
Employer forced a 100.000 OMR third-party customer default debt onto
worker's sub-ledger while delaying stock delivery to Barka Branch!`;

export const STATUTORY_BREACHES = [
  {
    id: 'b-01',
    article: 'Articles 6 & 147',
    badge: 'Criminal Violation',
    color: 'red',
    titleEn: '11-Year Passport Confiscation & Mobility Deprivation',
    titleAr: 'المادتان 6 و 147: احتجاز جواز السفر ومصادرة حرية التنقل',
    titleBn: 'ধারা ৬ ও ১৪৭: ১১ বছর মূল পাসপোর্ট আটকে রাখা ও স্বাধীনতা হরণ',
    descEn: 'Al Yarmook LLC forcibly confiscated claimant original passport from 2015 to 2026 to prevent lawful job mobility. Under Article 147, violators face mandatory criminal fines of 500 to 1,000 OMR per worker (doubled on repeat).',
    descAr: 'احتجزت المنشأة جواز سفر العامل الأصلي طوال 11 عاماً بالمخالفة الصريحة لقانون العمل وتصل عقوبتها للغرامة 1000 ر.ع مع الإلزام بالتسليم الفوري.',
    descBn: 'শ্রমিক যাতে কোথাও যেতে না পারে সেজন্য ১১ বছর ধরে মূল পাসপোর্ট আটকে রেখেছে যা ফৌজদারি অপরাধ (৫০০-১০০০ রিয়াল জরিমানা)।'
  },
  {
    id: 'b-02',
    article: 'Article 37',
    badge: 'Seniority Breach',
    color: 'amber',
    titleEn: 'Seniority Wage Evasion via Coerced Demotion (300 to 250 OMR)',
    titleAr: 'المادة 37: التهرب من احتساب مكافأة نهاية الخدمة بالتحايل وتنزيل الراتب',
    titleBn: 'ধারা ৩৭: সার্ভিস বেনিফিট ফাঁকি দিতে ৩০০ থেকে ২৫০ রিয়ালে নামিয়ে আনা',
    descEn: 'Employer stripped agreed 50 OMR monthly sales commission and coerced paper contract to 60 OMR to depress End of Service Benefits (EOSB). Supreme Judicial Council precedent establishes true wage must govern all 11 years.',
    descAr: 'تجريد العامل من عمولة المبيعات ومحاولة فرض عقد صوري بـ 60 ر.ع لحرمانه من مستحقات نهاية الخدمة العادلة.',
    descBn: 'মারুফের গ্র্যাচুইটি কম দেওয়ার জন্য ৬০ রিয়ালের ভুয়া চুক্তি তৈরি করা হয় যা সুপ্রিম কোর্টের রায়ে অকার্যকর।'
  },
  {
    id: 'b-03',
    article: 'Articles 55 & 58',
    badge: 'Wage Protection Breach',
    color: 'red',
    titleEn: 'Salary Deductions Exceeding Legal Ceiling (20% to 70% Confiscation)',
    titleAr: 'المادتان 55 و 58: تجاوز الحد الأقصى القانوني للخصم (اقتطاع 20% إلى 70%)',
    titleBn: 'ধারা ৫৫ ও ৫৮: অনুমোদিত সীমার বাইরে ২০% থেকে ৭০% বেতন কর্তন',
    descEn: 'Article 58 strictly caps permissible wage deductions at 15% (or 25% for loans). Al Yarmook slashed net payouts down to 80 OMR (over 68% deduction) without written agreement, investigation, or court decree.',
    descAr: 'يحظر القانون استقطاع أكثر من 15% إلى 25%، في حين قامت الإدارة باقتطاع مبالغ خيالية أوصلت الراتب إلى 80 ر.ع فقط.',
    descBn: 'আইনে সর্বোচ্চ ১৫-২৫% কাটার নিয়ম থাকলেও কোম্পানি জোর করে মারুফের বেতনের ৭০% পর্যন্ত কেটে নিয়েছে।'
  },
  {
    id: 'b-04',
    article: 'Article 58 & 66',
    badge: 'Leave Denial',
    color: 'blue',
    titleEn: '11 Years Unpaid Accrued Annual Leave (330 Days Owed)',
    titleBn: 'ধারা ৫৮ ও ৬৬: ১১ বছরের ৩৩০ দিনের সঞ্চিত বার্ষিক ছুটির টাকা অনাদায়ী',
    titleAr: 'المادتان 58 و 66: الحرمان من بدل الإجازات السنوية المجمعة (330 يوماً)',
    descEn: 'Claimant served 11 continuous years without receiving statutory annual leave encashment (30 days/yr = 330 accumulated days). Valued at 2,750.000 OMR based on 250 OMR wage.',
    descAr: 'خدمة مستمرة لمدة 11 عاماً دون صرف نقدي لرصيد الإجازات السنوية المستحقة قانوناً (30 يوماً عن كل سنة).',
    descBn: '১১ বছর ধরে কাজ করলেও প্রতি বছরের ৩০ দিনের ছুটির কোনো টাকা কোম্পানি পরিশোধ করেনি।'
  },
  {
    id: 'b-05',
    article: 'Article 66',
    badge: 'Protected Medical Leave',
    color: 'purple',
    titleEn: 'Unlawful Deduction for Certified Sick Leave (27/01/2026 Certificate)',
    titleAr: 'المادة 66: معاقبة العامل بالخصم أثناء إجازة مرضية معتمدة طبياً',
    titleBn: 'ধারা ৬৬: ডাক্তার সত্যায়িত মেডিকেল ছুটির বিপরীতে বেতন কর্তন',
    descEn: 'Claimant provided a legitimate doctor-certified sick leave slip dated 27/01/2026. Al Yarmook illegally deducted 25 OMR for 3 days absence in clear breach of paid sick leave statutory safeguards.',
    descAr: 'قام صاحب العمل بخصم 25 ر.ع عن 3 أيام غياب رغم تقديم تقرير طبي معتمد صادراً بتاريخ 27/01/2026م.',
    descBn: 'ডাক্তারের অফিশিয়াল ছুটি সনদ থাকা সত্ত্বেও ৩ দিনের জন্য ২৫ রিয়াল কেটে নেওয়া আইনের সুস্পষ্ট লঙ্ঘন।'
  }
];

export const INITIAL_LEDGER_ENTRIES: LedgerEntry[] = [
  {
    id: 'led-01',
    date: '2026-01-28',
    total_sales: 1420.500,
    bank_deposit: 1420.500,
    expenses_paid: 0.000,
    deduction: 0.000,
    ledger_type: 'HABIBUR_PERSONAL',
    note: 'Bank Muscat deposit slip #BM-88419 verified by Muhammad Nazar diary page 48.',
    short_amount: 0.000
  },
  {
    id: 'led-02',
    date: '2026-01-15',
    total_sales: 985.250,
    bank_deposit: 985.250,
    expenses_paid: 0.000,
    deduction: 0.000,
    ledger_type: 'HABIBUR_PERSONAL',
    note: 'Mabella and Barka branch sales reconciled. Deposit slip #BM-87912.',
    short_amount: 0.000
  },
  {
    id: 'led-03',
    date: '2026-01-29',
    total_sales: 250.000,
    bank_deposit: 80.000,
    expenses_paid: 0.000,
    deduction: 170.000,
    ledger_type: 'HABIBUR_PERSONAL',
    note: 'Arbitrary salary transfer error by company. Slashed 170 OMR.',
    short_amount: 170.000
  },
  {
    id: 'led-04',
    date: '2025-12-10',
    total_sales: 3000.000,
    bank_deposit: 2800.000,
    expenses_paid: 200.000,
    deduction: 0.000,
    ledger_type: 'OWNER_CORPORATE',
    note: 'Aluminium profiles delivery freight paid on behalf of head office.',
    short_amount: 0.000
  },
  {
    id: 'led-05',
    date: '2025-08-14',
    total_sales: 0.000,
    bank_deposit: 0.000,
    expenses_paid: 0.000,
    deduction: 2200.000,
    ledger_type: 'OWNER_CORPORATE',
    note: 'Fabricated cash shortage manufactured via admin password tampering during leave.',
    short_amount: 0.000
  }
];

export const STRATEGIC_LETTERS = {
  track1: {
    title: 'TRACK 1 — Formal Legal Appeal & Amicable Settlement Request',
    date: '02/02/2026',
    recipient: 'The Board of Directors / General Manager\nAl Yarmook Modern Trading LLC\nMabella Industrial Area / Barka, Sultanate of Oman',
    content: `Subject: Formal Appeal Concerning Unlawful Salary Reductions & Submission of Work Regularisation Terms

Respected Management,

I, Habibur Rahman Abdul Barak ("Maruf"), holding Civil ID No. 103352388 and Work Permit No. 10706994, write to you with deep respect and sincerity regarding my unbroken eleven (11) years of continuous service since July 2015. Over these years, I have dedicated myself entirely to the growth of Al Yarmook Modern Trading LLC, establishing and expanding our Barka Industrial Branch from its inception to monthly commercial turnovers reaching 53,000 OMR.

I must respectfully lodge a formal objection to the recent arbitrary reductions imposed upon my contractual salary:

1. Cap on Monthly Deductions:
   Under Article 58 of Royal Decree No. 53/2023, deductions are strictly limited. Imposing cumulative cuts that reduced my net pay on 29/01/2026 to only 80 OMR is an extreme hardship. I respectfully request an immediate cap on any disputed deduction to no more than 30.000 OMR monthly, preserving the dignity of my lawful livelihood.

2. Installment Relief for Customer Defaults:
   The 100.000 OMR customer default attributed to my account was solely occasioned by company warehouse dispatch delays beyond my field control. I request this liability be absorbed by corporate operational bad debt, or structured with manageable humanitarian installments.

3. Official Audited Company Ledger Statement:
   As established on 06/07/2024, my ledger closed with a positive credit balance of +21.800 OMR in my favour. I hereby formally request a signed, stamp-authenticated copy of my Sub-Ledger statement.

My sole objective is to maintain Halal sustenance for my wife and four daughters who depend upon my earnings. I urge management to resolve these matters amicably before formal court hearings commence.

Yours faithfully,
Habibur Rahman Abdul Barak (Maruf)
Barka Branch Manager | Mobile: +968 96522902`
  },
  track2: {
    title: 'TRACK 2 — No Objection Certificate (NOC) & Unconditional Release Request',
    date: '10/02/2026',
    recipient: 'Department of Human Resources & Legal Affairs\nAl Yarmook Modern Trading LLC\nSultanate of Oman',
    content: `Subject: Request for No Objection Certificate (NOC) and Unconditional Sponsorship Transfer Release

Respected Management,

Having completed over eleven (11) unbroken years of service with Al Yarmook Modern Trading LLC (encompassing more than five consecutive statutory contract renewals since July 2015), I hereby formally request the issuance of an official No Objection Certificate (NOC) and release to transfer my work visa to a new sponsor within the Sultanate of Oman.

Under the amended provisions of the Omani Labour Law (Royal Decree No. 53/2023) and Royal Oman Police Immigration Regulations:
1. Long-serving expatriates who have completed contractual periods possess the statutory right to seek new employment without arbitrary restrictions.
2. I undertake to conduct a full, transparent handover of all customer accounts, keys, and branch inventory across Barka and Mabella.
3. This release shall operate concurrently with the final liquidation of my statutory End of Service Benefits (EOSB) amounting to 2,375.000 OMR and accrued leave entitlements.

I appeal to your sense of Islamic brotherhood and corporate honour to grant this release promptly, allowing me to continue supporting my family lawfully within the Sultanate.

Yours sincerely,
Habibur Rahman Abdul Barak (Maruf)
Civil ID: 103352388 | Phone: +968 96522902`
  }
};
