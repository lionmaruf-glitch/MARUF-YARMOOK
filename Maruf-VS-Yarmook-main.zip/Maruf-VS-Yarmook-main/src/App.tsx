import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ForensicAuditView } from './components/ForensicAuditView';
import { StatutoryViolationsView } from './components/StatutoryViolationsView';
import { EvidenceVault } from './components/EvidenceVault';
import { DualLedgerTracker } from './components/DualLedgerTracker';
import { SubLedgerContaminationView } from './components/SubLedgerContaminationView';
import { AILabView } from './components/AILabView';
import { LegalCalculator } from './components/LegalCalculator';
import { StrategicLettersView } from './components/StrategicLettersView';
import { CourtPetitionView } from './components/CourtPetitionView';
import { SettingsBackupView } from './components/SettingsBackupView';
import { AudioTranscriberView } from './components/AudioTranscriberView';
import { OmanLabourLawAdvisor } from './components/OmanLabourLawAdvisor';
import { CaseTimelineView } from './components/CaseTimelineView';
import { LegalResearchLabView } from './components/LegalResearchLabView';
import { EvidenceInspectorModal } from './components/EvidenceInspectorModal';
import { Language, TRANSLATIONS } from './data/translations';
import { EvidenceItem } from './types/case';
import { Menu, Printer, Scale, Download, Mic, Camera, Calendar, FileText, User as UserIcon } from 'lucide-react';
import { auth } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('maruf_lang');
      if (saved === 'en' || saved === 'ar' || saved === 'bn') return saved;
    } catch {
      // ignore
    }
    return 'bn';
  });

  const [currentSection, setCurrentSection] = useState<string>('dashboard');
  const [selectedEvidenceCategory, setSelectedEvidenceCategory] = useState<string>('all');
  const [inspectingItem, setInspectingItem] = useState<EvidenceItem | null>(null);
  const [isSidebarOpenMobile, setIsSidebarOpenMobile] = useState(false);
  const [forwardedPromptToAILab, setForwardedPromptToAILab] = useState<string>('');

  useEffect(() => {
    document.body.dataset.lang = lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

    try {
      localStorage.setItem('maruf_lang', lang);
    } catch {
      // ignore
    }
  }, [lang]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });
    return () => unsub();
  }, []);

  const handlePrint = () => {
    if (currentSection !== 'court-petition') {
      setCurrentSection('court-petition');
    }
    setTimeout(() => {
      window.print();
    }, 200);
  };

  const handleSelectCategoryFromDashboard = (cat: string) => {
    setSelectedEvidenceCategory(cat);
    setCurrentSection('evidence-vault');
  };

  const t = TRANSLATIONS[lang];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex font-sans">
      
      {/* 280px Left Sidebar */}
      <Sidebar
        currentSection={currentSection}
        onSelectSection={setCurrentSection}
        isOpenMobile={isSidebarOpenMobile}
        onCloseMobile={() => setIsSidebarOpenMobile(false)}
        lang={lang}
      />

      {/* Main Content Viewport */}
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${lang === 'ar' ? 'lg:mr-72' : 'lg:ml-72'}`}>
        
        {/* Sticky Topbar */}
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4 no-print shadow-2xs">
          
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setIsSidebarOpenMobile(true)}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <div className="text-sm font-bold text-slate-900 truncate">
                MarufEdge Forensic Lab
              </div>
              <span className="text-xs text-slate-400 font-mono hidden md:inline">
                / CRT2601-3344
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick Camera Document Scanner button */}
            <button
              onClick={() => setCurrentSection('evidence-vault')}
              title="Camera Document Scanner & Grayscale Legal Conversion"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
                currentSection === 'evidence-vault'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Scan Doc</span>
            </button>

            {/* Quick Voice Transcribe button */}
            <button
              onClick={() => setCurrentSection('audio-transcribe')}
              title="Voice & Audio Transcription (gemini-3.5-transcribe)"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
                currentSection === 'audio-transcribe'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <Mic className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Voice Transcribe</span>
            </button>

            {/* Quick Timeline button */}
            <button
              onClick={() => setCurrentSection('case-timeline')}
              title="Critical Case Dates & Milestones Timeline (Recharts)"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
                currentSection === 'case-timeline'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden lg:inline">Timeline</span>
            </button>

            {/* Quick Legal Document & Judgment Research Lab button */}
            <button
              onClick={() => setCurrentSection('ai-research-lab')}
              title="Upload Legal Files, Judgments & Research Study Lab"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
                currentSection === 'ai-research-lab'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-purple-600" />
              <span className="hidden sm:inline">Research Lab</span>
            </button>

            {/* Quick Oman Law AI Advisor button */}
            <button
              onClick={() => setCurrentSection('law-advisor')}
              title="Oman Labour Law AI Advisor (Search Grounding RD 53/2023)"
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors border ${
                currentSection === 'law-advisor'
                  ? 'bg-amber-400 text-slate-950 border-amber-500 font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <Scale className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden lg:inline">Law Advisor</span>
            </button>

            {/* Firebase User Status Chip */}
            {user && (
              <button
                onClick={() => setCurrentSection('settings')}
                title={`Signed in as ${user.email} (Firebase Firestore Active)`}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 hover:bg-emerald-100 transition-colors"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="max-w-[100px] truncate font-mono text-[11px] font-semibold">
                  {user.displayName?.split(' ')[0] || user.email?.split('@')[0]}
                </span>
              </button>
            )}

            {/* Standalone HTML Download Link */}
            <a
              href="/marufedge-forensic-lab.html"
              download="marufedge-forensic-lab.html"
              title="Download Single-File Offline HTML"
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
            >
              <Download className="w-3.5 h-3.5 text-amber-600" />
              <span>Offline HTML</span>
            </a>

            {/* Language Switcher */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
              <button
                onClick={() => setLang('bn')}
                className={`px-2.5 py-1 font-bold rounded transition-colors ${
                  lang === 'bn' ? 'bg-[#0b1f3a] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                বাংলা
              </button>
              <button
                onClick={() => setLang('en')}
                className={`px-2 py-1 font-bold rounded transition-colors ${
                  lang === 'en' ? 'bg-[#0b1f3a] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLang('ar')}
                className={`px-2.5 py-1 font-bold rounded transition-colors ${
                  lang === 'ar' ? 'bg-[#0b1f3a] text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                العربية
              </button>
            </div>

            {/* Primary Print Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 rounded-lg shadow-2xs transition-all whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print A4 (AR+EN)</span>
              <span className="sm:hidden">Print</span>
            </button>
          </div>

        </header>

        {/* View Routing */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentSection === 'dashboard' && (
            <DashboardView
              lang={lang}
              onNavigate={setCurrentSection}
              onSelectEvidenceCategory={handleSelectCategoryFromDashboard}
            />
          )}

          {currentSection === 'case-timeline' && (
            <CaseTimelineView
              lang={lang}
              onNavigate={setCurrentSection}
              onSendToAILab={(prompt) => {
                setForwardedPromptToAILab(prompt);
                setCurrentSection('ai-lab');
              }}
            />
          )}

          {currentSection === 'forensic-audit' && (
            <ForensicAuditView
              lang={lang}
              onNavigate={setCurrentSection}
              onPrint={handlePrint}
            />
          )}

          {currentSection === 'statutory-violations' && (
            <StatutoryViolationsView
              lang={lang}
              onNavigate={setCurrentSection}
              onPrint={handlePrint}
            />
          )}

          {currentSection === 'evidence-vault' && (
            <EvidenceVault
              lang={lang}
              selectedCategory={selectedEvidenceCategory}
              onSelectCategory={setSelectedEvidenceCategory}
              onInspectEvidence={(item) => setInspectingItem(item)}
            />
          )}

          {currentSection === 'dual-ledger' && (
            <DualLedgerTracker
              lang={lang}
            />
          )}

          {currentSection === 'sub-ledger-contamination' && (
            <SubLedgerContaminationView
              lang={lang}
              onNavigate={setCurrentSection}
              onPrint={handlePrint}
            />
          )}

          {currentSection === 'ai-lab' && (
            <AILabView
              lang={lang}
              initialPrompt={forwardedPromptToAILab}
              onClearInitialPrompt={() => setForwardedPromptToAILab('')}
            />
          )}

          {currentSection === 'audio-transcribe' && (
            <AudioTranscriberView
              lang={lang}
              onSendToAILab={(text) => {
                setForwardedPromptToAILab(
                  `قم بتحليل هذا التفريغ الصوتي لأقوال العامل واستخرج الحجج القانونية الواجب تقديمها للمحكمة الابتدائية:\n\n"${text}"`
                );
                setCurrentSection('ai-lab');
              }}
            />
          )}

          {currentSection === 'law-advisor' && (
            <OmanLabourLawAdvisor
              lang={lang}
              onNavigateToSection={setCurrentSection}
              onForwardToPetition={(text) => {
                setForwardedPromptToAILab(
                  `قم بصياغة مذكرة قضائية استناداً للرأي القانوني والبحث التالي:\n\n${text}`
                );
                setCurrentSection('ai-lab');
              }}
            />
          )}

          {currentSection === 'ai-research-lab' && (
            <LegalResearchLabView
              lang={lang}
              onForwardToPetition={(text) => {
                setForwardedPromptToAILab(
                  `قم بصياغة مذكرة قضائية استناداً للتقرير والدراسة القانونية التالية:\n\n${text}`
                );
                setCurrentSection('court-petition');
              }}
              onForwardToAILab={(text) => {
                setForwardedPromptToAILab(
                  `قم بفحص هذا التحليل الجنائي للمستند وصياغة طلبات الإلزام والدفوع وفق قانون العمل العماني:\n\n${text}`
                );
                setCurrentSection('ai-lab');
              }}
            />
          )}

          {currentSection === 'calculator' && (
            <LegalCalculator
              lang={lang}
              onNavigateToPetition={() => setCurrentSection('court-petition')}
            />
          )}

          {currentSection === 'strategic-letters' && (
            <StrategicLettersView
              lang={lang}
              onPrint={handlePrint}
            />
          )}

          {currentSection === 'court-petition' && (
            <CourtPetitionView
              lang={lang}
              onPrint={handlePrint}
            />
          )}

          {currentSection === 'settings' && (
            <SettingsBackupView
              lang={lang}
            />
          )}

          {currentSection === 'backup' && (
            <SettingsBackupView
              lang={lang}
            />
          )}
        </main>

        {/* Quiet Judicial Footer (no-print) */}
        <footer className="bg-white border-t border-slate-200 py-5 px-6 text-xs text-slate-500 no-print mt-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
            <div>
              <b className="text-slate-800">MarufEdge Forensic Lab</b> — Sultanate of Oman Supreme Judicial Council (RD 53/2023)
            </div>
            <div className="font-mono text-slate-400 text-[11px]">
              Seeb CRT2601-3344 · Barka 1005/1215/2026 · Habibur Rahman (103352388)
            </div>
          </div>
        </footer>

      </div>

      {/* Modal Inspector */}
      {inspectingItem && (
        <EvidenceInspectorModal
          item={inspectingItem}
          lang={lang}
          onClose={() => setInspectingItem(null)}
        />
      )}

    </div>
  );
}
